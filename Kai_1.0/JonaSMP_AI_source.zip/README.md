# JonaSMP AI — Rekonstruierter Source Code

## Was ist das?

Dieser Source wurde aus der kompilierten JAR `JonaSMP_AI_v1_Fixed-1_0_0.jar` 
durch Bytecode-Analyse rekonstruiert (Java 25 Bytecode → Java-Stubs).

## Struktur

- **Stubs** (205 Klassen): Vollständige Felder + Methoden-Signaturen aus dem Bytecode extrahiert.
  Die Methoden-Bodies enthalten `// TODO: decompile` da Java 25 Bytecode mit
  verfügbaren Open-Source-Decompilern nicht vollständig lesbar ist.

- **Vollständig implementiert** (unsere Fixes aus dieser Session):
  - `BotCombatManager.java` — Kompletter Rewrite mit:
    - Range-Check vor attack() (max 3.5 Blöcke)
    - Line-of-Sight-Check
    - Mace Smash Fix (WindCharge → aufsteigen → fallen → smash)
    - Eating-Fix (Waffe merken, nach Essen zurückwechseln)
    - W-Tap, Kiting, Shield-Block
  - `AIGoalBridge.java` — Neu: trennt Player-Goals von AI-Goals

## Bekannte Bugs im Original (aus Bytecode-Analyse + Logs)

| Bug | Klasse | Beschreibung |
|---|---|---|
| Attack aus 87 Blöcken | BotCombatManager | Kein Range-Check vor attack() |
| Angriff durch Blöcke | BotCombatManager | Kein hasLineOfSight()-Check |
| Mace als Schwert | BotCombatManager | startMaceSmash() nie getriggert |
| Essen mit Waffe weiter kämpfen | BotCombatManager | Kein Weapon-Lock während eating |
| AI überschreibt Player-Goal | AIPlayerBot | Kein Priority-System |
| Bot macht nix nach Befehl | BotGoalPlanner | stepStuckCounter → wander loop |
| WindCharge nie genutzt | BotCombatManager | findWindChargeSlot() defekt |

## Build

```bash
mvn clean package -DskipTests
```

Benötigt Java 25 und die im pom.xml definierten Dependencies.

## String-Konstanten

Jede Stub-Klasse enthält am Ende einen `/* String constants */` Kommentar
mit allen String-Literalen aus dem Bytecode — sehr hilfreich um die
ursprüngliche Logik zu rekonstruieren.
