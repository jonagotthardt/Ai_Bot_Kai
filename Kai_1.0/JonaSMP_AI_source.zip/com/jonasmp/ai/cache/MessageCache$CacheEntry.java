package com.jonasmp.ai.cache;

public class MessageCache$CacheEntry {

    final ChatModerationPipeline$PipelineResult result;
    final long expiresAt;

     MessageCache$CacheEntry(ChatModerationPipeline$PipelineResult arg0, long arg1) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'expiresAt'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'MessageCache.java'
       'InnerClasses'
       'CacheEntry'
       'PipelineResult'
    */
}