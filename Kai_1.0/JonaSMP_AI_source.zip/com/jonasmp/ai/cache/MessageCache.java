package com.jonasmp.ai.cache;

public class MessageCache {

    private final ConcurrentHashMap cache;
    private final ScheduledExecutorService cleaner;
    private long defaultTtlMs;

    public MessageCache() {
        // TODO: decompile
    }

    public void setDefaultTtl(long arg0) {
    }

    public ChatModerationPipeline$PipelineResult get(String arg0) {
        return null;
    }

    public void put(String arg0, ChatModerationPipeline$PipelineResult arg1) {
    }

    public void put(String arg0, ChatModerationPipeline$PipelineResult arg1, long arg2) {
    }

    public void invalidate(String arg0) {
    }

    public void clear() {
    }

    public int size() {
        return 0;
    }

    public void shutdown() {
    }

    private void cleanExpired() {
    }

    private String hash(String arg0) {
        return null;
    }

    private static boolean lambda$cleanExpired$0(long arg0, Map$Entry arg1) {
        return false;
    }

    private static Thread lambda$new$0(Runnable arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'newThread'
       'newSingleThreadScheduledExecutor'
       'defaultTtlMs'
       'scheduleAtFixedRate'
       'currentTimeMillis'
       'expiresAt'
       'toHexString'
       'JonaSMP-CacheCleaner'
       'setDaemon'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'setDefaultTtl'
       'StackMapTable'
       'invalidate'
       'cleanExpired'
       'lambda$cleanExpired$0'
       'lambda$new$0'
       'SourceFile'
       'MessageCache.java'
       'NestMembers'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
       'CacheEntry'
       'PipelineResult'
    */
}