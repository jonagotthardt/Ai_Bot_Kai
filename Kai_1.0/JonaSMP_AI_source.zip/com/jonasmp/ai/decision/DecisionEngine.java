package com.jonasmp.ai.decision;

public class DecisionEngine {

    public DecisionEngine() {
        // TODO: decompile
    }

    public DecisionResult evaluate(AIResponse arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'getToxicity'
       'Toxic language detected'
       'Potentially toxic language'
       'Safe message'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'DecisionEngine.java'
       'InnerClasses'
    */
}