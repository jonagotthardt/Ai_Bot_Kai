package com.jonasmp.ai.decision;

public class DecisionResult {

    private final DecisionResult$Action action;
    private final double score;
    private final String reason;

    public DecisionResult(DecisionResult$Action arg0, double arg1, String arg2) {
        // TODO: decompile
    }

    public DecisionResult$Action getAction() {
        return null;
    }

    public double getScore() {
        return 0.0;
    }

    public String getReason() {
        return null;
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'getAction'
       'getReason'
       'SourceFile'
       'DecisionResult.java'
       'NestMembers'
       'InnerClasses'
    */
}