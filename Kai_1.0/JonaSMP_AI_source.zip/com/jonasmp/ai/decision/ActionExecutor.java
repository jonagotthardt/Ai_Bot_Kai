package com.jonasmp.ai.decision;

public class ActionExecutor {

    public ActionExecutor() {
        // TODO: decompile
    }

    public void execute(Player arg0, DecisionResult arg1) {
    }

    /* String constants found in bytecode:
       '$SwitchMap$com$jonasmp$ai$decision$DecisionResult$Action'
       'getAction'
       '§cMessage blocked by AI'
       'sendMessage'
       'getReason'
       'makeConcatWithConstants'
       '§6Flagged for review'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'ActionExecutor.java'
       'NestMembers'
       'BootstrapMethods'
       '§eWarning: \x01'
       'InnerClasses'
    */
}