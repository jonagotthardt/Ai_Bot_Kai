package com.jonasmp.ai.decision;

public class DecisionResult$Action extends Enum {

    public static final DecisionResult$Action ALLOW;
    public static final DecisionResult$Action WARN;
    public static final DecisionResult$Action BLOCK;
    public static final DecisionResult$Action KICK;
    public static final DecisionResult$Action BAN;
    public static final DecisionResult$Action FLAG;
    private static final DecisionResult$Action[] $VALUES;

    public static DecisionResult$Action[] values() {
        return null;
    }

    public static DecisionResult$Action valueOf(String arg0) {
        return null;
    }

    private DecisionResult$Action(String arg0, int arg1) {
        // TODO: decompile
    }

    private static DecisionResult$Action[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'DecisionResult.java'
       'InnerClasses'
    */
}