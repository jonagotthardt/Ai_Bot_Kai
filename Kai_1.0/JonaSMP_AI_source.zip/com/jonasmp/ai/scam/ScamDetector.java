package com.jonasmp.ai.scam;

public class ScamDetector {

    private final List patterns;

    public ScamDetector() {
        // TODO: decompile
    }

    public boolean isScam(String arg0) {
        return false;
    }

    public double scamScore(String arg0) {
        return 0.0;
    }

    /* String constants found in bytecode:
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'scamScore'
       'SourceFile'
       'ScamDetector.java'
    */
}