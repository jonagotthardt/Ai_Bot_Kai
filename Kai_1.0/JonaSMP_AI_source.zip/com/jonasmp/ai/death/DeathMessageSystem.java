package com.jonasmp.ai.death;

public class DeathMessageSystem implements Listener {

    private final Random random;
    private final Map deMessages;
    private final Map enMessages;

    public DeathMessageSystem() {
        // TODO: decompile
    }

    public void register() {
    }

    public void onPlayerDeath(PlayerDeathEvent arg0) {
    }

    private String getDeathCategory(Player arg0, Player arg1) {
        return null;
    }

    private String getRandomMessage(String arg0, String arg1, String arg2, Player arg3) {
        return null;
    }

    private void loadMessages() {
    }

    /* String constants found in bytecode:
       'deMessages'
       'enMessages'
       'loadMessages'
       'getPluginManager'
       'registerEvents'
       'getLogger'
       'getEntity'
       'getKiller'
       'getDeathCategory'
       'setDeathMessage'
       'getOnlinePlayers'
       'PLAYER_LANGUAGE_STORE'
       'getUniqueId'
       'getLanguage'
       'getRandomMessage'
       'sendMessage'
       'getLastDamageCause'
       '$SwitchMap$org$bukkit$event$entity$EntityDamageEvent$DamageCause'
       'explosion'
       'mob_melee'
       'projectile'
       'suffocation'
       'starvation'
       'lightning'
       'getDamage'
       'bed_explosion'
       'block_explosion'
       'dragon_breath'
       'sonic_boom'
       'getOrDefault'
       'translateAlternateColorCodes'
       '&c[Spieler] &7fand die Gravitation etwas zu interessant.'
       '&c[Spieler] &7hat die Schwerkraft unterschätzt. Die Schwerkraft nicht.'
       '&c[Spieler] &7wollte fliegen. Der Boden hatte Einwände.'
       '&c[Spieler] &7führte einen kontrollierten Absturz durch. Kontrolle nicht gefunden.'
       '&c[Spieler] &7sprang. Der Boden gewann.'
       '&c[Spieler] &7erreichte sein Ziel. Leider mit dem Gesicht zuerst.'
       '&c[Spieler] &7found gravity a bit too interesting.'
       "&c[Spieler] &7underestimated gravity. Gravity didn't."
       '&c[Spieler] &7tried to fly. The ground objected.'
    */
}