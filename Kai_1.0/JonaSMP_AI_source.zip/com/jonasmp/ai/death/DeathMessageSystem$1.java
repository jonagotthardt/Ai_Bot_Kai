package com.jonasmp.ai.death;

public class DeathMessageSystem$1 {

    static final int[] $SwitchMap$org$bukkit$event$entity$EntityDamageEvent$DamageCause;

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       '$SwitchMap$org$bukkit$event$entity$EntityDamageEvent$DamageCause'
       'FLY_INTO_WALL'
       'FIRE_TICK'
       'ENTITY_EXPLOSION'
       'ENTITY_ATTACK'
       'PROJECTILE'
       'SUFFOCATION'
       'STARVATION'
       'LIGHTNING'
       'BLOCK_EXPLOSION'
       'FALLING_BLOCK'
       'DRAGON_BREATH'
       'HOT_FLOOR'
       'SONIC_BOOM'
       'WORLD_BORDER'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'DeathMessageSystem.java'
       'EnclosingMethod'
       'InnerClasses'
       'DamageCause'
    */
}