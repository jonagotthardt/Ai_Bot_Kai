package com.jonasmp.ai.memory;

public class ProfileExporter {

    private final File profilesFolder;

    public ProfileExporter() {
        // TODO: decompile
    }

    public void exportProfile(PlayerMemory arg0) {
    }

    public void exportAll(Collection arg0) {
    }

    private String sanitizeFileName(String arg0) {
        return null;
    }

    public File getProfilesFolder() {
        return null;
    }

    /* String constants found in bytecode:
       'getDataFolder'
       'player_profiles'
       'profilesFolder'
       'displayName'
       'sanitizeFileName'
       'makeConcatWithConstants'
       'getAdminReport'
       'addSuppressed'
       'getLogger'
       'getMessage'
       'exportProfile'
       'getAbsolutePath'
       'replaceAll'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'exportAll'
       'LocalVariableTypeTable'
       'Signature'
       'getProfilesFolder'
       'SourceFile'
       'ProfileExporter.java'
       'BootstrapMethods'
       '\x01_profile.txt'
       'InnerClasses'
    */
}