package com.jonasmp.ai.memory;

public class SuspiciousEvent {

    public long timestamp;
    public String type;
    public String description;
    public int severity;

    public SuspiciousEvent() {
        // TODO: decompile
    }

    public SuspiciousEvent(String arg0, String arg1, int arg2) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'timestamp'
       'description'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'SuspiciousEvent.java'
    */
}