package com.jonasmp.ai.memory;

public class ChatEntry {

    public long timestamp;
    public String message;
    public String channel;

    public ChatEntry() {
        // TODO: decompile
    }

    public ChatEntry(String arg0, String arg1) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'timestamp'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'ChatEntry.java'
    */
}