package com.jonasmp.ai.memory;

public class PlayerActivityListener implements Listener {

    private final Map lastPositions;
    private final Map lastMoveCheck;
    private static final long MOVE_CHECK_INTERVAL_MS;
    private final Map recentOreBreaks;
    private final Map oreCheckWindow;
    private final Map containerOpenTimes;
    private final Map flyMoveTimes;
    private static final int CONTAINER_SPAM_THRESHOLD;
    private static final long CONTAINER_SPAM_WINDOW_MS;
    private static final int FLY_SUSPICION_TICKS;
    private final Map lastLocationSnapshot;

    public PlayerActivityListener() {
        // TODO: decompile
    }

    public void onJoin(PlayerJoinEvent arg0) {
    }

    public void onQuit(PlayerQuitEvent arg0) {
    }

    public void onDeath(PlayerDeathEvent arg0) {
    }

    public void onBlockBreak(BlockBreakEvent arg0) {
    }

    public void onBlockPlace(BlockPlaceEvent arg0) {
    }

    private void checkXraySuspicion(UUID arg0, String arg1, Location arg2) {
    }

    private void checkBurstPlace(UUID arg0) {
    }

    private void checkSpeedAndFly(Player arg0, UUID arg1, Location arg2, Location arg3) {
    }

    private void checkContainerSpam(UUID arg0) {
    }

    public void onEntityDeath(EntityDeathEvent arg0) {
    }

    public void onWorldChange(PlayerChangedWorldEvent arg0) {
    }

    public void onCraft(CraftItemEvent arg0) {
    }

    public void onMove(PlayerMoveEvent arg0) {
    }

    public void onInventoryOpen(InventoryOpenEvent arg0) {
    }

    public void onInteract(PlayerInteractEvent arg0) {
    }

    private static Deque lambda$checkContainerSpam$0(UUID arg0) {
        return null;
    }

    private static Deque lambda$checkSpeedAndFly$0(UUID arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'lastPositions'
       'lastMoveCheck'
       'recentOreBreaks'
       'oreCheckWindow'
       'containerOpenTimes'
       'flyMoveTimes'
       'lastLocationSnapshot'
       'getPlayer'
       'MEMORY_ENGINE'
       'getUniqueId'
       'logConnection'
       'getLocation'
       'getBlockX'
       'getBlockY'
       'getBlockZ'
       'snapshotLocation'
       'sessionsPlayed'
       'First join to the server'
       'recordMilestone'
       'getEntity'
       'getDeathMessage'
       'logAction'
       'onBlockBroken'
       'BLOCK_BREAK'
       'getInventory'
       'getItemInMainHand'
       'onItemUsed'
       'checkXraySuspicion'
       'onBlockPlaced'
       'BLOCK_PLACE'
       'checkBurstPlace'
       'currentTimeMillis'
       'longValue'
       'getOrDefault'
       'addXrayFlag'
       'XRAY_PATTERN'
       'makeConcatWithConstants'
       'logSuspicious'
       'lastBlockPlaceTime'
       'blocksInLastMinute'
    */
}