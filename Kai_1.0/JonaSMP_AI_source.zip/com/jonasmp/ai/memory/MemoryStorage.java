package com.jonasmp.ai.memory;

public class MemoryStorage {

    private final Gson gson;
    private final File folder;

    public MemoryStorage() {
        // TODO: decompile
    }

    public void save(PlayerMemory arg0) {
    }

    public PlayerMemory load(UUID arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'getDataFolder'
       'makeConcatWithConstants'
       'printStackTrace'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'MemoryStorage.java'
       'BootstrapMethods'
       'InnerClasses'
    */
}