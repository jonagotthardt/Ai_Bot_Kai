package com.jonasmp.ai.memory;

public class LocationSnapshot {

    public long timestamp;
    public String world;
    public int x;
    public int y;
    public int z;

    public LocationSnapshot() {
        // TODO: decompile
    }

    public LocationSnapshot(String arg0, int arg1, int arg2, int arg3) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'timestamp'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'LocationSnapshot.java'
    */
}