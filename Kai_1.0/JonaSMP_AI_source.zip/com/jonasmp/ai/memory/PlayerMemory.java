package com.jonasmp.ai.memory;

public class PlayerMemory {

    public UUID uuid;
    public int scamFlags;
    public int raidFlags;
    public int aiBlocks;
    public long lastSeen;
    public String displayName;
    public int totalInteractions;
    public long lastInteraction;
    public List interests;
    public String humorStyle;
    public String formality;
    public String preferredLength;
    public long totalPlayTimeMs;
    public int sessionsPlayed;
    public long currentSessionStart;
    public long longestSessionMs;
    public long avgSessionLengthMs;
    public long firstJoin;
    public long lastLogout;
    public long[] playTimeByHour;
    public long[] playTimeByDay;
    public int totalDeaths;
    public int totalPlayerKills;
    public int totalMobKills;
    public int pvpWins;
    public int pvpLosses;
    public String lastDeathCause;
    public String mostKilledMob;
    public int mostKilledMobCount;
    public long totalBlocksPlaced;
    public long totalBlocksBroken;
    public Map blocksPlacedByType;
    public Map blocksBrokenByType;
    public String favoriteBlock;
    public String favoriteTool;
    public long totalItemsCrafted;
    public long totalItemsEnchanted;
    public Map itemsCrafted;
    public Map itemsUsed;
    public String favoriteItem;
    public long distanceTraveled;
    public long distanceFlown;
    public String favoriteWorld;
    public int netherVisits;
    public int endVisits;
    public int totalChatMessages;
    public int totalAIConversations;
    public int questionCount;
    public long totalCharsTyped;
    public int avgMessageLength;
    public String emotionalTone;
    public String languagePreference;
    public int emojiUsage;
    public Map wordFrequency;
    public List catchphrases;
    public String playStyle;
    public String buildStyle;
    public String riskTolerance;
    public String socialStyle;
    public List topicsAskedAI;
    public List personalFactsShared;
    public List frustrationTriggers;
    public List thingsTheyLike;
    public List thingsTheyDislike;
    public String aiRelationship;
    public long lastVoiceAIResponse;
    public Map nearbyPlayersTime;
    public Map mentionedPlayers;
    public List trustedPlayers;
    public List rivalPlayers;
    public String clanOrGuild;
    public String socialRole;
    public double peakBalance;
    public double totalMoneyEarned;
    public double totalMoneySpent;
    public int shopVisits;
    public Map shopItemsBought;
    public Map shopItemsSold;
    public String tradingStyle;
    public List milestones;
    public int achievementsUnlocked;
    public String currentGoal;
    public int maxGearScore;
    public Map commandUsage;
    public String mostUsedCommand;
    public int teleportRequestsSent;
    public int teleportRequestsAccepted;
    public long totalAfkTimeMs;
    public List actionLog;
    public List suspiciousEvents;
    public int suspicionScore;
    public String adminNotes;
    public boolean flaggedAsSuspicious;
    public List adminFlags;
    public long lastBlockPlaceTime;
    public int blocksInLastMinute;
    public Map suspiciousPatterns;
    public int speedFlags;
    public int flyFlags;
    public int xrayFlags;
    public int nukerFlags;
    public int killauraFlags;
    public int autoclickFlags;
    public int containerSpamFlags;
    public int noFallFlags;
    public int reachFlags;
    public List locationHistory;
    public int chestsOpenedTotal;
    public Map containerAccesses;
    public List chatHistory;
    public List connectionHistory;
    public String realName;
    public String age;
    public String location;
    public String job;
    public String education;
    public String mbtiType;
    public String enneagramType;
    public int bigFiveOpenness;
    public int bigFiveConscientiousness;
    public int bigFiveExtraversion;
    public int bigFiveAgreeableness;
    public int bigFiveNeuroticism;
    public List coreValues;
    public List fears;
    public List strengths;
    public List weaknesses;
    public String primaryMotivation;
    public String attachmentStyle;
    public String selfEsteemIndicator;
    public int perfectionismLevel;
    public String communicationStyle;
    public String conflictStyle;
    public String emotionalExpression;
    public String decisionMakingStyle;
    public String stressResponse;
    public String energySource;
    public List technicalInterests;
    public List creativeInterests;
    public List socialInterests;
    public List hobbies;
    public List sharedLifeEvents;
    public List familyMentioned;
    public List dreamsAndGoals;
    public List regrets;
    public int trustLevel;
    public int vulnerabilityLevel;
    public String howTheySeeAI;
    public List topicsNeverDiscussed;
    public boolean isPerfectionist;
    public boolean isImpulsive;
    public boolean isCompetitive;
    public boolean isEmpathetic;
    public boolean usesHumorAsDefense;
    public boolean overthinks;
    public boolean seeksValidation;
    public boolean avoidsConflict;
    public boolean needsControl;

    public PlayerMemory(UUID arg0) {
        // TODO: decompile
    }

    public int getRiskScore() {
        return 0;
    }

    private void ensureInit() {
    }

    public String getPersonalityContext() {
        return null;
    }

    private String fmtTime(long arg0) {
        return null;
    }

    public void learnFromMessage(String arg0) {
    }

    public void recordAIConversation(String arg0) {
    }

    public void recordPersonalFact(String arg0) {
    }

    public void recordFrustration(String arg0) {
    }

    public void recordLike(String arg0) {
    }

    public void recordDislike(String arg0) {
    }

    public void recordMilestone(String arg0) {
    }

    public void onJoin() {
    }

    public void onQuit() {
    }

    public void onDeath(String arg0) {
    }

    public void onPlayerKill(String arg0) {
    }

    public void onMobKill(String arg0) {
    }

    public void onBlockPlaced(String arg0) {
    }

    public void onBlockBroken(String arg0) {
    }

    public void onItemCrafted(String arg0) {
    }

    public void onItemUsed(String arg0) {
    }

    public void onWorldChange(String arg0) {
    }

    public void onDistanceTraveled(long arg0, boolean arg1) {
    }

    public void onCommand(String arg0) {
    }

    public void onTeleportRequest() {
    }

    public void onTeleportAccept() {
    }

    public void onMoneyEarned(double arg0) {
    }

    public void onMoneySpent(double arg0) {
    }

    public void onShopBuy(String arg0) {
    }

    public void onShopSell(String arg0) {
    }

    public void onNearbyPlayer(String arg0, int arg1) {
    }

    public void onPlayerMention(String arg0) {
    }

    public void setPeakBalance(double arg0) {
    }

    public void setCurrentGoal(String arg0) {
    }

    public void setBuildStyle(String arg0) {
    }

    public void setClanOrGuild(String arg0) {
    }

    public void setSocialRole(String arg0) {
    }

    public void setAiRelationship(String arg0) {
    }

    private void updateFavoriteBlock() {
    }

    private void updateFavoriteItem() {
    }

    private void updateMostUsedCommand() {
    }

    private void updateSocialStyle() {
    }

    private void detectPlayStyle() {
    }

    private void detectRiskTolerance() {
    }

    private void detectTradingStyle() {
    }

    private void detectEmotionalTone(String arg0) {
    }

    private void extractTopics(String arg0) {
    }

    private void addInterest(String arg0) {
    }

    private void detectStyle(String arg0) {
    }

    private void updateWordFrequency(String arg0) {
    }

    private void detectPersonalFacts(String arg0) {
    }

    private void detectPreferences(String arg0) {
    }

    private void extractPreference(String arg0, boolean arg1) {
    }

    private int countEmojis(String arg0) {
        return 0;
    }

    public void logAction(String arg0, String arg1, String arg2, int arg3, int arg4, int arg5) {
    }

    public void logSuspicious(String arg0, String arg1, int arg2) {
    }

    public void addAdminNote(String arg0) {
    }

    public void addAdminFlag(String arg0) {
    }

    public void removeAdminFlag(String arg0) {
    }

    public void snapshotLocation(String arg0, int arg1, int arg2, int arg3) {
    }

    public void logChat(String arg0, String arg1) {
    }

    public void logConnection(String arg0, long arg1) {
    }

    public void logContainerAccess(String arg0) {
    }

    public String getAdminReport() {
        return null;
    }

    private String buildAdminReport() {
        return null;
    }

    private String fmtDate(long arg0) {
        return null;
    }

    public boolean wasAt(String arg0, int arg1, int arg2, int arg3, long arg4, int arg5) {
        return false;
    }

    private void detectDeepPersonalFacts(String arg0) {
    }

    private int findSentenceEnd(String arg0, int arg1) {
        return 0;
    }

    private void detectPsychologicalPatterns(String arg0, String arg1) {
    }

    private void detectCommunicationStyle(String arg0) {
    }

    private void detectStressResponse(String arg0) {
    }

    private void detectEnergySource(String arg0) {
    }

    private void detectCompetitiveness(String arg0) {
    }

    private void detectPerfectionism(String arg0) {
    }

    private void detectEmpathy(String arg0) {
    }

    private void detectDreamsAndGoals(String arg0) {
    }

    private void detectRegrets(String arg0) {
    }

    private void detectFamilyMentions(String arg0) {
    }

    private void detectLifeEvents(String arg0) {
    }

    private void updateTrustAndVulnerability(String arg0) {
    }

    public String getDeepProfile() {
        return null;
    }

    private static void lambda$buildAdminReport$17(StringBuilder arg0, String arg1, Integer arg2) {
    }

    private static void lambda$buildAdminReport$16(StringBuilder arg0, Map$Entry arg1) {
    }

    private static int lambda$buildAdminReport$15(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    private static void lambda$buildAdminReport$14(StringBuilder arg0, Map$Entry arg1) {
    }

    private static int lambda$buildAdminReport$13(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    private static void lambda$buildAdminReport$12(StringBuilder arg0, Map$Entry arg1) {
    }

    private static int lambda$buildAdminReport$11(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    private static void lambda$buildAdminReport$10(StringBuilder arg0, Map$Entry arg1) {
    }

    private static int lambda$buildAdminReport$9(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    private static void lambda$buildAdminReport$8(StringBuilder arg0, Map$Entry arg1) {
    }

    private static int lambda$buildAdminReport$7(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    private static void lambda$buildAdminReport$6(StringBuilder arg0, Map$Entry arg1) {
    }

    private static int lambda$buildAdminReport$5(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    private static void lambda$buildAdminReport$4(StringBuilder arg0, Map$Entry arg1) {
    }

    private static int lambda$buildAdminReport$3(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    private static void lambda$buildAdminReport$2(StringBuilder arg0, Map$Entry arg1) {
    }

    private static int lambda$buildAdminReport$1(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    private static void lambda$buildAdminReport$0(StringBuilder arg0, String arg1, Integer arg2) {
    }

    /* String constants found in bytecode:
       'scamFlags'
       'raidFlags'
       'currentTimeMillis'
       'displayName'
       'totalInteractions'
       'lastInteraction'
       'interests'
       'humorStyle'
       'formality'
       'preferredLength'
       'totalPlayTimeMs'
       'sessionsPlayed'
       'currentSessionStart'
       'longestSessionMs'
       'avgSessionLengthMs'
       'firstJoin'
       'lastLogout'
       'playTimeByHour'
       'playTimeByDay'
       'totalDeaths'
       'totalPlayerKills'
       'totalMobKills'
       'pvpLosses'
       'lastDeathCause'
       'mostKilledMob'
       'mostKilledMobCount'
       'totalBlocksPlaced'
       'totalBlocksBroken'
       'blocksPlacedByType'
       'blocksBrokenByType'
       'favoriteBlock'
       'favoriteTool'
       'totalItemsCrafted'
       'totalItemsEnchanted'
       'itemsCrafted'
       'itemsUsed'
       'favoriteItem'
       'distanceTraveled'
       'distanceFlown'
       'favoriteWorld'
    */
}