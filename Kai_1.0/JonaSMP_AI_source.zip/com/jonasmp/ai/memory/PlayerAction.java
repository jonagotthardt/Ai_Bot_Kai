package com.jonasmp.ai.memory;

public class PlayerAction {

    public long timestamp;
    public String type;
    public String details;
    public String world;
    public int x;
    public int y;
    public int z;

    public PlayerAction() {
        // TODO: decompile
    }

    public PlayerAction(String arg0, String arg1, String arg2, int arg3, int arg4, int arg5) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'timestamp'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'PlayerAction.java'
    */
}