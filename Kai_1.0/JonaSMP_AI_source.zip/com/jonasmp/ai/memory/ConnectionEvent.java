package com.jonasmp.ai.memory;

public class ConnectionEvent {

    public long timestamp;
    public String type;
    public long durationMs;

    public ConnectionEvent() {
        // TODO: decompile
    }

    public ConnectionEvent(String arg0, long arg1) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'timestamp'
       'durationMs'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'ConnectionEvent.java'
    */
}