package com.jonasmp.ai.bootstrap;

public class CoreBootstrap {

    public static ConfigManager CONFIG;
    public static AIGateway AI_GATEWAY;
    public static WebSearchTool WEB_SEARCH;
    public static ThreatScoreManager THREAT_MANAGER;
    public static ThreatDecayTask THREAT_DECAY_TASK;
    public static MemoryEngine MEMORY_ENGINE;
    public static PersonalityEngine PERSONALITY_ENGINE;
    public static MuteManager MUTE_MANAGER;
    public static BanHistoryManager BAN_HISTORY_MANAGER;
    public static FalsePositiveStore FALSE_POSITIVE_STORE;
    public static LastBlockedMessageStore LAST_BLOCKED_STORE;
    public static PlayerLanguageStore PLAYER_LANGUAGE_STORE;
    public static FirstJoinTracker FIRST_JOIN_TRACKER;
    public static WordlistLoader WORDLIST_LOADER;
    public static MessageCache MESSAGE_CACHE;
    public static ChatModerationPipeline MODERATION_PIPELINE;
    public static WatcherCore WATCHER;
    public static DeathMessageSystem DEATH_MESSAGES;
    public static DynamicShopBridge SHOP_BRIDGE;
    public static JavaPlugin PLUGIN;

    public CoreBootstrap() {
        // TODO: decompile
    }

    public static void init(JavaPlugin arg0) {
    }

    private static void lambda$init$0() {
    }

    /* String constants found in bytecode:
       'MEMORY_ENGINE'
       'THREAT_MANAGER'
       'getHuggingFaceApiKey'
       'getAIModel'
       'getAITimeout'
       'getOpenRouterApiKey'
       'getOpenRouterModel'
       'getOpenRouterTimeout'
       'AI_GATEWAY'
       'getLogger'
       'makeConcatWithConstants'
       'isWebSearchEnabled'
       'WEB_SEARCH'
       'setWebSearchTool'
       'getScheduler'
       'runTaskAsynchronously'
       'MUTE_MANAGER'
       'BAN_HISTORY_MANAGER'
       'getDataFolder'
       'FALSE_POSITIVE_STORE'
       'LAST_BLOCKED_STORE'
       'PERSONALITY_ENGINE'
       'WORDLIST_LOADER'
       'MESSAGE_CACHE'
       'getCacheTTL'
       'setDefaultTtl'
       'PLAYER_LANGUAGE_STORE'
       'FIRST_JOIN_TRACKER'
       'MODERATION_PIPELINE'
       'THREAT_DECAY_TASK'
       'getInstance'
       'DEATH_MESSAGES'
       'SHOP_BRIDGE'
       'getCategoryNames'
       'runOrHealthCheck'
       'LineNumberTable'
       'LocalVariableTable'
       'hfTimeout'
       'orTimeout'
       'StackMapTable'
    */
}