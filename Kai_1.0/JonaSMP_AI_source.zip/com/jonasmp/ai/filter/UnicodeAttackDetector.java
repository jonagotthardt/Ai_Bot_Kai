package com.jonasmp.ai.filter;

public class UnicodeAttackDetector {

    public UnicodeAttackDetector() {
        // TODO: decompile
    }

    public boolean detect(String arg0, double arg1) {
        return false;
    }

    private boolean isBidirectionalOverride(int arg0) {
        return false;
    }

    private boolean isCombiningMark(int arg0) {
        return false;
    }

    /* String constants found in bytecode:
       'codePointAt'
       'isBidirectionalOverride'
       'isCombiningMark'
       'LineNumberTable'
       'LocalVariableTable'
       'unicodeRiskScore'
       'StackMapTable'
       'SourceFile'
       'UnicodeAttackDetector.java'
    */
}