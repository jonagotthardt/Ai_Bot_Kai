package com.jonasmp.ai.filter;

public class CompoundWordDetector {

    public CompoundWordDetector() {
        // TODO: decompile
    }

    public boolean detect(String arg0, WordlistLoader arg1) {
        return false;
    }

    /* String constants found in bytecode:
       'getCategoryNames'
       'getCategory'
       'compounds'
       'LineNumberTable'
       'LocalVariableTable'
       'cleanedText'
       'LocalVariableTypeTable'
       'StackMapTable'
       'SourceFile'
       'CompoundWordDetector.java'
       'InnerClasses'
       'CompoundConfig'
    */
}