package com.jonasmp.ai.filter;

public class SplitWordDetector {

    private static final Pattern SPLIT_BY_WHITESPACE;
    private static final Pattern SPLIT_BY_PUNCT;
    private static final Pattern CAMEL_CASE;

    public SplitWordDetector() {
        // TODO: decompile
    }

    public boolean detect(String arg0, String arg1) {
        return false;
    }

    private boolean looksLikeBadWord(String arg0) {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'SPLIT_BY_WHITESPACE'
       'replaceAll'
       'looksLikeBadWord'
       'SPLIT_BY_PUNCT'
       'CAMEL_CASE'
       'toLowerCase'
       '.*f[cku].*'
       '.*s[hct].*'
       '.*a[s$].*'
       '.*b[tch].*'
       '.*d[ick].*'
       '.*n[gger].*'
       '.*h[ure].*'
       '.*w[ich].*'
       '.*sc[h]+.*'
       'LineNumberTable'
       'LocalVariableTable'
       'cleanedText'
       'StackMapTable'
       'SourceFile'
       'SplitWordDetector.java'
    */
}