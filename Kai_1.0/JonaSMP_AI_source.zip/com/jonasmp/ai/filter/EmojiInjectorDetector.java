package com.jonasmp.ai.filter;

public class EmojiInjectorDetector {

    public EmojiInjectorDetector() {
        // TODO: decompile
    }

    public boolean detect(String arg0) {
        return false;
    }

    private boolean isEmoji(int arg0) {
        return false;
    }

    /* String constants found in bytecode:
       'codePointAt'
       'charCount'
       '.*(.)\\1{4,}.*'
       'LineNumberTable'
       'LocalVariableTable'
       'emojiCount'
       'letterCount'
       'emojiBetweenLetters'
       'StackMapTable'
       'SourceFile'
       'EmojiInjectorDetector.java'
    */
}