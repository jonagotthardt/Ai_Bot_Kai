package com.jonasmp.ai.radar;

public class DeltaTracker$DeltaEntry {

    final Material material;
    final long timestamp;

     DeltaTracker$DeltaEntry(Material arg0, long arg1) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'timestamp'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'DeltaTracker.java'
       'InnerClasses'
       'DeltaEntry'
    */
}