package com.jonasmp.ai.radar;

public class ChunkCache$ChunkKey {

    public final int x;
    public final int z;

    public ChunkCache$ChunkKey(int arg0, int arg1) {
        // TODO: decompile
    }

    public boolean equals(Object arg0) {
        return false;
    }

    public int hashCode() {
        return 0;
    }

    public String toString() {
        return null;
    }

    /* String constants found in bytecode:
       'makeConcatWithConstants'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'ChunkCache.java'
       'BootstrapMethods'
       'InnerClasses'
    */
}