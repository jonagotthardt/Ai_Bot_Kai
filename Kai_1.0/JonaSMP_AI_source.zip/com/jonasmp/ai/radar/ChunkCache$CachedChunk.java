package com.jonasmp.ai.radar;

public class ChunkCache$CachedChunk {

    public final long loadedAt;
    private final Material[] blocks;
    private final int minY;
    private final int sectionHeight;

    public ChunkCache$CachedChunk(Material[] arg0, int arg1, int arg2) {
        // TODO: decompile
    }

    public Material getBlockType(int arg0, int arg1, int arg2) {
        return null;
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'sectionHeight'
       'LineNumberTable'
       'LocalVariableTable'
       'getBlockType'
       'StackMapTable'
       'SourceFile'
       'ChunkCache.java'
       'InnerClasses'
       'CachedChunk'
    */
}