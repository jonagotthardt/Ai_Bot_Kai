package com.jonasmp.ai.radar;

public class DeltaTracker implements Listener {

    private final Map deltas;
    private static final int MAX_ENTRIES;

    public DeltaTracker() {
        // TODO: decompile
    }

    public void onBlockBreak(BlockBreakEvent arg0) {
    }

    public void onBlockPlace(BlockPlaceEvent arg0) {
    }

    public Material getLiveMaterial(int arg0, int arg1, int arg2, String arg3) {
        return null;
    }

    public void invalidateChunk(String arg0, int arg1, int arg2) {
    }

    private String makeKey(Block arg0) {
        return null;
    }

    private void evictIfNeeded() {
    }

    private static boolean lambda$evictIfNeeded$0(long arg0, DeltaTracker$DeltaEntry arg1) {
        return false;
    }

    private static boolean lambda$invalidateChunk$0(String arg0, String arg1) {
        return false;
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'evictIfNeeded'
       'makeConcatWithConstants'
       'timestamp'
       'startsWith'
       'Signature'
       'MAX_ENTRIES'
       'ConstantValue'
       'LineNumberTable'
       'LocalVariableTable'
       'onBlockBreak'
       'RuntimeVisibleAnnotations'
       'ignoreCancelled'
       'onBlockPlace'
       'getLiveMaterial'
       'worldName'
       'StackMapTable'
       'invalidateChunk'
       'lambda$evictIfNeeded$0'
       'lambda$invalidateChunk$0'
       'SourceFile'
       'DeltaTracker.java'
       'NestMembers'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
       'DeltaEntry'
    */
}