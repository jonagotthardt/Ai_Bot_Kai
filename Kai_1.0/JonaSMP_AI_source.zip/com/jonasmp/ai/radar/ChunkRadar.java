package com.jonasmp.ai.radar;

public class ChunkRadar {

    private static final int RADAR_RADIUS_CHUNKS;
    private static final long REFRESH_INTERVAL_TICKS;
    private final ChunkCache cache;
    private final ChunkFileReader fileReader;
    private final DeltaTracker deltaTracker;
    private Player trackedBot;
    private int refreshTaskId;

    public ChunkRadar() {
        // TODO: decompile
    }

    public void startRefreshTask(Player arg0) {
    }

    public void stopRefreshTask() {
    }

    public Material getBlockType(int arg0, int arg1, int arg2, String arg3) {
        return null;
    }

    public Material getBlockType(Location arg0) {
        return null;
    }

    public List scanFor(Player arg0, Material arg1, int arg2) {
        return null;
    }

    public Location findNearestTree(Player arg0, int arg1) {
        return null;
    }

    public Location findNearestOre(Player arg0, Material arg1, int arg2) {
        return null;
    }

    public DeltaTracker getDeltaTracker() {
        return null;
    }

    public int getCacheSize() {
        return 0;
    }

    public double getCacheMemoryMb() {
        return 0.0;
    }

    public boolean isChunkCached(int arg0, int arg1) {
        return false;
    }

    private void refreshAroundBot() {
    }

    private static int lambda$scanFor$0(Location arg0, Location arg1, Location arg2) {
        return 0;
    }

    /* String constants found in bytecode:
       'trackedBot'
       'refreshTaskId'
       'fileReader'
       'deltaTracker'
       'getScheduler'
       'cancelTask'
       'runTaskTimerAsynchronously'
       'getTaskId'
       'getLogger'
       'makeConcatWithConstants'
       'getLiveMaterial'
       'getBlockType'
       'getBlockAt'
       'getBlockX'
       'getBlockY'
       'getBlockZ'
       'getLocation'
       'getMinHeight'
       'getMaxHeight'
       'BIRCH_LOG'
       'SPRUCE_LOG'
       'JUNGLE_LOG'
       'ACACIA_LOG'
       'DARK_OAK_LOG'
       'getEstimatedMemoryMb'
       'readChunk'
       'purgeExpired'
       'distanceSquared'
       'RADAR_RADIUS_CHUNKS'
       'ConstantValue'
       'REFRESH_INTERVAL_TICKS'
       'LineNumberTable'
       'LocalVariableTable'
       'startRefreshTask'
       'StackMapTable'
       'stopRefreshTask'
       'worldName'
       'radiusBlocks'
       'radiusChunks'
       'botChunkX'
    */
}