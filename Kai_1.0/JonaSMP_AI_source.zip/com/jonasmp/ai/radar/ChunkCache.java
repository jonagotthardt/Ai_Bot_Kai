package com.jonasmp.ai.radar;

public class ChunkCache {

    private static final long DEFAULT_TTL_MS;
    private static final int MAX_CHUNKS;
    private final ConcurrentHashMap cache;
    private final long ttlMs;

    public ChunkCache() {
        // TODO: decompile
    }

    public ChunkCache(long arg0) {
        // TODO: decompile
    }

    public Material getBlockType(int arg0, int arg1, int arg2) {
        return null;
    }

    public void put(int arg0, int arg1, ChunkCache$CachedChunk arg2) {
    }

    private void evictOldest() {
    }

    public boolean isCached(int arg0, int arg1) {
        return false;
    }

    public void invalidate(int arg0, int arg1) {
    }

    public int purgeExpired() {
        return 0;
    }

    public int size() {
        return 0;
    }

    public double getEstimatedMemoryMb() {
        return 0.0;
    }

    private boolean isExpired(ChunkCache$CachedChunk arg0) {
        return false;
    }

    /* String constants found in bytecode:
       'isExpired'
       'getBlockType'
       'evictOldest'
       'currentTimeMillis'
       'DEFAULT_TTL_MS'
       'ConstantValue'
       'MAX_CHUNKS'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'oldestKey'
       'oldestTime'
       'LocalVariableTypeTable'
       'invalidate'
       'purgeExpired'
       'getEstimatedMemoryMb'
       'SourceFile'
       'ChunkCache.java'
       'NestMembers'
       'InnerClasses'
       'CachedChunk'
    */
}