package com.jonasmp.ai.radar;

public class ChunkFileReader {

    public ChunkFileReader() {
        // TODO: decompile
    }

    public ChunkCache$CachedChunk readChunk(World arg0, int arg1, int arg2) {
        return null;
    }

    /* String constants found in bytecode:
       'isChunkLoaded'
       'getChunkAt'
       'getMinHeight'
       'getMaxHeight'
       'getLogger'
       'getMessage'
       'makeConcatWithConstants'
       'LineNumberTable'
       'LocalVariableTable'
       'readChunk'
       'sectionHeight'
       'StackMapTable'
       'SourceFile'
       'ChunkFileReader.java'
       'BootstrapMethods'
       'InnerClasses'
       'CachedChunk'
    */
}