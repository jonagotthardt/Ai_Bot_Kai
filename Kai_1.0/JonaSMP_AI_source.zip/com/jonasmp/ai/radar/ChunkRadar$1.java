package com.jonasmp.ai.radar;

public class ChunkRadar$1 extends BukkitRunnable {

    final ChunkRadar this$0;

     ChunkRadar$1(ChunkRadar arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'trackedBot'
       'refreshAroundBot'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'ChunkRadar.java'
       'EnclosingMethod'
       'startRefreshTask'
       'InnerClasses'
    */
}