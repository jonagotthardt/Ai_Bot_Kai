package com.jonasmp.ai.commands;

public class AICommands implements CommandExecutor, TabCompleter {

    private final MuteManager muteManager;

    public AICommands(MuteManager arg0) {
        // TODO: decompile
    }

    public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
        return false;
    }

    private void handleMute(CommandSender arg0, String[] arg1) {
    }

    private void handleUnmute(CommandSender arg0, String[] arg1) {
    }

    private void handleUnban(CommandSender arg0, String[] arg1) {
    }

    private void handleTrain(CommandSender arg0) {
    }

    private void handleStats(CommandSender arg0) {
    }

    private void handleStatus(CommandSender arg0, String[] arg1) {
    }

    private void handleRules(CommandSender arg0, String[] arg1) {
    }

    private void handleReload(CommandSender arg0) {
    }

    private void handleDebug(CommandSender arg0, String[] arg1) {
    }

    private void handleVoice(CommandSender arg0, String[] arg1) {
    }

    private void handleVoiceStatus(CommandSender arg0) {
    }

    private void handleVoiceDebug(CommandSender arg0) {
    }

    private void handleVoiceToggle(CommandSender arg0) {
    }

    private void handleVoiceMute(CommandSender arg0, String[] arg1) {
    }

    private void handleVoiceUnmute(CommandSender arg0, String[] arg1) {
    }

    private void handleVoiceLogs(CommandSender arg0, String[] arg1) {
    }

    private void handleFalsePositive(CommandSender arg0, String[] arg1) {
    }

    private void handleLanguage(CommandSender arg0, String[] arg1) {
    }

    private void handleChat(CommandSender arg0, String[] arg1) {
    }

    private void handleDirectChat(CommandSender arg0, String arg1, boolean arg2) {
    }

    private boolean mightNeedWebSearch(String arg0) {
        return false;
    }

    private void doChatWithOptionalWebSearch(CommandSender arg0, String arg1, String arg2, String arg3, boolean arg4) {
    }

    private String extractPlayerName(String arg0) {
        return null;
    }

    private void sendHelp(CommandSender arg0) {
    }

    private String formatDuration(long arg0) {
        return null;
    }

    public List onTabComplete(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
        return null;
    }

    private void handleRadar(CommandSender arg0) {
    }

    private List filterSuggestions(List arg0, String arg1) {
        return null;
    }

    private List playerNames(String arg0) {
        return null;
    }

    private static void lambda$doChatWithOptionalWebSearch$0(boolean arg0, String arg1, StringBuilder arg2, String arg3, String arg4, CommandSender arg5) {
    }

    private static void lambda$doChatWithOptionalWebSearch$1(String arg0, boolean arg1, String arg2, CommandSender arg3) {
    }

    private static void lambda$handleChat$0(Player arg0, String arg1, String arg2, CommandSender arg3) {
    }

    private static void lambda$handleChat$1(String arg0, String arg1, CommandSender arg2) {
    }

    private static void lambda$handleStats$0(CommandSender arg0) {
    }

    private static void lambda$handleStats$1(Map arg0, CommandSender arg1) {
    }

    private static void lambda$handleTrain$0(CommandSender arg0) {
    }

    private static void lambda$handleTrain$1(boolean arg0, CommandSender arg1) {
    }

    /* String constants found in bytecode:
       'muteManager'
       'equalsIgnoreCase'
       'handleRadar'
       'jonasmpai.chat.query'
       'hasPermission'
       "§cYou don't have permission to use AI chat!"
       'sendMessage'
       'copyOfRange'
       'handleDirectChat'
       'toLowerCase'
       'handleLanguage'
       'falsepositive'
       'jonasmpai.falsepositive'
       "§cYou don't have permission to report false positives!"
       'handleFalsePositive'
       'handleChat'
       'jonasmpai.admin.status'
       "§cYou don't have permission!"
       'handleStatus'
       'jonasmpai.admin.moderate'
       "§cYou don't have permission to moderate!"
       'handleMute'
       'handleUnmute'
       'handleUnban'
       'jonasmpai.admin.stats'
       "§cYou don't have permission to view AI stats!"
       'handleStats'
       'jonasmpai.admin.train'
       "§cYou don't have permission to train the AI!"
       'handleTrain'
       'jonasmpai.admin.reload'
       "§cYou don't have permission to reload!"
       'handleReload'
       'jonasmpai.rules.reset'
       "§cYou don't have permission to manage rules!"
       'handleRules'
       'jonasmpai.admin.voice'
       "§cYou don't have permission to manage voice chat moderation!"
       'handleVoice'
       'jonasmpai.admin.debug'
    */
}