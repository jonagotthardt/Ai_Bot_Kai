package com.jonasmp.ai.threat;

public class PlayerThreatProfile {

    private final UUID uuid;
    private double threatScore;

    public PlayerThreatProfile(UUID arg0) {
        // TODO: decompile
    }

    public UUID getUuid() {
        return null;
    }

    public double getThreatScore() {
        return 0.0;
    }

    public void addThreat(double arg0) {
    }

    public void reduceThreat(double arg0) {
    }

    /* String constants found in bytecode:
       'threatScore'
       'LineNumberTable'
       'LocalVariableTable'
       'getThreatScore'
       'addThreat'
       'StackMapTable'
       'reduceThreat'
       'SourceFile'
       'PlayerThreatProfile.java'
    */
}