package com.jonasmp.ai.threat;

public class ThreatDecayTask$1 extends BukkitRunnable {

    final ThreatDecayTask this$0;

     ThreatDecayTask$1(ThreatDecayTask arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    private void lambda$run$0(ThreatScoreManager arg0, Player arg1) {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'THREAT_MANAGER'
       'getOnlinePlayers'
       'getUniqueId'
       'calculateDecay'
       'reduceThreat'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'lambda$run$0'
       'StackMapTable'
       'SourceFile'
       'ThreatDecayTask.java'
       'EnclosingMethod'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
    */
}