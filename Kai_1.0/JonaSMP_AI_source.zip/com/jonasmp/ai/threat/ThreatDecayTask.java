package com.jonasmp.ai.threat;

public class ThreatDecayTask {

    public ThreatDecayTask() {
        // TODO: decompile
    }

    public void start() {
    }

    private double calculateDecay(double arg0) {
        return 0.0;
    }

    /* String constants found in bytecode:
       'runTaskTimer'
       'LineNumberTable'
       'LocalVariableTable'
       'calculateDecay'
       'StackMapTable'
       'SourceFile'
       'ThreatDecayTask.java'
       'NestMembers'
       'InnerClasses'
    */
}