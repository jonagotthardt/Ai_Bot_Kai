package com.jonasmp.ai.threat;

public class ThreatScoreManager {

    private final HashMap profiles;
    private final File file;
    private final YamlConfiguration config;
    private final JavaPlugin plugin;

    public ThreatScoreManager(JavaPlugin arg0) {
        // TODO: decompile
    }

    private void load() {
    }

    public void save() {
    }

    public PlayerThreatProfile getProfile(UUID arg0) {
        return null;
    }

    public void addThreat(UUID arg0, double arg1) {
    }

    public void reduceThreat(UUID arg0, double arg1) {
    }

    public double getScore(UUID arg0) {
        return 0.0;
    }

    public boolean isDangerous(UUID arg0) {
        return false;
    }

    public double getThreat(UUID arg0) {
        return 0.0;
    }

    /* String constants found in bytecode:
       'getDataFolder'
       'threats.yml'
       'getParentFile'
       'createNewFile'
       'printStackTrace'
       'loadConfiguration'
       'fromString'
       'getDouble'
       'addThreat'
       'computeIfAbsent'
       'getProfile'
       'reduceThreat'
       'getThreatScore'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'isDangerous'
       'getThreat'
       'SourceFile'
       'ThreatScoreManager.java'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
    */
}