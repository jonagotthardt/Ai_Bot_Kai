package com.jonasmp.ai.scoreboard;

public class DynamicScoreboardManager {

    public DynamicScoreboardManager() {
        // TODO: decompile
    }

    public void start() {
    }

    public void stop() {
    }

    public void onPlayerJoin(Player arg0) {
    }

    public void onPlayerQuit(Player arg0) {
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'onPlayerJoin'
       'onPlayerQuit'
       'SourceFile'
       'DynamicScoreboardManager.java'
    */
}