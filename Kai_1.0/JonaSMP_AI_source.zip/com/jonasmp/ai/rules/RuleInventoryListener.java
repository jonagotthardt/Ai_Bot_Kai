package com.jonasmp.ai.rules;

public class RuleInventoryListener implements Listener {

    private static final String GUI_TITLE;

    public RuleInventoryListener() {
        // TODO: decompile
    }

    public void onInventoryClick(InventoryClickEvent arg0) {
    }

    private static void lambda$onInventoryClick$0(Player arg0) {
    }

    /* String constants found in bytecode:
       'getWhoClicked'
       'getClickedInventory'
       'setCancelled'
       'getCurrentItem'
       'getItemMeta'
       'getDisplayName'
       'FIRST_JOIN_TRACKER'
       'getUniqueId'
       'setAccepted'
       'closeInventory'
       '§a§lRegeln akzeptiert! Willkommen auf Yona SMP!'
       'sendMessage'
       '§7§lRules accepted! Welcome to Yona SMP!'
       'getScheduler'
       'runTaskLater'
       'GUI_TITLE'
       'ConstantValue'
       'LineNumberTable'
       'LocalVariableTable'
       'onInventoryClick'
       'whoClicked'
       'StackMapTable'
       'RuntimeVisibleAnnotations'
       'lambda$onInventoryClick$0'
       'SourceFile'
       'RuleInventoryListener.java'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
    */
}