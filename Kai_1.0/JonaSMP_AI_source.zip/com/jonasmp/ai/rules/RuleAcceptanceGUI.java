package com.jonasmp.ai.rules;

public class RuleAcceptanceGUI {

    private static final String TITLE;

    public RuleAcceptanceGUI() {
        // TODO: decompile
    }

    public static void open(Player arg0) {
    }

    private static ItemStack createRuleItem(Material arg0, String arg1, List arg2) {
        return null;
    }

    /* String constants found in bytecode:
       'createInventory'
       '§e§l1. Respektiere alle Spieler'
       '§7Beleidigungen, Hassrede und'
       '§7Mobbing werden nicht toleriert.'
       '§7Verwarnung bis BAN.'
       '§7Respect all players. No insults,'
       '§7hate speech or harassment.'
       'createRuleItem'
       '§7Keine unerlaubten Modifikationen'
       '§7und kein Zerstören fremder Bauten.'
       '§7Permanenter BAN.'
       "§7No cheating or griefing others' builds."
       '§7Permanent BAN.'
       '§7Wiederholtes Spamming und'
       '§7Werbung für andere Server ist'
       '§7verboten. Kick bis Mute.'
       '§7No spamming or advertising.'
       '§7Kick to Mute.'
       '§e§l4. AFK-Regeln beachten'
       '§7AFK-Farmen sind erlaubt, aber'
       '§7bitte lagfrei halten.'
       '§7Auto-Clicker sind verboten.'
       '§7AFK farms allowed, keep it lag-free.'
       '§7Auto-clickers forbidden.'
       '§e§l5. Chat-Moderation aktiv'
       '§7KI-gestützte Chat-Moderation'
       '§7ist aktiv. Beleidigungen werden'
       '§7automatisch erkannt.'
       '§7AI chat moderation is active.'
       '§7Insults are auto-detected.'
       '§e§l6. Admin hat letztes Wort'
       '§7Admins entscheiden in Streitfällen.'
       '§7Diskussionen per Discord.'
       '§7Entscheidungen sind endgültig.'
       '§7Admin decisions are final.'
       '§7Discuss via Discord.'
       'LIME_WOOL'
       'getItemMeta'
       'setDisplayName'
       '§7Klicke hier, um die Regeln zu akzeptieren'
    */
}