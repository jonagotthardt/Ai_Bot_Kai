package com.jonasmp.ai.rules;

public class FirstJoinTracker {

    private final File file;
    private FileConfiguration config;

    public FirstJoinTracker() {
        // TODO: decompile
    }

    public boolean hasAccepted(UUID arg0) {
        return false;
    }

    public void setAccepted(UUID arg0) {
    }

    public void resetPlayer(UUID arg0) {
    }

    private void save() {
    }

    /* String constants found in bytecode:
       'getDataFolder'
       'player_rules_accepted.yml'
       'createNewFile'
       'getLogger'
       'loadConfiguration'
       'getBoolean'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'hasAccepted'
       'setAccepted'
       'resetPlayer'
       'SourceFile'
       'FirstJoinTracker.java'
    */
}