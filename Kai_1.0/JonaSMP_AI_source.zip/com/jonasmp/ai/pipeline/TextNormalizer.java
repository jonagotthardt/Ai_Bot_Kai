package com.jonasmp.ai.pipeline;

public class TextNormalizer {

    public TextNormalizer() {
        // TODO: decompile
    }

    public String normalize(String arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'normalize'
       'replaceAll'
       'toLowerCase'
       'LineNumberTable'
       'LocalVariableTable'
       'normalized'
       'StackMapTable'
       'SourceFile'
       'TextNormalizer.java'
       'InnerClasses'
    */
}