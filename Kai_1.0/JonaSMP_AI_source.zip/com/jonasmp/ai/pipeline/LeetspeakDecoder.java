package com.jonasmp.ai.pipeline;

public class LeetspeakDecoder {

    private static final Map LEET_MAP;

    public LeetspeakDecoder() {
        // TODO: decompile
    }

    public String decode(String arg0) {
        return null;
    }

    private static int lambda$decode$0(Map$Entry arg0, Map$Entry arg1) {
        return 0;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'LocalVariableTypeTable'
       'StackMapTable'
       'lambda$decode$0'
       'SourceFile'
       'LeetspeakDecoder.java'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
    */
}