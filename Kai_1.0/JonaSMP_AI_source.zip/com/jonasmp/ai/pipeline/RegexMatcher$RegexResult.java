package com.jonasmp.ai.pipeline;

public class RegexMatcher$RegexResult {

    public static final RegexMatcher$RegexResult EMPTY;
    public final String category;
    public final List matchedPatterns;
    public final double score;
    public final String severity;

    public RegexMatcher$RegexResult(String arg0, List arg1, double arg2, String arg3) {
        // TODO: decompile
    }

    public boolean isEmpty() {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'matchedPatterns'
       'emptyList'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'LocalVariableTypeTable'
       'StackMapTable'
       'SourceFile'
       'RegexMatcher.java'
       'InnerClasses'
       'RegexResult'
    */
}