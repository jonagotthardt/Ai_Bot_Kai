package com.jonasmp.ai.pipeline;

public class CategoryScorer$ScoreResult {

    public final Map categoryScores;
    public final Map matches;
    public final double totalRisk;
    public final String primaryCategory;
    public final String recommendedAction;

    public CategoryScorer$ScoreResult(Map arg0, Map arg1, double arg2, String arg3, String arg4) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'unmodifiableMap'
       'categoryScores'
       'totalRisk'
       'primaryCategory'
       'recommendedAction'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'LocalVariableTypeTable'
       'SourceFile'
       'CategoryScorer.java'
       'InnerClasses'
       'ScoreResult'
    */
}