package com.jonasmp.ai.pipeline;

public class SafeWordFilter {

    private final Set safeWords;

    public SafeWordFilter(WordlistLoader arg0) {
        // TODO: decompile
    }

    public boolean isSafe(String arg0) {
        return false;
    }

    public boolean isSafeWord(String arg0) {
        return false;
    }

    /* String constants found in bytecode:
       'safeWords'
       'safewords'
       'getCategory'
       'toLowerCase'
       'replaceAll'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'safeCount'
       'totalMeaningful'
       'isSafeWord'
       'SourceFile'
       'SafeWordFilter.java'
    */
}