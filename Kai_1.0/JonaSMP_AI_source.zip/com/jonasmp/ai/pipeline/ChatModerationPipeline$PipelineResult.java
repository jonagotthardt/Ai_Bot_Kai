package com.jonasmp.ai.pipeline;

public class ChatModerationPipeline$PipelineResult {

    public final DecisionResult$Action action;
    public final double score;
    public final String reason;
    public final String category;
    public final boolean escalateToBan;
    public final long processingTimeMs;
    public final ChatModerationPipeline$DetectionFlags flags;

    public ChatModerationPipeline$PipelineResult(DecisionResult$Action arg0, double arg1, String arg2, String arg3, boolean arg4, long arg5, ChatModerationPipeline$DetectionFlags arg6) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'escalateToBan'
       'processingTimeMs'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'ChatModerationPipeline.java'
       'InnerClasses'
       'PipelineResult'
       'DetectionFlags'
    */
}