package com.jonasmp.ai.pipeline;

public class RegexMatcher {

    private final WordlistLoader loader;

    public RegexMatcher(WordlistLoader arg0) {
        // TODO: decompile
    }

    public Map matchAll(String arg0) {
        return null;
    }

    public RegexMatcher$RegexResult matchCategory(String arg0, String arg1) {
        return null;
    }

    /* String constants found in bytecode:
       'getCategoryNames'
       'getPatterns'
       'getCompoundPattern'
       'getCategory'
       'score_per_hit'
       'max_score'
       'LineNumberTable'
       'LocalVariableTable'
       'LocalVariableTypeTable'
       'StackMapTable'
       'Signature'
       'matchCategory'
       'SourceFile'
       'RegexMatcher.java'
       'NestMembers'
       'InnerClasses'
       'RegexResult'
    */
}