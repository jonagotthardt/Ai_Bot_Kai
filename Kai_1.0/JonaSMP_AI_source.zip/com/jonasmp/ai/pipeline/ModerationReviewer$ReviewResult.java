package com.jonasmp.ai.pipeline;

public class ModerationReviewer$ReviewResult extends Enum {

    public static final ModerationReviewer$ReviewResult OVERRIDE_ALLOW;
    public static final ModerationReviewer$ReviewResult OVERRIDE_WARN;
    public static final ModerationReviewer$ReviewResult OVERRIDE_BLOCK;
    public static final ModerationReviewer$ReviewResult NO_CHANGE;
    private static final ModerationReviewer$ReviewResult[] $VALUES;

    public static ModerationReviewer$ReviewResult[] values() {
        return null;
    }

    public static ModerationReviewer$ReviewResult valueOf(String arg0) {
        return null;
    }

    private ModerationReviewer$ReviewResult(String arg0, int arg1) {
        // TODO: decompile
    }

    private static ModerationReviewer$ReviewResult[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'OVERRIDE_ALLOW'
       'OVERRIDE_WARN'
       'OVERRIDE_BLOCK'
       'NO_CHANGE'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'ModerationReviewer.java'
       'InnerClasses'
       'ReviewResult'
    */
}