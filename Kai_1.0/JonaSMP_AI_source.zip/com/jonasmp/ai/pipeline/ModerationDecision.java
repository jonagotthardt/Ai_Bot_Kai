package com.jonasmp.ai.pipeline;

public class ModerationDecision {

    private double blockThreshold;
    private double warnThreshold;
    private double banThreshold;
    private double kickThreshold;
    private double muteThreshold;

    public ModerationDecision() {
        // TODO: decompile
    }

    public void setThresholds(double arg0, double arg1, double arg2, double arg3, double arg4) {
    }

    public ModerationDecision$Decision decide(CategoryScorer$ScoreResult arg0, Double arg1, Double arg2, double arg3) {
        return null;
    }

    private String buildReason(CategoryScorer$ScoreResult arg0, double arg1, double arg2) {
        return null;
    }

    /* String constants found in bytecode:
       'blockThreshold'
       'warnThreshold'
       'banThreshold'
       'kickThreshold'
       'muteThreshold'
       'doubleValue'
       'totalRisk'
       'primaryCategory'
       'buildReason'
       'recommendedAction'
       'equalsIgnoreCase'
       'makeConcatWithConstants'
       'Safe message'
       ' Toxicity:'
       'LineNumberTable'
       'LocalVariableTable'
       'setThresholds'
       'localScore'
       'backendToxicity'
       'backendScam'
       'playerThreat'
       'finalRisk'
       'StackMapTable'
       'LocalVariableTypeTable'
       'SourceFile'
       'ModerationDecision.java'
       'NestMembers'
       'BootstrapMethods'
       '\x01 [repeat offender]'
       'InnerClasses'
       'ScoreResult'
    */
}