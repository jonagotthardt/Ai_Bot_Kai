package com.jonasmp.ai.pipeline;

public class TypoCorrector {

    private final WordlistLoader loader;
    private final Set safeWords;

    public TypoCorrector(WordlistLoader arg0) {
        // TODO: decompile
    }

    public String correct(String arg0) {
        return null;
    }

    private String findBestMatch(String arg0) {
        return null;
    }

    private int getThreshold(int arg0) {
        return 0;
    }

    private void replaceIgnoreCase(StringBuilder arg0, String arg1, String arg2) {
    }

    public static int damerauLevenshtein(String arg0, String arg1) {
        return 0;
    }

    /* String constants found in bytecode:
       'safewords'
       'getCategory'
       'toLowerCase'
       'safeWords'
       'findBestMatch'
       'equalsIgnoreCase'
       'replaceIgnoreCase'
       'getThreshold'
       'getCategoryNames'
       'damerauLevenshtein'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'LocalVariableTypeTable'
       'StackMapTable'
       'bestMatch'
       'corrected'
       'threshold'
       'bestDistance'
       'wordLength'
       'replacement'
       'SourceFile'
       'TypoCorrector.java'
    */
}