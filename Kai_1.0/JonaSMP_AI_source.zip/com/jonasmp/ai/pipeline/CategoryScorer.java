package com.jonasmp.ai.pipeline;

public class CategoryScorer {

    private final WordlistLoader loader;

    public CategoryScorer(WordlistLoader arg0) {
        // TODO: decompile
    }

    public CategoryScorer$ScoreResult score(String arg0, String arg1, Map arg2, Map arg3) {
        return null;
    }

    /* String constants found in bytecode:
       'matchedWords'
       'matchedPatterns'
       'getCategory'
       'context_boosters'
       'toLowerCase'
       'insult_phrases'
       'max_score'
       'makeConcatWithConstants'
       'doubleValue'
       'LineNumberTable'
       'LocalVariableTable'
       'originalText'
       'processedText'
       'wordlistHits'
       'regexHits'
       'categoryScores'
       'allMatches'
       'allCategories'
       'totalRisk'
       'primaryCategory'
       'primaryConfig'
       'LocalVariableTypeTable'
       'StackMapTable'
       'Signature'
       'SourceFile'
       'CategoryScorer.java'
       'NestMembers'
       'BootstrapMethods'
       'InnerClasses'
       'MatchResult'
       'RegexResult'
       'ContextBoost'
       'ScoreResult'
    */
}