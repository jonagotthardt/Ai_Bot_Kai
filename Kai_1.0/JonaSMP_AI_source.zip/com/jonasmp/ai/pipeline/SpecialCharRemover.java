package com.jonasmp.ai.pipeline;

public class SpecialCharRemover {

    private static final Pattern PUNCTUATION_SPACER;
    private static final Pattern REPEATED_SPECIAL;
    private static final Pattern WHITESPACE_NORMALIZER;

    public SpecialCharRemover() {
        // TODO: decompile
    }

    public String clean(String arg0) {
        return null;
    }

    public String aggressiveClean(String arg0) {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'PUNCTUATION_SPACER'
       'replaceAll'
       'REPEATED_SPECIAL'
       'WHITESPACE_NORMALIZER'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'aggressiveClean'
       'SourceFile'
       'SpecialCharRemover.java'
    */
}