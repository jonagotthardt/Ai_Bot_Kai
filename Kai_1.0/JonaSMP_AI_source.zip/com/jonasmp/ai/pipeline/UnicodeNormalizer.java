package com.jonasmp.ai.pipeline;

public class UnicodeNormalizer {

    public UnicodeNormalizer() {
        // TODO: decompile
    }

    public double detectUnicodeAttack(String arg0) {
        return 0.0;
    }

    public String replaceHomoglyphs(String arg0) {
        return null;
    }

    private boolean isCyrillicHomoglyph(char arg0) {
        return false;
    }

    private boolean isGreekHomoglyph(char arg0) {
        return false;
    }

    private boolean isRareBlock(int arg0) {
        return false;
    }

    private char mapHomoglyph(char arg0) {
        return 0;
    }

    /* String constants found in bytecode:
       'codePointAt'
       'isCyrillicHomoglyph'
       'isGreekHomoglyph'
       'isRareBlock'
       'toCharArray'
       'mapHomoglyph'
       'LineNumberTable'
       'LocalVariableTable'
       'detectUnicodeAttack'
       'suspicious'
       'StackMapTable'
       'replaceHomoglyphs'
       'SourceFile'
       'UnicodeNormalizer.java'
    */
}