package com.jonasmp.ai.pipeline;

public class ModerationDecision$Decision {

    public final DecisionResult$Action action;
    public final double score;
    public final String reason;
    public final String category;
    public final boolean escalateToBan;

    public ModerationDecision$Decision(DecisionResult$Action arg0, double arg1, String arg2, String arg3, boolean arg4) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'escalateToBan'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'ModerationDecision.java'
       'InnerClasses'
    */
}