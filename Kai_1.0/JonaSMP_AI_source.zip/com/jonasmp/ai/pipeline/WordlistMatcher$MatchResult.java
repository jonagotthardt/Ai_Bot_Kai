package com.jonasmp.ai.pipeline;

public class WordlistMatcher$MatchResult {

    public static final WordlistMatcher$MatchResult EMPTY;
    public final String category;
    public final List matchedWords;
    public final double score;
    public final String severity;

    public WordlistMatcher$MatchResult(String arg0, List arg1, double arg2, String arg3) {
        // TODO: decompile
    }

    public boolean isEmpty() {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'matchedWords'
       'emptyList'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'LocalVariableTypeTable'
       'StackMapTable'
       'SourceFile'
       'WordlistMatcher.java'
       'InnerClasses'
       'MatchResult'
    */
}