package com.jonasmp.ai.pipeline;

public class WordlistMatcher {

    private final WordlistLoader loader;

    public WordlistMatcher(WordlistLoader arg0) {
        // TODO: decompile
    }

    public Map matchAll(String arg0) {
        return null;
    }

    private int countWholeWordMatches(String arg0, String arg1) {
        return 0;
    }

    public WordlistMatcher$MatchResult matchCategory(String arg0, String arg1) {
        return null;
    }

    public boolean hasAnyMatch(String arg0) {
        return false;
    }

    /* String constants found in bytecode:
       'toLowerCase'
       'getCategoryNames'
       'safewords'
       'getCategory'
       'countWholeWordMatches'
       'score_per_hit'
       'max_score'
       'isLetterOrDigit'
       'LineNumberTable'
       'LocalVariableTable'
       'wholeWordCount'
       'validMatches'
       'LocalVariableTypeTable'
       'StackMapTable'
       'Signature'
       'leftBoundary'
       'rightBoundary'
       'matchCategory'
       'hasAnyMatch'
       'SourceFile'
       'WordlistMatcher.java'
       'NestMembers'
       'InnerClasses'
       'MatchResult'
    */
}