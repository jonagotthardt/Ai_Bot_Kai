package com.jonasmp.ai.pipeline;

public class ChatModerationPipeline$DetectionFlags {

    public final boolean obfuscation;
    public final boolean unicodeAttack;
    public final boolean emojiInjection;
    public final boolean splitWords;
    public final boolean compoundWords;

    public ChatModerationPipeline$DetectionFlags(boolean arg0, boolean arg1, boolean arg2, boolean arg3, boolean arg4) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'obfuscation'
       'unicodeAttack'
       'emojiInjection'
       'splitWords'
       'compoundWords'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'ChatModerationPipeline.java'
       'InnerClasses'
       'DetectionFlags'
    */
}