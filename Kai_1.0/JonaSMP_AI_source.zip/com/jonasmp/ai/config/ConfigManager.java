package com.jonasmp.ai.config;

public class ConfigManager {

    private final JavaPlugin plugin;

    public ConfigManager(JavaPlugin arg0) {
        // TODO: decompile
    }

    public void init() {
    }

    public boolean isAIEnabled() {
        return false;
    }

    public int getAITimeout() {
        return 0;
    }

    public double getBlockThreshold() {
        return 0.0;
    }

    public double getWarnThreshold() {
        return 0.0;
    }

    public String getBackendUrl() {
        return null;
    }

    public String getHuggingFaceApiKey() {
        return null;
    }

    public String getGroqApiKey() {
        return null;
    }

    public String getAIProvider() {
        return null;
    }

    public String getAIModel() {
        return null;
    }

    public boolean isWebSearchEnabled() {
        return false;
    }

    public boolean isDirectOpenRouterEnabled() {
        return false;
    }

    public String getOpenRouterApiKey() {
        return null;
    }

    public String getOpenRouterModel() {
        return null;
    }

    public int getOpenRouterTimeout() {
        return 0;
    }

    public boolean isCacheEnabled() {
        return false;
    }

    public boolean isPhysicalMemoryWarningEnabled() {
        return false;
    }

    public int getCacheTTL() {
        return 0;
    }

    public double getPipelineBlockThreshold() {
        return 0.0;
    }

    public double getPipelineWarnThreshold() {
        return 0.0;
    }

    public double getPipelineBanThreshold() {
        return 0.0;
    }

    public double getPipelineKickThreshold() {
        return 0.0;
    }

    public double getPipelineMuteThreshold() {
        return 0.0;
    }

    public boolean isLocalPipelineEnabled() {
        return false;
    }

    public boolean isBackendFallbackEnabled() {
        return false;
    }

    public boolean isTeacherModeEnabled() {
        return false;
    }

    public boolean isPublicShamingEnabled() {
        return false;
    }

    public int getVoiceKickStrikes() {
        return 0;
    }

    public int getVoiceStrikeDecayMinutes() {
        return 0;
    }

    /* String constants found in bytecode:
       'saveDefaultConfig'
       'reloadConfig'
       'getConfig'
       'copyDefaults'
       'saveConfig'
       'getLogger'
       'ai.enabled'
       'getBoolean'
       'ai.timeout_ms'
       'moderation.block_threshold'
       'getDouble'
       'moderation.warn_threshold'
       'ai.backend_url'
       'getString'
       'ai.huggingface_api_key'
       'ai.groq_api_key'
       'ai.provider'
       'huggingface'
       'ai.web_search.enabled'
       'ai.direct_openrouter_enabled'
       'ai.openrouter_api_key'
       'ai.openrouter_model'
       'ai.openrouter_timeout_ms'
       'performance.enable_cache'
       'performance.physical_memory_warning'
       'performance.cache_ttl_seconds'
       'pipeline.block_threshold'
       'pipeline.warn_threshold'
       'pipeline.ban_threshold'
       'pipeline.kick_threshold'
       'pipeline.mute_threshold'
       'pipeline.local_enabled'
       'pipeline.backend_fallback'
       'teacher_mode.enabled'
       'teacher_mode.public_shaming'
       'voice_moderation.kick_after_strikes'
       'voice_moderation.strike_decay_minutes'
       'LineNumberTable'
       'LocalVariableTable'
       'isAIEnabled'
    */
}