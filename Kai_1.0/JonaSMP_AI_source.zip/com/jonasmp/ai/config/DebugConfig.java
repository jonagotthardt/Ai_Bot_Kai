package com.jonasmp.ai.config;

public class DebugConfig {

    private static boolean debugEnabled;
    private static boolean voiceDebugEnabled;

    public DebugConfig() {
        // TODO: decompile
    }

    public static boolean isDebugEnabled() {
        return false;
    }

    public static void setDebugEnabled(boolean arg0) {
    }

    public static boolean isVoiceDebugEnabled() {
        return false;
    }

    public static void setVoiceDebugEnabled(boolean arg0) {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'debugEnabled'
       'voiceDebugEnabled'
       'LineNumberTable'
       'LocalVariableTable'
       'isDebugEnabled'
       'setDebugEnabled'
       'isVoiceDebugEnabled'
       'setVoiceDebugEnabled'
       'SourceFile'
       'DebugConfig.java'
    */
}