package com.jonasmp.ai.wordlist;

public class CategoryConfig$CompoundConfig {

    public List prefixes;
    public List suffixes;

    public CategoryConfig$CompoundConfig() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'CategoryConfig.java'
       'InnerClasses'
       'CompoundConfig'
    */
}