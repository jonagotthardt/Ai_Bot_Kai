package com.jonasmp.ai.wordlist;

public class CategoryConfig$ContextBoost {

    public List insult_phrases;
    public double boost;

    public CategoryConfig$ContextBoost() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'insult_phrases'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'CategoryConfig.java'
       'InnerClasses'
       'ContextBoost'
    */
}