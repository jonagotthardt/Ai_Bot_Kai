package com.jonasmp.ai.wordlist;

public class WordlistLoader {

    private static final Gson GSON;
    private static final String WORDLIST_DIR;
    private final Map categories;
    private final Map tries;
    private final Map regexPatterns;
    private final Map compoundPatterns;

    public WordlistLoader() {
        // TODO: decompile
    }

    public void load() {
    }

    private CategoryConfig mergeConfigs(List arg0) {
        return null;
    }

    private void copyDefaultsFromJar(File arg0) {
    }

    public CategoryConfig getCategory(String arg0) {
        return null;
    }

    public Trie getTrie(String arg0) {
        return null;
    }

    public List getPatterns(String arg0) {
        return null;
    }

    public Pattern getCompoundPattern(String arg0) {
        return null;
    }

    public Set getCategoryNames() {
        return null;
    }

    public boolean hasCategory(String arg0) {
        return false;
    }

    private static List lambda$load$1(String arg0) {
        return null;
    }

    private static boolean lambda$load$0(File arg0, String arg1) {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'categories'
       'regexPatterns'
       'compoundPatterns'
       'getDataFolder'
       'wordlists'
       'copyDefaultsFromJar'
       'listFiles'
       'toLowerCase'
       'computeIfAbsent'
       'addSuppressed'
       'getLogger'
       'makeConcatWithConstants'
       'mergeConfigs'
       'compounds'
       'description'
       'score_per_hit'
       'max_score'
       'context_boosters'
       'insult_phrases'
       'leet_mappings'
       'safewords.json'
       'severe.json'
       'profanity.json'
       'profanity_extended.json'
       'profanity_german.json'
       'profanity_batch_1.json'
       'profanity_batch_2.json'
       'profanity_batch_3.json'
       'hate.json'
       'scam.json'
       'spam.json'
       'getResource'
       'transferTo'
       'emptyList'
       'getOrDefault'
       'containsKey'
       'WORDLIST_DIR'
       'ConstantValue'
       'Signature'
       'LineNumberTable'
    */
}