package com.jonasmp.ai.wordlist;

public class CategoryConfig {

    public String category;
    public String description;
    public String severity;
    public double score_per_hit;
    public double max_score;
    public String action;
    public List words;
    public List patterns;
    public CategoryConfig$CompoundConfig compounds;
    public CategoryConfig$ContextBoost context_boosters;
    public CategoryConfig$RepetitionRules repetition_rules;
    public Map leet_mappings;

    public CategoryConfig() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'compounds'
       'context_boosters'
       'repetition_rules'
       'leet_mappings'
       'description'
       'score_per_hit'
       'max_score'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'CategoryConfig.java'
       'NestMembers'
       'InnerClasses'
       'CompoundConfig'
       'ContextBoost'
       'RepetitionRules'
    */
}