package com.jonasmp.ai.wordlist;

public class CategoryConfig$RepetitionRules {

    public int max_repeated_chars;
    public int max_repeated_words;
    public double max_caps_ratio;
    public double max_emoji_ratio;

    public CategoryConfig$RepetitionRules() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'max_repeated_chars'
       'max_repeated_words'
       'max_caps_ratio'
       'max_emoji_ratio'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'CategoryConfig.java'
       'InnerClasses'
       'RepetitionRules'
    */
}