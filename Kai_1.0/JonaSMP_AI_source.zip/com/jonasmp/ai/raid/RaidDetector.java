package com.jonasmp.ai.raid;

public class RaidDetector {

    private final Map messageLog;
    private final long TIME_WINDOW;
    private final int LIMIT;

    public RaidDetector() {
        // TODO: decompile
    }

    public boolean isRaid(UUID arg0) {
        return false;
    }

    private static boolean lambda$isRaid$1(long arg0, Long arg1) {
        return false;
    }

    private static List lambda$isRaid$0(UUID arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'TIME_WINDOW'
       'messageLog'
       'currentTimeMillis'
       'computeIfAbsent'
       'longValue'
       'Signature'
       'ConstantValue'
       'LineNumberTable'
       'LocalVariableTable'
       'timestamps'
       'LocalVariableTypeTable'
       'StackMapTable'
       'lambda$isRaid$1'
       'lambda$isRaid$0'
       'SourceFile'
       'RaidDetector.java'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
    */
}