package com.jonasmp.ai.watcher;

public class WatcherAmbientHorror {

    private final WatcherCore core;
    private final WatcherBot bot;
    private final Random random;
    private BukkitRunnable ambientTask;
    private final List AMBIENT_MESSAGES;
    private final List SIGN_TEXTS;

    public WatcherAmbientHorror(WatcherCore arg0) {
        // TODO: decompile
    }

    public void start() {
    }

    public void stop() {
    }

    public void triggerEventOnPlayer(Player arg0) {
    }

    private void tryRandomAmbientEvent() {
    }

    private void tryRandomAmbientEvent(Player arg0) {
    }

    private void sendAmbientMessage(Player arg0) {
    }

    private void flickerNearbyLights(Player arg0) {
    }

    private boolean isLightSource(Material arg0) {
        return false;
    }

    private void playDistantSound(Player arg0) {
    }

    private void placeAmbientSign(Player arg0) {
    }

    private void briefNausea(Player arg0) {
    }

    private void fakeFootsteps(Player arg0) {
    }

    private void briefTorchExtinguish(Player arg0) {
    }

    private Player getRandomOnlinePlayer() {
        return null;
    }

    private Location findValidSurface(Player arg0, int arg1, int arg2) {
        return null;
    }

    private static void lambda$briefTorchExtinguish$0(Block arg0, Material arg1) {
    }

    private static void lambda$fakeFootsteps$0(Player arg0, int arg1, Location arg2, double arg3, World arg4) {
    }

    private static void lambda$placeAmbientSign$0(Block arg0) {
    }

    private static void lambda$flickerNearbyLights$0(Block arg0, Material arg1) {
    }

    /* String constants found in bytecode:
       'ambientTask'
       '§8§oDu hörst etwas im Dunkeln...'
       '§8§oEin kalter Luftzug streicht über deinen Nacken.'
       '§8§oWar das ein Schritt hinter dir?'
       '§8§oDie Stille hier ist... falsch.'
       '§8§oDu spürst jemandes Blick auf deinem Rücken.'
       '§8§oDie Blöcke flüstern. Oder war das nur der Wind?'
       '§8§oDein Herz schlägt schneller. Ich merke es.'
       '§8§oJemand hat deinen Namen geflüstert.'
       '§8§oDie Dunkelheit hier ist nicht normal.'
       '§8§oDu solltest nicht allein sein...'
       'AMBIENT_MESSAGES'
       'TURN BACK'
       'I SEE YOU'
       'FOLLOW ME'
       'DONT LOOK'
       'BEHIND YOU'
       'SIGN_TEXTS'
       'getConfig'
       'isAmbientEnabled'
       'getLogger'
       'getAmbientEventIntervalMin'
       'getAmbientEventIntervalMax'
       'runTaskTimer'
       'tryRandomAmbientEvent'
       'getRandomOnlinePlayer'
       'ambient_message'
       'isAmbientEventEnabled'
       'getAmbientEventChance'
       'sendAmbientMessage'
       'light_flicker'
       'flickerNearbyLights'
       'distant_sound'
       'playDistantSound'
       'ambient_sign'
       'placeAmbientSign'
       'brief_nausea'
       'briefNausea'
       'fake_footsteps'
       'fakeFootsteps'
    */
}