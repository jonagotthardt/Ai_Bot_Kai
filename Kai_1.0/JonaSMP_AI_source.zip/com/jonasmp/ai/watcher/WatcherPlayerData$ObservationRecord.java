package com.jonasmp.ai.watcher;

public class WatcherPlayerData$ObservationRecord {

    public final long timestamp;
    public final String category;
    public final String details;
    public final int severity;

    public WatcherPlayerData$ObservationRecord(long arg0, String arg1, String arg2, int arg3) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'timestamp'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'WatcherPlayerData.java'
       'InnerClasses'
       'ObservationRecord'
    */
}