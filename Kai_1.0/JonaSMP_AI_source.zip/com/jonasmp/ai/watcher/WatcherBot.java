package com.jonasmp.ai.watcher;

public class WatcherBot {

    private final WatcherCore core;
    private final NMSBot nmsBot;
    private String botName;
    private boolean spawned;

    public WatcherBot(WatcherCore arg0) {
        // TODO: decompile
    }

    public void spawn() {
    }

    public void despawn() {
    }

    private void configureBot() {
    }

    public void vanish() {
    }

    public void unvanish() {
    }

    public void teleport(Location arg0) {
    }

    public void lookAt(Location arg0) {
    }

    public void smoothLookAt(Location arg0, float arg1) {
    }

    public Location getLocation() {
        return null;
    }

    public Player getBotPlayer() {
        return null;
    }

    public boolean isSpawned() {
        return false;
    }

    public String getBotName() {
        return null;
    }

    /* String constants found in bytecode:
       'getConfig'
       'getWatcherName'
       'getWorlds'
       'getSpawnLocation'
       'setBotName'
       'getLogger'
       'makeConcatWithConstants'
       'getScheduler'
       'runTaskLater'
       'isSpawned'
       'getPlayer'
       'setCollidable'
       'setInvulnerable'
       'setSilent'
       'setSleepingIgnored'
       'setCanPickupItems'
       'INVISIBILITY'
       'removePotionEffect'
       'addPotionEffect'
       'getUniqueId'
       'getBotPlayer'
       'getLocation'
       'toDegrees'
       'LineNumberTable'
       'LocalVariableTable'
       'desiredName'
       'StackMapTable'
       'configureBot'
       'smoothLookAt'
       'targetYaw'
       'targetPitch'
       'currentYaw'
       'currentPitch'
       'getBotName'
       'SourceFile'
       'WatcherBot.java'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
    */
}