package com.jonasmp.ai.watcher;

public class WatcherPlayerData {

    private final UUID playerUuid;
    private final String playerName;
    private int antiCheatStrikes;
    private int suspiciousChatStrikes;
    private int suspiciousCombatStrikes;
    private int suspiciousMovementStrikes;
    private int xrayIndicators;
    private long lastAntiCheatFlag;
    private long lastSuspiciousChat;
    private long lastSuspiciousCombat;
    private long lastSuspiciousMovement;
    private long lastXrayFlag;
    private final List observationHistory;
    private int investigationScore;
    private long investigationStarted;
    private boolean underInvestigation;
    private int freezeCount;
    private long lastFreeze;
    private int loreAppearances;
    private long lastLoreAppearance;

    public WatcherPlayerData(UUID arg0, String arg1) {
        // TODO: decompile
    }

    public UUID getPlayerUuid() {
        return null;
    }

    public String getPlayerName() {
        return null;
    }

    public int getAntiCheatStrikes() {
        return 0;
    }

    public void incrementAntiCheatStrikes() {
    }

    public int getSuspiciousChatStrikes() {
        return 0;
    }

    public void incrementSuspiciousChatStrikes() {
    }

    public int getSuspiciousCombatStrikes() {
        return 0;
    }

    public void incrementSuspiciousCombatStrikes() {
    }

    public int getSuspiciousMovementStrikes() {
        return 0;
    }

    public void incrementSuspiciousMovementStrikes() {
    }

    public int getXrayIndicators() {
        return 0;
    }

    public void incrementXrayIndicators() {
    }

    public int getInvestigationScore() {
        return 0;
    }

    public void setInvestigationScore(int arg0) {
    }

    public void addInvestigationScore(int arg0) {
    }

    public boolean isUnderInvestigation() {
        return false;
    }

    public void setUnderInvestigation(boolean arg0) {
    }

    public long getInvestigationStarted() {
        return 0;
    }

    public int getFreezeCount() {
        return 0;
    }

    public void incrementFreezeCount() {
    }

    public long getLastFreeze() {
        return 0;
    }

    public int getLoreAppearances() {
        return 0;
    }

    public void incrementLoreAppearances() {
    }

    public long getLastLoreAppearance() {
        return 0;
    }

    public void addObservationRecord(String arg0, String arg1, int arg2) {
    }

    public List getObservationHistory() {
        return null;
    }

    public void decayStrikes(int arg0) {
    }

    public int getTotalStrikes() {
        return 0;
    }

    public void reset() {
    }

    /* String constants found in bytecode:
       'antiCheatStrikes'
       'suspiciousChatStrikes'
       'suspiciousCombatStrikes'
       'suspiciousMovementStrikes'
       'xrayIndicators'
       'lastAntiCheatFlag'
       'lastSuspiciousChat'
       'lastSuspiciousCombat'
       'lastSuspiciousMovement'
       'lastXrayFlag'
       'observationHistory'
       'investigationScore'
       'investigationStarted'
       'underInvestigation'
       'freezeCount'
       'lastFreeze'
       'loreAppearances'
       'lastLoreAppearance'
       'playerUuid'
       'playerName'
       'currentTimeMillis'
       'setInvestigationScore'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'getPlayerUuid'
       'getPlayerName'
       'getAntiCheatStrikes'
       'incrementAntiCheatStrikes'
       'getSuspiciousChatStrikes'
       'incrementSuspiciousChatStrikes'
       'getSuspiciousCombatStrikes'
       'incrementSuspiciousCombatStrikes'
       'getSuspiciousMovementStrikes'
       'incrementSuspiciousMovementStrikes'
       'getXrayIndicators'
       'incrementXrayIndicators'
       'getInvestigationScore'
       'addInvestigationScore'
       'isUnderInvestigation'
    */
}