package com.jonasmp.ai.watcher;

public class AIBridgeWriter$1 extends BukkitRunnable {

    final AIBridgeWriter this$0;

     AIBridgeWriter$1(AIBridgeWriter arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'writeSnapshot'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'SourceFile'
       'AIBridgeWriter.java'
       'EnclosingMethod'
       'startTask'
       'InnerClasses'
    */
}