package com.jonasmp.ai.watcher;

public class WatcherVisuals$3 {

    static final int[] $SwitchMap$com$jonasmp$ai$watcher$WatcherState;

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       '$SwitchMap$com$jonasmp$ai$watcher$WatcherState'
       'OBSERVING'
       'INVESTIGATING'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'WatcherVisuals.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}