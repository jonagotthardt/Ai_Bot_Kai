package com.jonasmp.ai.watcher;

public class WatcherFreeze$FreezeSession {

    final Location lockLocation;
    final long expiresAt;

     WatcherFreeze$FreezeSession(Location arg0, long arg1) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'lockLocation'
       'expiresAt'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'WatcherFreeze.java'
       'InnerClasses'
       'FreezeSession'
    */
}