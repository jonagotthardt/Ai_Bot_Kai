package com.jonasmp.ai.watcher;

public class WatcherCaveDweller$1 extends BukkitRunnable {

     int tick;
    final int val$checkInterval;
    final WatcherCaveDweller this$0;

     WatcherCaveDweller$1(WatcherCaveDweller arg0, int arg1) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'val$checkInterval'
       'requireNonNull'
       'isRunning'
       'checkPlayersInDarkness'
       'flickerForDarkPlayers'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'WatcherCaveDweller.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}