package com.jonasmp.ai.watcher;

public class BotGoalPlanner {

    private BotGoalPlanner$GoalType currentGoal;
    private final List goalSteps;
    private int currentStepIndex;
    private int stepStuckCounter;
    private long goalStartTime;
    public Location targetLocation;
    public Entity nearestThreat;
    public boolean isNight;
    public double healthPercent;
    public int foodLevel;
    public int woodCount;
    public int plankCount;
    public int stickCount;
    public int stoneCount;
    public int coalCount;
    public int ironCount;
    public boolean hasWoodenPickaxe;
    public boolean hasStonePickaxe;
    public boolean hasIronPickaxe;
    public double surfaceY;
    public long stepStartTick;
    private long playerOverrideUntil;
     Player followTargetPlayer;
    private Block currentMiningBlock;
    private static final Map stuckTicks;
    private static final Map lastPositions;
    private static final Map botPaths;
    private static final Map botPathTargets;
    private static final Map botPathComputeTime;
    private static final long PATH_RECALC_INTERVAL_MS;
    private static final double PATH_DEVIATION_THRESHOLD;

    public BotGoalPlanner() {
        // TODO: decompile
    }

    public void setPlayerOverride(long arg0) {
    }

    public void setGoal(BotGoalPlanner$GoalType arg0) {
    }

    public boolean tick(Player arg0, NMSBot arg1) {
        return false;
    }

    public BotGoalPlanner$GoalType getCurrentGoal() {
        return null;
    }

    public String getCurrentStepDesc() {
        return null;
    }

    private void updateContext(Player arg0) {
    }

    private static int countItem(PlayerInventory arg0, Material[] arg1) {
        return 0;
    }

    private static int countAny(PlayerInventory arg0, Material[] arg1) {
        return 0;
    }

    private static boolean hasItem(PlayerInventory arg0, Material arg1) {
        return false;
    }

    private static boolean hasAny(PlayerInventory arg0, Material[] arg1) {
        return false;
    }

    private static Block findNearestBlock(Player arg0, Material[] arg1, int arg2) {
        return null;
    }

    private static Block findNearestTree(Player arg0, int arg1) {
        return null;
    }

    private static boolean isLog(Material arg0) {
        return false;
    }

    private static boolean hasLeavesNearby(Block arg0, int arg1) {
        return false;
    }

    private static Entity findNearestAnimal(Player arg0, double arg1) {
        return null;
    }

    private static boolean isCliffAhead(Player arg0, double arg1) {
        return false;
    }

    private static boolean isLavaAhead(Player arg0, double arg1) {
        return false;
    }

    private static void walkTo(Player arg0, NMSBot arg1, Location arg2, double arg3) {
    }

    private static void pickupNearbyItems(Player arg0) {
    }

    private boolean mineBlockTick(NMSBot arg0, Block arg1, Player arg2) {
        return false;
    }

    private static double normalizeAngle(double arg0) {
        return 0.0;
    }

    private static void wander(Player arg0, NMSBot arg1) {
    }

    private void buildGatherWood() {
    }

    private void buildGatherStone() {
    }

    private void buildCraftTools() {
    }

    private void buildMineOres() {
    }

    private void buildDigDiamonds() {
    }

    private void buildShelter() {
    }

    private void buildFindFood() {
    }

    private void buildExplore() {
    }

    private void buildFlee() {
    }

    private void buildSmeltOres() {
    }

    private void buildDeepMine() {
    }

    private void buildCookFood() {
    }

    private void buildBasicHouse() {
    }

    private void buildBridgeGap() {
    }

    private void buildFillHole() {
    }

    private void buildPlaceTorches() {
    }

    private void buildFarmCrops() {
    }

    private void buildBreedAnimals() {
    }

    private void buildShearSheep() {
    }

    private void buildTradeVillager() {
    }

    private void buildEnchantGear() {
    }

    private void buildBrewPotions() {
    }

    private void buildNetherPortal() {
    }

    private void buildExploreEnd() {
    }

    private void buildSurviveNight() {
    }

    private static BotGoalPlanner$Step lambda$buildSurviveNight$14(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildSurviveNight$13(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildSurviveNight$12(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildSurviveNight$11(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildSurviveNight$10(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildSurviveNight$9(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildSurviveNight$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static BotGoalPlanner$Step lambda$buildSurviveNight$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildSurviveNight$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildSurviveNight$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static boolean lambda$buildSurviveNight$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildSurviveNight$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildSurviveNight$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildSurviveNight$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildSurviveNight$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildExploreEnd$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildExploreEnd$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildExploreEnd$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildNetherPortal$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildNetherPortal$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildNetherPortal$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildNetherPortal$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildNetherPortal$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildNetherPortal$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildBrewPotions$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildBrewPotions$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildBrewPotions$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildEnchantGear$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildEnchantGear$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildEnchantGear$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildTradeVillager$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildTradeVillager$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildTradeVillager$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildShearSheep$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildShearSheep$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildShearSheep$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildBreedAnimals$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildBreedAnimals$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildBreedAnimals$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildFarmCrops$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildFarmCrops$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildFarmCrops$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildPlaceTorches$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildPlaceTorches$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildPlaceTorches$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildFillHole$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildFillHole$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildFillHole$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildBridgeGap$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildBridgeGap$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildBridgeGap$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildBasicHouse$11(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildBasicHouse$10(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildBasicHouse$9(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildBasicHouse$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildBasicHouse$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildBasicHouse$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildBasicHouse$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildBasicHouse$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildBasicHouse$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildBasicHouse$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildBasicHouse$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildBasicHouse$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildCookFood$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildCookFood$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildCookFood$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildCookFood$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildCookFood$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildCookFood$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildDeepMine$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildDeepMine$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildDeepMine$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildDeepMine$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildDeepMine$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildDeepMine$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildDeepMine$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildDeepMine$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildDeepMine$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildSmeltOres$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildSmeltOres$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildSmeltOres$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildSmeltOres$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildSmeltOres$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildSmeltOres$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildFlee$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildFlee$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildFlee$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildExplore$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildExplore$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildExplore$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildFindFood$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildFindFood$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildFindFood$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildFindFood$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static BotGoalPlanner$Step lambda$buildFindFood$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildFindFood$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildFindFood$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static boolean lambda$buildFindFood$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildFindFood$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildShelter$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildShelter$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildShelter$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildShelter$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildShelter$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildShelter$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildShelter$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildShelter$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildShelter$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildDigDiamonds$14(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildDigDiamonds$13(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildDigDiamonds$12(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildDigDiamonds$11(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildDigDiamonds$10(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildDigDiamonds$9(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildDigDiamonds$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static BotGoalPlanner$Step lambda$buildDigDiamonds$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildDigDiamonds$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildDigDiamonds$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static boolean lambda$buildDigDiamonds$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildDigDiamonds$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildDigDiamonds$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildDigDiamonds$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildDigDiamonds$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildMineOres$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildMineOres$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildMineOres$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildMineOres$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildMineOres$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildMineOres$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildMineOres$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildMineOres$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildMineOres$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildCraftTools$11(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildCraftTools$10(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildCraftTools$9(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildCraftTools$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildCraftTools$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildCraftTools$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildCraftTools$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildCraftTools$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildCraftTools$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildCraftTools$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildCraftTools$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildCraftTools$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildGatherStone$11(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildGatherStone$10(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildGatherStone$9(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private BotGoalPlanner$Step lambda$buildGatherStone$5(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static BotGoalPlanner$Step lambda$buildGatherStone$8(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildGatherStone$7(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildGatherStone$6(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static boolean lambda$buildGatherStone$4(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildGatherStone$3(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildGatherStone$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildGatherStone$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private static boolean lambda$buildGatherStone$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    private static BotGoalPlanner$Step lambda$buildGatherWood$2(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    private static boolean lambda$buildGatherWood$1(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    private boolean lambda$buildGatherWood$0(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'currentGoal'
       'goalSteps'
       'currentStepIndex'
       'stepStuckCounter'
       'goalStartTime'
       'targetLocation'
       'nearestThreat'
       'healthPercent'
       'foodLevel'
       'woodCount'
       'plankCount'
       'stickCount'
       'stoneCount'
       'coalCount'
       'ironCount'
       'hasWoodenPickaxe'
       'hasStonePickaxe'
       'hasIronPickaxe'
       'stepStartTick'
       'playerOverrideUntil'
       'followTargetPlayer'
       'currentMiningBlock'
       'currentTimeMillis'
       'buildGatherWood'
       'buildGatherStone'
       'buildCraftTools'
       'buildMineOres'
       'buildDigDiamonds'
       'buildShelter'
       'buildFindFood'
       'buildExplore'
       'buildFlee'
       'buildSurviveNight'
       'buildSmeltOres'
       'buildDeepMine'
       'buildCookFood'
       'buildBasicHouse'
       'buildBridgeGap'
       'buildFillHole'
       'buildPlaceTorches'
    */
}