package com.jonasmp.ai.watcher;

public class BotMemory {

    public String botName;
    public UUID botUuid;
    public long createdAt;
    public long lastSaved;
    public int totalDeaths;
    public int totalMobKills;
    public int totalPlayerKills;
    public int blocksMined;
    public int blocksPlaced;
    public int itemsPickedUp;
    public String lastDeathCause;
    public double lastDeathX;
    public double lastDeathY;
    public double lastDeathZ;
    public long lastDeathTime;
    public List deathHistory;
    public Map killCounts;
    public List resourceFinds;
    public List dangerZones;
    public List safeSpots;
    public int[] deathsByHour;
    public Map deathsByBiome;
    public Map weaponKills;
    public Map foodEaten;
    public boolean learnedShelterAtNight;
    public boolean learnedDontFightLowHealth;
    public boolean learnedRunFromCreepers;
    public boolean learnedCarryFood;
    public boolean learnedDigForSafety;
    public int survivalSkill;
    public long longestSurvivalMinutes;
    public long currentSpawnTime;
    public List playerInstructions;
    public List learnedLessons;
    public String lastActionDescription;
    public long lastActionTime;
    public String environmentAhead;

    public BotMemory() {
        // TODO: decompile
    }

    public BotMemory(UUID arg0) {
        // TODO: decompile
    }

    public void recordDeath(String arg0, Location arg1, long arg2) {
    }

    public void recordKill(String arg0, String arg1) {
    }

    public void recordResourceFound(String arg0, Location arg1) {
    }

    public void recordDanger(Location arg0, String arg1) {
    }

    public void recordSafeSpot(Location arg0) {
    }

    public void recordBlockMined() {
    }

    public void recordBlockPlaced() {
    }

    public void recordItemPickedUp() {
    }

    public void recordFoodEaten(String arg0) {
    }

    public void updateSurvivalTime() {
    }

    public double getDangerLevel(int arg0, String arg1) {
        return 0.0;
    }

    public BotMemory$ResourceLocation findNearestResource(String arg0, Location arg1, double arg2) {
        return null;
    }

    public Location findNearestSafeSpot(Location arg0, double arg1) {
        return null;
    }

    public boolean isNearDanger(Location arg0, double arg1) {
        return false;
    }

    public void recordPlayerInstruction(String arg0, String arg1, Location arg2) {
    }

    public void recordLesson(String arg0, String arg1, String arg2, String arg3) {
    }

    public void reinforceLesson(String arg0) {
    }

    public boolean removeLesson(int arg0) {
        return false;
    }

    public boolean removeInstruction(int arg0) {
        return false;
    }

    public List findLessons(String arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'createdAt'
       'lastSaved'
       'totalDeaths'
       'totalMobKills'
       'totalPlayerKills'
       'blocksMined'
       'blocksPlaced'
       'itemsPickedUp'
       'lastDeathCause'
       'lastDeathX'
       'lastDeathY'
       'lastDeathZ'
       'lastDeathTime'
       'deathHistory'
       'killCounts'
       'resourceFinds'
       'dangerZones'
       'safeSpots'
       'deathsByHour'
       'deathsByBiome'
       'weaponKills'
       'foodEaten'
       'learnedShelterAtNight'
       'learnedDontFightLowHealth'
       'learnedRunFromCreepers'
       'learnedCarryFood'
       'learnedDigForSafety'
       'survivalSkill'
       'longestSurvivalMinutes'
       'currentSpawnTime'
       'playerInstructions'
       'learnedLessons'
       'lastActionDescription'
       'lastActionTime'
       'toLowerCase'
       'getOrDefault'
       'equalsIgnoreCase'
       'playerName'
       'instruction'
    */
}