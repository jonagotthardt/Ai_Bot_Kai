package com.jonasmp.ai.watcher;

public class WatcherVisuals$2 extends BukkitRunnable {

     int tick;
    final int val$durationTicks;
    final Player val$target;
    final int val$intensity;
    final Location val$base;
    final WatcherVisuals this$0;

     WatcherVisuals$2(WatcherVisuals arg0, int arg1, Player arg2, int arg3, Location arg4) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'val$durationTicks'
       'val$target'
       'val$intensity'
       'requireNonNull'
       'nextDouble'
       'getLocation'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'WatcherVisuals.java'
       'EnclosingMethod'
       'shakeCamera'
       'InnerClasses'
    */
}