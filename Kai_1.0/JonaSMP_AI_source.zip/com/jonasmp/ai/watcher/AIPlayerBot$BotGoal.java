package com.jonasmp.ai.watcher;

public class AIPlayerBot$BotGoal extends Enum {

    public static final AIPlayerBot$BotGoal IDLE;
    public static final AIPlayerBot$BotGoal MINE_BLOCK;
    public static final AIPlayerBot$BotGoal ATTACK_ENTITY;
    public static final AIPlayerBot$BotGoal FOLLOW_PLAYER;
    public static final AIPlayerBot$BotGoal PICKUP_ITEM;
    public static final AIPlayerBot$BotGoal EAT_FOOD;
    public static final AIPlayerBot$BotGoal FLEE;
    public static final AIPlayerBot$BotGoal BUILD;
    public static final AIPlayerBot$BotGoal CRAFT;
    public static final AIPlayerBot$BotGoal EXPLORE;
    private static final AIPlayerBot$BotGoal[] $VALUES;

    public static AIPlayerBot$BotGoal[] values() {
        return null;
    }

    public static AIPlayerBot$BotGoal valueOf(String arg0) {
        return null;
    }

    private AIPlayerBot$BotGoal(String arg0, int arg1) {
        // TODO: decompile
    }

    private static AIPlayerBot$BotGoal[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'MINE_BLOCK'
       'ATTACK_ENTITY'
       'FOLLOW_PLAYER'
       'PICKUP_ITEM'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'AIPlayerBot.java'
       'InnerClasses'
    */
}