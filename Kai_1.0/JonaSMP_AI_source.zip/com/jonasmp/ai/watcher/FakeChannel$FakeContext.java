package com.jonasmp.ai.watcher;

public class FakeChannel$FakeContext implements ChannelHandlerContext {

    private final ChannelPipeline pipeline;
    private final String name;

     FakeChannel$FakeContext(ChannelPipeline arg0, String arg1) {
        // TODO: decompile
    }

    public ChannelPipeline pipeline() {
        return null;
    }

    public Channel channel() {
        return null;
    }

    public EventExecutor executor() {
        return null;
    }

    public String name() {
        return null;
    }

    public ChannelHandler handler() {
        return null;
    }

    public boolean isRemoved() {
        return false;
    }

    public ChannelHandlerContext fireChannelRegistered() {
        return null;
    }

    public ChannelHandlerContext fireChannelUnregistered() {
        return null;
    }

    public ChannelHandlerContext fireChannelActive() {
        return null;
    }

    public ChannelHandlerContext fireChannelInactive() {
        return null;
    }

    public ChannelHandlerContext fireExceptionCaught(Throwable arg0) {
        return null;
    }

    public ChannelHandlerContext fireUserEventTriggered(Object arg0) {
        return null;
    }

    public ChannelHandlerContext fireChannelRead(Object arg0) {
        return null;
    }

    public ChannelHandlerContext fireChannelReadComplete() {
        return null;
    }

    public ChannelHandlerContext fireChannelWritabilityChanged() {
        return null;
    }

    public ChannelHandlerContext read() {
        return null;
    }

    public ChannelHandlerContext flush() {
        return null;
    }

    public ChannelFuture write(Object arg0) {
        return null;
    }

    public ChannelFuture write(Object arg0, ChannelPromise arg1) {
        return null;
    }

    public ChannelFuture writeAndFlush(Object arg0) {
        return null;
    }

    public ChannelFuture writeAndFlush(Object arg0, ChannelPromise arg1) {
        return null;
    }

    public ChannelPromise newPromise() {
        return null;
    }

    public ChannelProgressivePromise newProgressivePromise() {
        return null;
    }

    public ChannelFuture newSucceededFuture() {
        return null;
    }

    public ChannelFuture newFailedFuture(Throwable arg0) {
        return null;
    }

    public ChannelPromise voidPromise() {
        return null;
    }

    public ChannelFuture bind(SocketAddress arg0) {
        return null;
    }

    public ChannelFuture connect(SocketAddress arg0) {
        return null;
    }

    public ChannelFuture connect(SocketAddress arg0, SocketAddress arg1) {
        return null;
    }

    public ChannelFuture disconnect() {
        return null;
    }

    public ChannelFuture close() {
        return null;
    }

    public ChannelFuture deregister() {
        return null;
    }

    public ChannelFuture bind(SocketAddress arg0, ChannelPromise arg1) {
        return null;
    }

    public ChannelFuture connect(SocketAddress arg0, ChannelPromise arg1) {
        return null;
    }

    public ChannelFuture connect(SocketAddress arg0, SocketAddress arg1, ChannelPromise arg2) {
        return null;
    }

    public ChannelFuture disconnect(ChannelPromise arg0) {
        return null;
    }

    public ChannelFuture close(ChannelPromise arg0) {
        return null;
    }

    public ChannelFuture deregister(ChannelPromise arg0) {
        return null;
    }

    public ByteBufAllocator alloc() {
        return null;
    }

    public Attribute attr(AttributeKey arg0) {
        return null;
    }

    public boolean hasAttr(AttributeKey arg0) {
        return false;
    }

    private ChannelFuture newFailedFuture() {
        return null;
    }

    public ChannelInboundInvoker fireChannelWritabilityChanged() {
        return null;
    }

    public ChannelInboundInvoker fireChannelReadComplete() {
        return null;
    }

    public ChannelInboundInvoker fireChannelRead(Object arg0) {
        return null;
    }

    public ChannelInboundInvoker fireUserEventTriggered(Object arg0) {
        return null;
    }

    public ChannelInboundInvoker fireExceptionCaught(Throwable arg0) {
        return null;
    }

    public ChannelInboundInvoker fireChannelInactive() {
        return null;
    }

    public ChannelInboundInvoker fireChannelActive() {
        return null;
    }

    public ChannelInboundInvoker fireChannelUnregistered() {
        return null;
    }

    public ChannelInboundInvoker fireChannelRegistered() {
        return null;
    }

    public ChannelOutboundInvoker flush() {
        return null;
    }

    public ChannelOutboundInvoker read() {
        return null;
    }

    /* String constants found in bytecode:
       'eventLoop'
       'newFailedFuture'
       'setFailure'
       'setSuccess'
       'fireChannelWritabilityChanged'
       'fireChannelReadComplete'
       'fireChannelRead'
       'fireUserEventTriggered'
       'fireExceptionCaught'
       'fireChannelInactive'
       'fireChannelActive'
       'fireChannelUnregistered'
       'fireChannelRegistered'
       'LineNumberTable'
       'LocalVariableTable'
       'isRemoved'
       'writeAndFlush'
       'newPromise'
       'newProgressivePromise'
       'newSucceededFuture'
       'voidPromise'
       'localAddress'
       'remoteAddress'
       'disconnect'
       'deregister'
       'LocalVariableTypeTable'
       'Signature'
       'MethodParameters'
       'SourceFile'
       'FakeChannel.java'
       'InnerClasses'
       'FakeContext'
    */
}