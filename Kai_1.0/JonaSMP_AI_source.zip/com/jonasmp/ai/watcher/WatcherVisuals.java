package com.jonasmp.ai.watcher;

public class WatcherVisuals {

    private final WatcherCore core;
    private final WatcherBot bot;
    private final Random random;
    private static final String WATCHER_TEAM;
    private BukkitRunnable particleTask;
    private BukkitRunnable eyeTask;

    public WatcherVisuals(WatcherCore arg0) {
        // TODO: decompile
    }

    public void setupHerobrineEyes() {
    }

    public void setupRedEyes() {
    }

    public void removeEyes() {
    }

    public void startParticleAura() {
    }

    public void stopParticleAura() {
    }

    public void spawnEyeParticles() {
    }

    public void triggerFullJumpScare(Player arg0) {
    }

    private void shakeCamera(Player arg0, int arg1, int arg2) {
    }

    public void applyTotalDarkness(Player arg0, int arg1) {
    }

    public void flashEyes(int arg0) {
    }

    public void playAmbientSound() {
    }

    public void playJumpScareSound() {
    }

    public void playHerobrineStareSound() {
    }

    private void playCustomOrVanilla(World arg0, Location arg1, String arg2, SoundCategory arg3, float arg4, float arg5, Sound arg6) {
    }

    public void playRandomHerobrineSound(World arg0, Location arg1) {
    }

    private void lambda$flashEyes$0() {
    }

    private void lambda$triggerFullJumpScare$0(Player arg0) {
    }

    private void lambda$triggerFullJumpScare$1() {
    }

    /* String constants found in bytecode:
       'particleTask'
       'getBotPlayer'
       'getScoreboardManager'
       'getMainScoreboard'
       'watcher_horror'
       'registerNewTeam'
       'NAME_TAG_VISIBILITY'
       'setOption'
       'COLLISION_RULE'
       'setCanSeeFriendlyInvisibles'
       'addPotionEffect'
       'getLogger'
       'unregister'
       'removeEntry'
       'getEntries'
       'removePotionEffect'
       'runTaskTimer'
       'getLocation'
       'toRadians'
       'spawnParticle'
       'SOUL_FIRE_FLAME'
       'getDirection'
       'getEyeLocation'
       'setupRedEyes'
       'BLINDNESS'
       'NIGHT_VISION'
       'TOTEM_OF_UNDYING'
       '§c§lHEROBRINE'
       '§8§oDu solltest nicht hier sein...'
       'sendTitle'
       'shakeCamera'
       'playJumpScareSound'
       'getScheduler'
       'runTaskLater'
       'watcher.ambient.cave'
       'AMBIENT_CAVE'
       'playCustomOrVanilla'
       'watcher.ambient.whisper'
       'ENTITY_GHAST_AMBIENT'
       'watcher.heartbeat'
    */
}