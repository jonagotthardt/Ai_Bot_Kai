package com.jonasmp.ai.watcher;

public class WatcherEvents$OreTracker {

    private final Map mines;

    private WatcherEvents$OreTracker() {
        // TODO: decompile
    }

     void addMine(String arg0) {
    }

     int getRecentCount(String arg0, long arg1) {
        return 0;
    }

     void reset(String arg0) {
    }

    private static boolean lambda$getRecentCount$0(long arg0, Long arg1) {
        return false;
    }

    private static List lambda$addMine$0(String arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'computeIfAbsent'
       'currentTimeMillis'
       'longValue'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'getRecentCount'
       'LocalVariableTypeTable'
       'StackMapTable'
       'lambda$getRecentCount$0'
       'lambda$addMine$0'
       'SourceFile'
       'WatcherEvents.java'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
       'OreTracker'
    */
}