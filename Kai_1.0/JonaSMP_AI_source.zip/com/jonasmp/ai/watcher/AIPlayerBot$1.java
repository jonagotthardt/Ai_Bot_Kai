package com.jonasmp.ai.watcher;

public class AIPlayerBot$1 extends BukkitRunnable {

     int attempts;
    final String val$botName;
    final Location val$loc;
    final AIPlayerBot this$0;

     AIPlayerBot$1(AIPlayerBot arg0, String arg1, Location arg2) {
        // TODO: decompile
    }

    public void run() {
    }

    private void lambda$run$0(Location arg0) {
    }

    /* String constants found in bytecode:
       'val$botName'
       'requireNonNull'
       'isSpawned'
       'getPlayer'
       'memoryStorage'
       'getUniqueId'
       'botMemory'
       'currentTimeMillis'
       'currentSpawnTime'
       'getLogger'
       'totalDeaths'
       'totalMobKills'
       'survivalSkill'
       'makeConcatWithConstants'
       'setCanPickupItems'
       'loadBotInventory'
       'loadLastLocation'
       'getScheduler'
       'runTaskLater'
       'startAITickLoop'
       'getInstance'
       'getChunkRadar'
       'startRefreshTask'
       'getBlockX'
       'getBlockY'
       'getBlockZ'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'botPlayer'
       'StackMapTable'
       'lambda$run$0'
       'SourceFile'
       'AIPlayerBot.java'
       'EnclosingMethod'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
    */
}