package com.jonasmp.ai.watcher;

public class BotMemory$LearnedLesson {

    public String topic;
    public String whatWasWrong;
    public String whatToDoInstead;
    public String taughtBy;
    public long time;
    public int timesReinforced;

    public BotMemory$LearnedLesson() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'whatWasWrong'
       'whatToDoInstead'
       'timesReinforced'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'BotMemory.java'
       'InnerClasses'
       'LearnedLesson'
    */
}