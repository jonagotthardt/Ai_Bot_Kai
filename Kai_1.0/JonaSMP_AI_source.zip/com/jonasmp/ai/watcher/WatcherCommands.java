package com.jonasmp.ai.watcher;

public class WatcherCommands implements CommandExecutor, TabCompleter {

    private static final List SUB_COMMANDS;
    private static final List AI_SUBS;
    private static final List GOAL_TYPES;
    private static final List CONFIG_ACTIONS;

    public WatcherCommands() {
        // TODO: decompile
    }

    public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
        return false;
    }

    private void cmdStatus(CommandSender arg0, WatcherCore arg1) {
    }

    private void cmdSpawn(CommandSender arg0, WatcherCore arg1) {
    }

    private void cmdDespawn(CommandSender arg0, WatcherCore arg1) {
    }

    private void cmdReload(CommandSender arg0, WatcherCore arg1) {
    }

    private void cmdObserve(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdInvestigate(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdVisible(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdInvisible(CommandSender arg0, WatcherCore arg1) {
    }

    private void cmdFreeze(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdUnfreeze(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdIdle(CommandSender arg0, WatcherCore arg1) {
    }

    private void cmdLore(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdTp(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdPatrol(CommandSender arg0, WatcherCore arg1) {
    }

    private void cmdHorror(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdHerobrine(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdLog(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdAmbient(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdStalk(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdCave(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdBroken(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdScript(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdToggle(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void cmdAi(CommandSender arg0, String[] arg1, WatcherCore arg2) {
    }

    private void sendHelp(CommandSender arg0) {
    }

    private boolean checkPerm(CommandSender arg0, String arg1) {
        return false;
    }

    public List onTabComplete(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
        return null;
    }

    private static boolean lambda$onTabComplete$8(String[] arg0, String arg1) {
        return false;
    }

    private static boolean lambda$onTabComplete$7(String[] arg0, String arg1) {
        return false;
    }

    private static boolean lambda$onTabComplete$6(String[] arg0, String arg1) {
        return false;
    }

    private static boolean lambda$onTabComplete$5(String[] arg0, String arg1) {
        return false;
    }

    private static boolean lambda$onTabComplete$4(String[] arg0, String arg1) {
        return false;
    }

    private static boolean lambda$onTabComplete$3(String[] arg0, String arg1) {
        return false;
    }

    private static boolean lambda$onTabComplete$2(String[] arg0, String arg1) {
        return false;
    }

    private static boolean lambda$onTabComplete$1(String[] arg0, String arg1) {
        return false;
    }

    private static boolean lambda$onTabComplete$0(String[] arg0, String arg1) {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'toLowerCase'
       'getInstance'
       'investigate'
       'invisible'
       'herobrine'
       'cmdStatus'
       'cmdDespawn'
       'cmdReload'
       'cmdObserve'
       'cmdInvestigate'
       'cmdVisible'
       'cmdInvisible'
       'cmdFreeze'
       'cmdUnfreeze'
       'cmdPatrol'
       'cmdHorror'
       'cmdHerobrine'
       'cmdAmbient'
       'cmdBroken'
       'cmdScript'
       'cmdToggle'
       'makeConcatWithConstants'
       'sendMessage'
       'jonasmpai.watcher.admin'
       'checkPerm'
       'isSpawned'
       'getConfig'
       'getWatcherName'
       'getAssignedPlayer'
       'getPlayer'
       'getAllPlayerData'
       'isLoreModeEnabled'
       'isRunning'
       'getUniqueId'
       'observePlayer'
       'beginInvestigation'
       'showVisible'
       'freezePlayer'
       'unfreezePlayer'
       'triggerLore'
    */
}