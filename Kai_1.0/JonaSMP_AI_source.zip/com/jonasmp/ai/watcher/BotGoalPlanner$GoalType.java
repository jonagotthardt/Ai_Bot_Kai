package com.jonasmp.ai.watcher;

public class BotGoalPlanner$GoalType extends Enum {

    public static final BotGoalPlanner$GoalType IDLE;
    public static final BotGoalPlanner$GoalType GATHER_WOOD;
    public static final BotGoalPlanner$GoalType GATHER_STONE;
    public static final BotGoalPlanner$GoalType CRAFT_BASIC_TOOLS;
    public static final BotGoalPlanner$GoalType MINE_SURFACE_ORES;
    public static final BotGoalPlanner$GoalType DIG_FOR_DIAMONDS;
    public static final BotGoalPlanner$GoalType BUILD_SHELTER;
    public static final BotGoalPlanner$GoalType FIND_FOOD;
    public static final BotGoalPlanner$GoalType EXPLORE;
    public static final BotGoalPlanner$GoalType SURVIVE_NIGHT;
    public static final BotGoalPlanner$GoalType FLEE_DANGER;
    public static final BotGoalPlanner$GoalType SMELT_ORES;
    public static final BotGoalPlanner$GoalType DEEP_MINE;
    public static final BotGoalPlanner$GoalType COOK_FOOD;
    public static final BotGoalPlanner$GoalType BUILD_BASIC_HOUSE;
    public static final BotGoalPlanner$GoalType BRIDGE_GAP;
    public static final BotGoalPlanner$GoalType FILL_HOLE;
    public static final BotGoalPlanner$GoalType PLACE_TORCHES;
    public static final BotGoalPlanner$GoalType FARM_CROPS;
    public static final BotGoalPlanner$GoalType BREED_ANIMALS;
    public static final BotGoalPlanner$GoalType SHEAR_SHEEP;
    public static final BotGoalPlanner$GoalType TRADE_VILLAGER;
    public static final BotGoalPlanner$GoalType ENCHANT_GEAR;
    public static final BotGoalPlanner$GoalType BREW_POTIONS;
    public static final BotGoalPlanner$GoalType BUILD_NETHER_PORTAL;
    public static final BotGoalPlanner$GoalType EXPLORE_END;
    private static final BotGoalPlanner$GoalType[] $VALUES;

    public static BotGoalPlanner$GoalType[] values() {
        return null;
    }

    public static BotGoalPlanner$GoalType valueOf(String arg0) {
        return null;
    }

    private BotGoalPlanner$GoalType(String arg0, int arg1) {
        // TODO: decompile
    }

    private static BotGoalPlanner$GoalType[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'GATHER_WOOD'
       'GATHER_STONE'
       'CRAFT_BASIC_TOOLS'
       'MINE_SURFACE_ORES'
       'DIG_FOR_DIAMONDS'
       'BUILD_SHELTER'
       'FIND_FOOD'
       'SURVIVE_NIGHT'
       'FLEE_DANGER'
       'SMELT_ORES'
       'DEEP_MINE'
       'COOK_FOOD'
       'BUILD_BASIC_HOUSE'
       'BRIDGE_GAP'
       'FILL_HOLE'
       'PLACE_TORCHES'
       'FARM_CROPS'
       'BREED_ANIMALS'
       'SHEAR_SHEEP'
       'TRADE_VILLAGER'
       'ENCHANT_GEAR'
       'BREW_POTIONS'
       'BUILD_NETHER_PORTAL'
       'EXPLORE_END'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'BotGoalPlanner.java'
       'InnerClasses'
    */
}