package com.jonasmp.ai.watcher;

public class WatcherCaveDweller {

    private final WatcherCore core;
    private final WatcherBot bot;
    private final WatcherVisuals visuals;
    private final Random random;
    private BukkitRunnable caveTask;
    private final Map darknessScore;
    private final Set warnedPlayers;
    private long lastGlobalAppear;
    private long lastGlobalHorror;
    private static final long APPEAR_COOLDOWN_MS;
    private static final long HORROR_COOLDOWN_MS;
    private static final long FLICKER_INTERVAL_TICKS;
    private final List CAVE_MESSAGES;

    public WatcherCaveDweller(WatcherCore arg0) {
        // TODO: decompile
    }

    public void start() {
    }

    public void stop() {
    }

    private void checkPlayersInDarkness() {
    }

    private void flickerForDarkPlayers() {
    }

    private void flickerNearbyLight(Player arg0) {
    }

    private boolean isLightBlock(Material arg0) {
        return false;
    }

    private void appearInDarkness(Player arg0) {
    }

    public void triggerCaveHorror(Player arg0) {
    }

    private void playCaveSound(Player arg0) {
    }

    private boolean isUnderground(Location arg0) {
        return false;
    }

    private void lambda$triggerCaveHorror$0() {
    }

    private void lambda$appearInDarkness$0() {
    }

    private static void lambda$flickerNearbyLight$0(Block arg0, Material arg1) {
    }

    /* String constants found in bytecode:
       'darknessScore'
       'warnedPlayers'
       'lastGlobalAppear'
       'lastGlobalHorror'
       '§8§oDie Dunkelheit hier ist... lebendig.'
       '§8§oHörst du das Atmen? Es ist nicht deins.'
       '§8§oIn der Tiefe wartet etwas.'
       '§8§oDas Licht ist keine Sicherheit mehr.'
       '§8§oDie Schatten bewegen sich. Wirklich.'
       '§8§oZu tief gegraben. Zu weit gegangen.'
       '§8§oDie Höhle kennt deinen Namen.'
       '§8§oNicht alle, die in die Tiefe gehen, kommen zurück.'
       'CAVE_MESSAGES'
       'getVisuals'
       'getConfig'
       'isCaveDwellerEnabled'
       'getLogger'
       'getCaveCheckInterval'
       'runTaskTimer'
       'getCaveDarkLightLevel'
       'getCaveDarknessWarningAt'
       'getCaveDarknessAppearAt'
       'getCaveDarknessHorrorAt'
       'getOnlinePlayers'
       'getBotPlayer'
       'getLocation'
       'getLightLevel'
       'isUnderground'
       'getUniqueId'
       'getOrDefault'
       'getCaveWarningMessages'
       'sendMessage'
       'playCaveSound'
       'nextDouble'
       'currentTimeMillis'
       'appearInDarkness'
       'triggerCaveHorror'
       'isCaveLightFlickerEnabled'
       'getCavesConfig'
       'light_flicker.chance'
    */
}