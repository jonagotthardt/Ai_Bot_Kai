package com.jonasmp.ai.watcher;

public class WatcherProtection implements Listener {

    private final WatcherCore core;

    public WatcherProtection(WatcherCore arg0) {
        // TODO: decompile
    }

    public void register() {
    }

    private boolean isWatcher(Entity arg0) {
        return false;
    }

    public void onAnyDamage(EntityDamageEvent arg0) {
    }

    public void onEntityDamageByEntity(EntityDamageByEntityEvent arg0) {
    }

    public void onEntityTarget(EntityTargetEvent arg0) {
    }

    public void onPotionSplash(PotionSplashEvent arg0) {
    }

    public void onInteractEntity(PlayerInteractEntityEvent arg0) {
    }

    public void zeroVelocityIfWatcher(Player arg0) {
    }

    /* String constants found in bytecode:
       'getPluginManager'
       'registerEvents'
       'getConfig'
       'getWatcherName'
       'getEntity'
       'isWatcher'
       'setCancelled'
       'setDamage'
       'getDamager'
       'getShooter'
       '§8[§4Watcher§8] §cYou cannot attack the Watcher.'
       'sendMessage'
       'getTarget'
       'setTarget'
       'getAffectedEntities'
       'setIntensity'
       'getRightClicked'
       'getPlayer'
       '§8[§4Watcher§8] §cYou cannot interact with the Watcher.'
       'getRandom'
       'setVelocity'
       'LineNumberTable'
       'LocalVariableTable'
       'watcherName'
       'StackMapTable'
       'onAnyDamage'
       'RuntimeVisibleAnnotations'
       'ignoreCancelled'
       'onEntityDamageByEntity'
       'onEntityTarget'
       'onPotionSplash'
       'onInteractEntity'
       'zeroVelocityIfWatcher'
       'SourceFile'
       'WatcherProtection.java'
    */
}