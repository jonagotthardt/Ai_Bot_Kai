package com.jonasmp.ai.watcher;

public class TeaseBehavior {

    private static final String TARGET;
    private static final long MESSAGE_COOLDOWN_TICKS;
    private static final long STARE_COOLDOWN_TICKS;
    private static final long CHECK_INTERVAL;
    private final Random random;
    private final WatcherCore core;
    private BukkitRunnable task;
    private long lastMessageTick;
    private long lastStareTick;
    private String lastAction;
    private static final String[] TEASE_MESSAGES;
    private static final String[] ACTION_REACTIONS;

    public TeaseBehavior(WatcherCore arg0) {
        // TODO: decompile
    }

    public void start() {
    }

    public void stop() {
    }

    private void tick() {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'lastMessageTick'
       'lastStareTick'
       'lastAction'
       'getLogger'
       'getPlayerExact'
       'getMethod'
       'booleanValue'
       'getAIPlayerBot'
       'isSpawned'
       'getNMSBot'
       'getPlayer'
       'getFullTime'
       'nextDouble'
       'TEASE_MESSAGES'
       'getLocation'
       'getHighestBlockYAt'
       'toDegrees'
       'setRotation'
       'ACTION_REACTIONS'
       'Hey mka197, ich beobachte dich...'
       'mka197, baust du da was Verbotenes?'
       'mka197, dein Inventar sieht... interessant aus.'
       'Hast du Angst vor mir, mka197?'
       'mka197, ich weiß wo dein Haus ist...'
       'Du gruselst mich, mka197. Ehrlich.'
       'mka197, soll ich was fuer dich abbauen?'
       'Hey mka197, rate mal was ich denke...'
       'mka197, du wirkst heute besonders... lebendig.'
       'Ich folge dir, mka197. Immer.'
       'Nice Block, mka197!'
       'mka197, das sieht gefaehrlich aus...'
       'Bergbau ist Leben, oder mka197?'
       'mka197, pass auf deine Gesundheit auf!'
       'ConstantValue'
       'MESSAGE_COOLDOWN_TICKS'
       'STARE_COOLDOWN_TICKS'
       'CHECK_INTERVAL'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
    */
}