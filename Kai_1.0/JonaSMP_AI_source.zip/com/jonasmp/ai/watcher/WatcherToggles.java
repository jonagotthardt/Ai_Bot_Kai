package com.jonasmp.ai.watcher;

public class WatcherToggles {

    private static final List ALL_EVENTS;
    private final File file;
    private YamlConfiguration config;

    public WatcherToggles() {
        // TODO: decompile
    }

    private void load() {
    }

    private void setDefaults() {
    }

    private void ensureDefaults() {
    }

    public void save() {
    }

    public boolean isBotEnabled() {
        return false;
    }

    public boolean isHorrorGlobalEnabled() {
        return false;
    }

    public boolean isBrokenScriptEnabled() {
        return false;
    }

    public boolean isEventEnabled(String arg0) {
        return false;
    }

    public boolean toggleBot() {
        return false;
    }

    public boolean toggleHorrorGlobal() {
        return false;
    }

    public boolean toggleBrokenScript() {
        return false;
    }

    public boolean toggleEvent(String arg0) {
        return false;
    }

    public List getAllEventTypes() {
        return null;
    }

    public String getToggleStatus() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'getDataFolder'
       'toggles.yml'
       'setDefaults'
       'loadConfiguration'
       'ensureDefaults'
       'bot_enabled'
       'horror_global_enabled'
       'broken_script_enabled'
       'ALL_EVENTS'
       'makeConcatWithConstants'
       'getLogger'
       'getMessage'
       'getBoolean'
       'isBotEnabled'
       'isHorrorGlobalEnabled'
       'isBrokenScriptEnabled'
       'isEventEnabled'
       '§eHorror Global: '
       '§eBroken Script: '
       'block_corruption'
       'item_vanish'
       'door_anomaly'
       'chest_anomaly'
       'torch_extinguish'
       'fake_chat'
       'health_glitch'
       'camera_glitch'
       'entity_swap'
       'sound_glitch'
       'inventory_shuffle'
       'sky_glitch'
       'block_under_foot'
       'broken_script_end'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'eventType'
       'toggleBot'
       'toggleHorrorGlobal'
    */
}