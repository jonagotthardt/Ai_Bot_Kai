package com.jonasmp.ai.watcher;

public class CraftingPlanner {

    private static final int MAX_STICKS;
    private static final int MAX_PLANKS;
    private static final int MIN_LOGS;
    private static final int MIN_PLANKS;
    private static final double MIN_HP_ARMOR;
    private static final List LOGS;
    private static final List PLANKS;
    private static final List WOOLS;

    private CraftingPlanner() {
        // TODO: decompile
    }

    public static void craftIfNeeded(Player arg0) {
    }

    private static boolean reserveOK(int arg0, int arg1, int arg2, int arg3) {
        return false;
    }

    private static int countItem(PlayerInventory arg0, Material arg1) {
        return 0;
    }

    private static int countAny(PlayerInventory arg0, List arg1) {
        return 0;
    }

    private static boolean hasItem(Player arg0, Material arg1) {
        return false;
    }

    private static void removeItems(PlayerInventory arg0, Material arg1, int arg2) {
    }

    private static void removeAnyPlanks(PlayerInventory arg0, int arg1) {
    }

    private static void removeAnyWool(PlayerInventory arg0, int arg1) {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'getInventory'
       'countItem'
       'removeItems'
       'removeAnyPlanks'
       'WOODEN_SWORD'
       'reserveOK'
       'WOODEN_AXE'
       'WOODEN_PICKAXE'
       'COBBLESTONE'
       'STONE_SWORD'
       'STONE_AXE'
       'STONE_PICKAXE'
       'WHITE_BED'
       'removeAnyWool'
       'getHealth'
       'LEATHER_HELMET'
       'LEATHER_CHESTPLATE'
       'LEATHER_LEGGINGS'
       'LEATHER_BOOTS'
       'getContents'
       'getAmount'
       'setAmount'
       'BIRCH_LOG'
       'SPRUCE_LOG'
       'JUNGLE_LOG'
       'ACACIA_LOG'
       'DARK_OAK_LOG'
       'MANGROVE_LOG'
       'CHERRY_LOG'
       'OAK_PLANKS'
       'SPRUCE_PLANKS'
       'BIRCH_PLANKS'
       'JUNGLE_PLANKS'
       'ACACIA_PLANKS'
       'DARK_OAK_PLANKS'
       'MANGROVE_PLANKS'
       'CHERRY_PLANKS'
       'BAMBOO_PLANKS'
       'WHITE_WOOL'
       'ORANGE_WOOL'
    */
}