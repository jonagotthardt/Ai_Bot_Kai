package com.jonasmp.ai.watcher;

public class WatcherVisuals$1 extends BukkitRunnable {

     int tick;
     long nextSoundTick;
    final WatcherVisuals this$0;

     WatcherVisuals$1(WatcherVisuals arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'nextSoundTick'
       'isRunning'
       'particleTask'
       'getBotPlayer'
       'getLocation'
       '$SwitchMap$com$jonasmp$ai$watcher$WatcherState'
       'spawnParticle'
       'SOUL_FIRE_FLAME'
       'spawnEyeParticles'
       'playAmbientSound'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'WatcherVisuals.java'
       'EnclosingMethod'
       'startParticleAura'
       'InnerClasses'
    */
}