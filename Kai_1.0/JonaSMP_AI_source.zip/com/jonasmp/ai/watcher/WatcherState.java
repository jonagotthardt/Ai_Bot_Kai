package com.jonasmp.ai.watcher;

public class WatcherState extends Enum {

    public static final WatcherState IDLE;
    public static final WatcherState OBSERVING;
    public static final WatcherState INVESTIGATING;
    public static final WatcherState VISIBLE;
    public static final WatcherState LORE;
    public static final WatcherState HORROR;
    public static final WatcherState FREEZING;
    public static final WatcherState DISABLED;
    private static final WatcherState[] $VALUES;

    public static WatcherState[] values() {
        return null;
    }

    public static WatcherState valueOf(String arg0) {
        return null;
    }

    private WatcherState(String arg0, int arg1) {
        // TODO: decompile
    }

    private static WatcherState[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'OBSERVING'
       'INVESTIGATING'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'WatcherState.java'
    */
}