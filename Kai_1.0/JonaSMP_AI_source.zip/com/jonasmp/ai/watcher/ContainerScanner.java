package com.jonasmp.ai.watcher;

public class ContainerScanner {

    public ContainerScanner() {
        // TODO: decompile
    }

    public static ContainerScanner$ContainerScanResult scanBlock(Block arg0) {
        return null;
    }

    public static Block findNearestContainer(Player arg0, Material[] arg1, double arg2) {
        return null;
    }

    /* String constants found in bytecode:
       'getInventory'
       'getAmount'
       'makeConcatWithConstants'
       'getLogger'
       'getInstance'
       'getChunkRadar'
       'getLocation'
       'getBlockX'
       'getBlockY'
       'getBlockZ'
       'getBlockAt'
       'LineNumberTable'
       'LocalVariableTable'
       'scanBlock'
       'containerType'
       'totalItems'
       'LocalVariableTypeTable'
       'StackMapTable'
       'findNearestContainer'
       'maxDistance'
       'minDistSq'
       'SourceFile'
       'ContainerScanner.java'
       'NestMembers'
       'BootstrapMethods'
       'InnerClasses'
       'ContainerScanResult'
    */
}