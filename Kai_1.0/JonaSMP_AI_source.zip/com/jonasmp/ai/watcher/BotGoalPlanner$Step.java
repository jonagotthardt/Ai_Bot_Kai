package com.jonasmp.ai.watcher;

public class BotGoalPlanner$Step {

    public final String id;
    public final String description;
    public final BotGoalPlanner$StepAction action;
    public final BotGoalPlanner$StepCondition condition;
    public final BotGoalPlanner$StepFallback fallback;

    public BotGoalPlanner$Step(String arg0, String arg1, BotGoalPlanner$StepAction arg2, BotGoalPlanner$StepCondition arg3, BotGoalPlanner$StepFallback arg4) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'description'
       'condition'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'BotGoalPlanner.java'
       'InnerClasses'
       'StepAction'
       'StepCondition'
       'StepFallback'
    */
}