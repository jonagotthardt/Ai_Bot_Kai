package com.jonasmp.ai.watcher;

public class WatcherCore$1 extends BukkitRunnable {

    final WatcherCore this$0;

     WatcherCore$1(WatcherCore arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'playerData'
       'getStrikeDecayMinutes'
       'decayStrikes'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'WatcherCore.java'
       'EnclosingMethod'
       'startTickLoop'
       'InnerClasses'
    */
}