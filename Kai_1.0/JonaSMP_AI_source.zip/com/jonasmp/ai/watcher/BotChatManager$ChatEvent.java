package com.jonasmp.ai.watcher;

public class BotChatManager$ChatEvent extends Record {

    private final String type;
    private final String context;
    private final boolean critical;

    private BotChatManager$ChatEvent(String arg0, String arg1, boolean arg2) {
        // TODO: decompile
    }

    public final String toString() {
        return null;
    }

    public final int hashCode() {
        return 0;
    }

    public final boolean equals(Object arg0) {
        return false;
    }

    public String type() {
        return null;
    }

    public String context() {
        return null;
    }

    public boolean critical() {
        return false;
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'SourceFile'
       'BotChatManager.java'
       'BootstrapMethods'
       'type;context;critical'
       'bootstrap'
       'InnerClasses'
       'ChatEvent'
    */
}