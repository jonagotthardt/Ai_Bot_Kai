package com.jonasmp.ai.watcher;

public class BotMemoryStorage {

    private final Gson gson;
    private final File folder;

    public BotMemoryStorage() {
        // TODO: decompile
    }

    public void save(BotMemory arg0) {
    }

    public BotMemory load(UUID arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'getDataFolder'
       'bot_memory'
       'makeConcatWithConstants'
       'currentTimeMillis'
       'lastSaved'
       'getLogger'
       'getMessage'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'BotMemoryStorage.java'
       'BootstrapMethods'
       'InnerClasses'
    */
}