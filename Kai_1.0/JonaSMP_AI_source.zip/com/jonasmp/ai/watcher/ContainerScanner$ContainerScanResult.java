package com.jonasmp.ai.watcher;

public class ContainerScanner$ContainerScanResult {

    public final String type;
    public final Map slots;
    public final int totalItems;
    public final boolean isEmpty;

    public ContainerScanner$ContainerScanResult(String arg0, Map arg1, int arg2) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'totalItems'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'LocalVariableTypeTable'
       'StackMapTable'
       'SourceFile'
       'ContainerScanner.java'
       'InnerClasses'
       'ContainerScanResult'
    */
}