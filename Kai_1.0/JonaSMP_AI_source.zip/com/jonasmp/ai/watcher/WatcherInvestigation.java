package com.jonasmp.ai.watcher;

public class WatcherInvestigation {

    private final WatcherCore core;
    private long lastEscalationCheck;

    public WatcherInvestigation(WatcherCore arg0) {
        // TODO: decompile
    }

    public void tick(Player arg0) {
    }

    public void onPipelineResult(Player arg0, ChatModerationPipeline$PipelineResult arg1) {
    }

    private void updateInvestigationScore(WatcherPlayerData arg0) {
    }

    private void checkEscalation(Player arg0, WatcherPlayerData arg1) {
    }

    public void clearInvestigation(UUID arg0) {
    }

    private void notifyAdmins(String arg0) {
    }

    private static void lambda$notifyAdmins$1(String arg0, Player arg1) {
    }

    private static boolean lambda$notifyAdmins$0(Player arg0) {
        return false;
    }

    /* String constants found in bytecode:
       'lastEscalationCheck'
       'currentTimeMillis'
       'getUniqueId'
       'getPlayerData'
       'updateInvestigationScore'
       'checkEscalation'
       'ensurePlayerData'
       'addInvestigationScore'
       'incrementSuspiciousChatStrikes'
       'getInvestigationScore'
       'isUnderInvestigation'
       'beginInvestigation'
       'getAntiCheatStrikes'
       'getSuspiciousChatStrikes'
       'getSuspiciousCombatStrikes'
       'getSuspiciousMovementStrikes'
       'getXrayIndicators'
       'getTotalStrikes'
       'setInvestigationScore'
       'getLogger'
       'makeConcatWithConstants'
       'showVisible'
       'getConfig'
       'isFreezeEnabled'
       'freezePlayer'
       'notifyAdmins'
       'setUnderInvestigation'
       'getOnlinePlayers'
       'sendMessage'
       'jonasmpai.watcher.notify'
       'hasPermission'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'onPipelineResult'
       'clearInvestigation'
       'formatted'
       'lambda$notifyAdmins$1'
       'lambda$notifyAdmins$0'
       'SourceFile'
    */
}