package com.jonasmp.ai.watcher;

public class WatcherAmbientHorror$1 extends BukkitRunnable {

     int tick;
     long nextEventTick;
    final int val$intervalMin;
    final int val$intervalMax;
    final WatcherAmbientHorror this$0;

     WatcherAmbientHorror$1(WatcherAmbientHorror arg0, int arg1, int arg2) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'val$intervalMin'
       'val$intervalMax'
       'requireNonNull'
       'nextEventTick'
       'isRunning'
       'ambientTask'
       'tryRandomAmbientEvent'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'WatcherAmbientHorror.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}