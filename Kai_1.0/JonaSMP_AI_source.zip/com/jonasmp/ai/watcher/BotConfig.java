package com.jonasmp.ai.watcher;

public class BotConfig {

    private static final File CONFIG_DIR;
    private static FileConfiguration behavior;
    private static FileConfiguration goals;
    private static FileConfiguration debug;
    private static FileConfiguration inventory;
    private static FileConfiguration prompts;

    public BotConfig() {
        // TODO: decompile
    }

    public static void reload() {
    }

    private static FileConfiguration loadOrCreate(String arg0, String arg1) {
        return null;
    }

    public static String getString(String arg0, String arg1) {
        return null;
    }

    public static int getInt(String arg0, int arg1) {
        return 0;
    }

    public static double getDouble(String arg0, double arg1) {
        return 0.0;
    }

    public static boolean getBoolean(String arg0, boolean arg1) {
        return false;
    }

    public static List getStringList(String arg0) {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'CONFIG_DIR'
       'behavior.yml'
       'loadOrCreate'
       'goals.yml'
       'debug.yml'
       'inventory.yml'
       'inventory'
       'prompts.yml'
       'getLogger'
       'getMessage'
       'makeConcatWithConstants'
       'loadConfiguration'
       'getString'
       'getDouble'
       'getBoolean'
       'getStringList'
       'getDataFolder'
       'bot_config'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'defaultContent'
       'Signature'
       'SourceFile'
       'BotConfig.java'
       'BootstrapMethods'
       'InnerClasses'
    */
}