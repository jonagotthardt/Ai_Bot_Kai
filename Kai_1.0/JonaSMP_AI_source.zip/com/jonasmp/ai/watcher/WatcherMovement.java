package com.jonasmp.ai.watcher;

public class WatcherMovement {

    private final WatcherCore core;
    private final WatcherBot bot;
    private final Random random;
    private final List patrolPoints;
    private int currentPatrolIndex;
    private long nextPatrolMove;
    private long nextLookChange;
    private long lastFollowUpdate;
    private Location lastTargetLoc;
    private double offsetX;
    private double offsetZ;
    private long offsetResetTime;

    public WatcherMovement(WatcherCore arg0) {
        // TODO: decompile
    }

    public void observe(Player arg0) {
    }

    public void investigate(Player arg0) {
    }

    public void approach(Player arg0, double arg1) {
    }

    public void teleportNear(Player arg0, int arg1) {
    }

    public void teleportTo(Location arg0) {
    }

    public void patrol() {
    }

    private void randomWander() {
    }

    private void maintainDistance(Player arg0, int arg1) {
    }

    private void moveAway(Player arg0, double arg1) {
    }

    private void naturalLookAt(Player arg0) {
    }

    private void randomHeadMovement() {
    }

    private void loadPatrolPoints() {
    }

    /* String constants found in bytecode:
       'patrolPoints'
       'currentPatrolIndex'
       'nextPatrolMove'
       'nextLookChange'
       'lastFollowUpdate'
       'lastTargetLoc'
       'offsetResetTime'
       'loadPatrolPoints'
       'currentTimeMillis'
       'getLocation'
       'getConfig'
       'getFollowDistance'
       'teleportNear'
       'maintainDistance'
       'naturalLookAt'
       'getInvestigationDistance'
       'getEyeLocation'
       'smoothLookAt'
       'nextDouble'
       'getHighestBlockYAt'
       'getAIPlayerBot'
       'getGoalPlanner'
       'getCurrentGoal'
       'randomWander'
       'getPatrolSpeed'
       'randomHeadMovement'
       'nextFloat'
       'loadPatrolConfigs'
       'getConfigurationSection'
       'makeConcatWithConstants'
       'getString'
       'getDouble'
       'getLogger'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'targetLoc'
       'followDist'
       'StackMapTable'
       'investigate'
    */
}