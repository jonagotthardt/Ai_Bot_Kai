package com.jonasmp.ai.watcher;

public class WatcherBrokenScript implements Listener {

    private final WatcherCore core;
    private final Random random;
    private BukkitRunnable mainTask;
    private boolean running;
    private final Map keywordMap;
    private final Map keywordCooldown;
    private final Set brokenPlayers;

    public WatcherBrokenScript(WatcherCore arg0) {
        // TODO: decompile
    }

    private void initKeywords() {
    }

    public void start() {
    }

    public void stop() {
    }

    private void tryRandomEvent() {
    }

    public void triggerRandomEventOn(Player arg0) {
    }

    public void triggerSpecificEvent(Player arg0, String arg1) {
    }

    private void executeEvent(Player arg0, String arg1) {
    }

    private void checkParanoia() {
    }

    public void onPlayerChat(AsyncPlayerChatEvent arg0) {
    }

    public void forceBrokenScriptEnd(Player arg0) {
    }

    public void forceTempBan(Player arg0, int arg1) {
    }

    public boolean isPlayerBroken(Player arg0) {
        return false;
    }

    public Set getBrokenPlayers() {
        return null;
    }

    private Player getRandomOnlinePlayer() {
        return null;
    }

    private boolean lambda$getRandomOnlinePlayer$1(Player arg0) {
        return false;
    }

    private boolean lambda$getRandomOnlinePlayer$0(Player arg0) {
        return false;
    }

    private void lambda$onPlayerChat$0(Player arg0, String arg1) {
    }

    /* String constants found in bytecode:
       'keywordMap'
       'keywordCooldown'
       'brokenPlayers'
       'initKeywords'
       'fake_chat'
       'sound_glitch'
       'herobrine'
       'camera_glitch'
       'block_corruption'
       'health_glitch'
       'inventory_shuffle'
       'sky_glitch'
       'door_anomaly'
       'torch_extinguish'
       'block_under_foot'
       'chest_anomaly'
       'item_vanish'
       'getConfig'
       'isBrokenScriptEnabled'
       'getLogger'
       'getToggles'
       'getPluginManager'
       'registerEvents'
       'getBrokenScriptEventIntervalMin'
       'getBrokenScriptEventIntervalMax'
       'runTaskTimer'
       'unregisterAll'
       'getRandomOnlinePlayer'
       'triggerRandomEventOn'
       'isHorrorGlobalEnabled'
       'getBrokenScriptEnabledEvents'
       'executeEvent'
       'getAIPlayerBot'
       'isBotPlayer'
       'isEventEnabled'
       'makeConcatWithConstants'
       'entity_swap'
       'broken_script_end'
       'blockCorruption'
       'itemVanish'
    */
}