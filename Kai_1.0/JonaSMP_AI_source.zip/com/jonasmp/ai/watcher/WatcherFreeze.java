package com.jonasmp.ai.watcher;

public class WatcherFreeze implements Listener {

    private final WatcherCore core;
    private final Map frozenPlayers;
    private boolean listenerRegistered;

    public WatcherFreeze(WatcherCore arg0) {
        // TODO: decompile
    }

    public void freeze(UUID arg0) {
    }

    public void unfreeze(UUID arg0) {
    }

    public void unfreezeAll() {
    }

    public void tick(UUID arg0) {
    }

    public boolean isFrozen(UUID arg0) {
        return false;
    }

    private void ensureListener() {
    }

    public void onMove(PlayerMoveEvent arg0) {
    }

    public void onBlockBreak(BlockBreakEvent arg0) {
    }

    public void onBlockPlace(BlockPlaceEvent arg0) {
    }

    public void onCombat(EntityDamageByEntityEvent arg0) {
    }

    private void lambda$freeze$0(UUID arg0) {
    }

    /* String constants found in bytecode:
       'frozenPlayers'
       'listenerRegistered'
       'getPlayer'
       'getConfig'
       'getFreezeDurationSeconds'
       'currentTimeMillis'
       'getLocation'
       'getFreezeMessage'
       '§c§lFREEZE'
       'makeConcatWithConstants'
       'sendTitle'
       'sendMessage'
       'ensureListener'
       'getLogger'
       'getScheduler'
       'runTaskLater'
       '§a[Watcher] Freeze lifted. You may move again.'
       'unregisterAll'
       'lockLocation'
       'containsKey'
       'getPluginManager'
       'registerEvents'
       'getUniqueId'
       'setCancelled'
       'getDamager'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'expiresAt'
       'StackMapTable'
       'unfreezeAll'
       'RuntimeVisibleAnnotations'
       'onBlockBreak'
       'onBlockPlace'
       'lambda$freeze$0'
       'SourceFile'
       'WatcherFreeze.java'
       'NestMembers'
       'BootstrapMethods'
       'metafactory'
    */
}