package com.jonasmp.ai.watcher;

public class BotAutoEquipper {

    private final AIPlayerBot aiBot;
    private final NMSBot nmsBot;
    private Runnable onBuyCallback;
    private int buyCooldown;
    private int commandCooldown;
    private int equipCheckCooldown;
    private boolean starterKitDone;
    private int lastDeathCount;
    private static final int COMMAND_COOLDOWN_TICKS;
    private static final int EQUIP_CHECK_INTERVAL;
    private static final String[][] STARTER_KIT;
    private static final String[][] STARTER_KIT_DIAMOND;
    private static final String[][] STARTER_KIT_IRON;

    public BotAutoEquipper(AIPlayerBot arg0, NMSBot arg1) {
        // TODO: decompile
    }

    public void setOnBuyCallback(Runnable arg0) {
    }

    public void tick(Player arg0) {
    }

    private boolean buyStarterKit() {
        return false;
    }

    private void checkAndBuyMissing(Player arg0) {
    }

    public void onCombatStart(Player arg0) {
    }

    private boolean sendShopBuy(String arg0, String arg1) {
        return false;
    }

    private boolean hasInInventory(String arg0, int arg1) {
        return false;
    }

    private int countInInventory(Material arg0) {
        return 0;
    }

    private boolean hasArmorEquipped() {
        return false;
    }

    private boolean hasWeapon() {
        return false;
    }

    private boolean hasAnyArmorPiece() {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'onBuyCallback'
       'buyCooldown'
       'commandCooldown'
       'equipCheckCooldown'
       'starterKitDone'
       'lastDeathCount'
       'getStatistic'
       'getHealth'
       'buyStarterKit'
       'autoEquipBestGear'
       'checkAndBuyMissing'
       'STARTER_KIT'
       'STARTER_KIT_DIAMOND'
       'STARTER_KIT_IRON'
       'hasInInventory'
       'sendShopBuy'
       'getInventory'
       'hasArmorEquipped'
       'hasAnyArmorPiece'
       'NETHERITE_CHESTPLATE'
       'DIAMOND_CHESTPLATE'
       'IRON_CHESTPLATE'
       'hasWeapon'
       'NETHERITE_SWORD'
       'DIAMOND_SWORD'
       'IRON_SWORD'
       'GOLDEN_APPLE'
       'countInInventory'
       'COOKED_BEEF'
       'COOKED_PORKCHOP'
       'GOLDEN_CARROT'
       'WIND_CHARGE'
       'selectBestWeapon'
       'getPlayer'
       'SHOP_BRIDGE'
       'getLogger'
       'totalPrice'
       'makeConcatWithConstants'
       'getMessage'
       'getMaterial'
    */
}