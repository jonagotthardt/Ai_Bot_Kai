package com.jonasmp.ai.watcher;

public class BotGoalPlanner$StepAction {

    public abstract boolean execute(Player arg0, NMSBot arg1, BotGoalPlanner arg2) {
        return false;
    }

    /* String constants found in bytecode:
       'SourceFile'
       'BotGoalPlanner.java'
       'InnerClasses'
       'StepAction'
    */
}