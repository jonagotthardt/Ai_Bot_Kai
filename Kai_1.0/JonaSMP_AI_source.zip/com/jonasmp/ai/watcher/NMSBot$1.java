package com.jonasmp.ai.watcher;

public class NMSBot$1 extends BukkitRunnable {

     int attempts;
    final String val$botName;
    final NMSBot this$0;

     NMSBot$1(NMSBot arg0, String arg1) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'val$botName'
       'requireNonNull'
       'tryInitializeBot'
       'getLogger'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'NMSBot.java'
       'EnclosingMethod'
       'createEntity'
       'InnerClasses'
    */
}