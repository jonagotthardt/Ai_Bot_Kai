package com.jonasmp.ai.watcher;

public class NMSBot {

    private Object serverPlayer;
    private Player craftPlayer;
    private UUID uuid;
    private String name;
    private boolean spawned;
    private Location currentLoc;
    private long lastRespawnTime;
    private static final long RESPAWN_COOLDOWN_MS;
    private Object fppBot;
    private static final String HEROBRINE_SKIN_VALUE;
    private static final String HEROBRINE_SKIN_SIGNATURE;
    private static Object fppApi;
    private Method cachedSetYRot;
    private Method cachedSetXRot;
    private long lastJumpTime;
    private static final long JUMP_COOLDOWN_MS;
    private Block miningTarget;
    private int miningProgress;
    private int miningRequired;
    private boolean isMiningActive;

    public NMSBot() {
        // TODO: decompile
    }

    public void spawn(Location arg0, String arg1) {
    }

    public void spawn(Location arg0, String arg1, UUID arg2) {
    }

    private void preloadLuckPermsUser(UUID arg0, String arg1) {
    }

    private void fetchSkinAndSpawn(Location arg0, String arg1) {
    }

    private Object getFppApi() {
        return null;
    }

    private void createEntity(Location arg0, String arg1, String arg2, String arg3) {
    }

    private boolean tryInitializeBot(String arg0) {
        return false;
    }

    private void injectSkin(ClassLoader arg0, Object arg1, String arg2, String arg3) {
    }

    private Object resolvePropertyMap(Object arg0) {
        return null;
    }

    private void clearExistingTextures(Object arg0) {
    }

    private Object createFakeConnection(ClassLoader arg0) {
        return null;
    }

    private Object createNullChannel(ClassLoader arg0) {
        return null;
    }

    private boolean placePlayer(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4) {
        return false;
    }

    private Object createCookie(Object arg0, Object arg1) {
        return null;
    }

    private void ensurePlayerData(Object arg0, Object arg1, UUID arg2) {
    }

    private Object[] injectMinimalListener(ClassLoader arg0, Object arg1, Object arg2, Object arg3, Object arg4) {
        return null;
    }

    private void addToPlayerList(Object arg0, Object arg1) {
    }

    private void initPreviousPosition(Object arg0, double arg1, double arg2, double arg3) {
    }

    private void broadcastSpawnPackets(Object arg0) {
    }

    public void despawn() {
    }

    private void removeFromPlayerList() {
    }

    public void teleport(Location arg0) {
    }

    public void setRotation(float arg0, float arg1) {
    }

    public void lookAt(Location arg0) {
    }

    public void moveNMS(double arg0, double arg1, double arg2) {
    }

    public void walkRelative(double arg0, double arg1) {
    }

    public void jump() {
    }

    public void navigateTo(Location arg0) {
    }

    public void cancelNavigation() {
    }

    public boolean isNavigating() {
        return false;
    }

    public void tickPhysics() {
    }

    private void updateLocationFromNMS() {
    }

    public void respawnPlayer() {
    }

    public boolean placeBlock(Block arg0) {
        return false;
    }

    public void dropItem(int arg0) {
    }

    public void dropItemsOfType(Material arg0, int arg1) {
    }

    public void openCrafting() {
    }

    public void vanish() {
    }

    public void unvanish() {
    }

    public void setGlowing(boolean arg0) {
    }

    public void setInvisible(boolean arg0) {
    }

    public void swingMainHand() {
    }

    public void useItem() {
    }

    public void useOffhandItem() {
    }

    public void selectHotbarSlot(int arg0) {
    }

    public void sendChat(String arg0) {
    }

    public void performCommand(String arg0) {
    }

    private boolean breakBlockInternal(Block arg0) {
        return false;
    }

    public boolean breakBlock(Block arg0) {
        return false;
    }

    public int startMining(Block arg0) {
        return 0;
    }

    public boolean tickMining() {
        return false;
    }

    public boolean finishMining() {
        return false;
    }

    public void cancelMining() {
    }

    public boolean isMining() {
        return false;
    }

    public Block getMiningTarget() {
        return null;
    }

    public int getMiningProgress() {
        return 0;
    }

    public int getMiningRequired() {
        return 0;
    }

    public int equipBestTool(Material arg0) {
        return 0;
    }

    private int getToolSpeed(Material arg0, Material arg1) {
        return 0;
    }

    private void broadcastPacketToSelf(Object arg0) {
    }

    private Object getFieldValue(Object arg0, String arg1) {
        return null;
    }

    public Player getPlayer() {
        return null;
    }

    public boolean isSpawned() {
        return false;
    }

    public String getName() {
        return null;
    }

    private Method findMethod(Class arg0, String arg1, int arg2, Class[] arg3) {
        return null;
    }

    private Field findField(Class arg0, String arg1) {
        return null;
    }

    private List getAllMethods(Class arg0) {
        return null;
    }

    private List getAllFields(Class arg0) {
        return null;
    }

    private String extractJson(String arg0, String arg1) {
        return null;
    }

    private static Object lambda$createNullChannel$2(Class arg0, Class arg1, Object arg2, Class arg3, Class arg4, Object arg5, Class arg6, Class arg7, Object arg8, Method arg9, Object[] arg10) {
        return null;
    }

    private static Object lambda$createNullChannel$1(Class arg0, Class arg1, Class arg2, Object arg3, Class arg4, Object arg5, Method arg6, Object[] arg7) {
        return null;
    }

    private static Object lambda$createNullChannel$0(Class arg0, Object arg1, Method arg2, Object[] arg3) {
        return null;
    }

    private void lambda$fetchSkinAndSpawn$0(Location arg0, String arg1) {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'lastRespawnTime'
       'lastJumpTime'
       'miningProgress'
       'miningRequired'
       'isMiningActive'
       'currentLoc'
       'randomUUID'
       'getLogger'
       'makeConcatWithConstants'
       'preloadLuckPermsUser'
       'fetchSkinAndSpawn'
       'getUserManager'
       'getSimpleName'
       'getMessage'
       'getScheduler'
       'getPluginManager'
       'FakePlayerPlugin'
       'getPlugin'
       'getFppApi'
       'getMethod'
       'isPresent'
       'booleanValue'
       'getPlayerExact'
       'craftPlayer'
       'getMethods'
       'getParameterCount'
       'getParameterTypes'
       'tryInitializeBot'
       'runTaskTimer'
       'printStackTrace'
       'getPlayer'
       'getBukkitPlayer'
       'getEntity'
       'getCraftPlayer'
       'getReturnType'
       'isAssignableFrom'
       'getUniqueId'
       'getServer'
       'getClassLoader'
       'net.minecraft.server.level.ServerPlayer'
    */
}