package com.jonasmp.ai.watcher;

public class WatcherLore {

    private final WatcherCore core;
    private final Random random;
    private long lastAppearance;
    private long nextAppearanceRoll;

    public WatcherLore(WatcherCore arg0) {
        // TODO: decompile
    }

    public void tick() {
    }

    public void triggerAppearance(Player arg0) {
    }

    private void playLoreSound(Player arg0) {
    }

    private void sendLoreTitle(Player arg0) {
    }

    private void lambda$triggerAppearance$0() {
    }

    /* String constants found in bytecode:
       'lastAppearance'
       'nextAppearanceRoll'
       'getConfig'
       'isLoreModeEnabled'
       'currentTimeMillis'
       'getLoreChancePercent'
       'getOnlinePlayers'
       'INVESTIGATING'
       'triggerAppearance'
       'getUniqueId'
       'ensurePlayerData'
       'getLoreEffectCooldownMinutes'
       'getLastLoreAppearance'
       'incrementLoreAppearances'
       'getLogger'
       'makeConcatWithConstants'
       'getLoreMinDistance'
       'getLoreMaxDistance'
       'nextDouble'
       'getLocation'
       'getHighestBlockYAt'
       'getEyeLocation'
       'playLoreSound'
       'sendLoreTitle'
       'getScheduler'
       'runTaskLater'
       'lore_appear'
       'lore_stare'
       'lore_vanish'
       'isSoundEnabled'
       'getSoundName'
       'toLowerCase'
       'fromString'
       'getSoundVolume'
       'getSoundPitch'
       'playSound'
       'getTitlePool'
       'getSubtitlePool'
       'sendTitle'
       'LineNumberTable'
    */
}