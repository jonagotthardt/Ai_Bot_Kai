package com.jonasmp.ai.watcher;

public class BurrowManager {

    private BurrowManager$BurrowState state;
    private int burrowTicks;
    private int escapeTicks;
    private long lastCheckTime;
    private static final long CHECK_INTERVAL_MS;
    private static final int MAX_BURROW_TICKS;
    private static final int MIN_ESCAPE_TICKS;
    private static final double BURROW_HP_THRESHOLD;
    private static final double MIN_ESCAPE_HEALTH;
    private static final double HEALING_HP_THRESHOLD;
    private static final int HEALING_PHASE_TICKS;
    private static final double MONSTER_CHECK_RANGE;
    private BiConsumer chatCallback;

    public BurrowManager() {
        // TODO: decompile
    }

    public boolean isBurrowed() {
        return false;
    }

    public boolean isHealingPhase() {
        return false;
    }

    public void setChatCallback(BiConsumer arg0) {
    }

    public boolean needsHealing(Player arg0) {
        return false;
    }

    public void tick(Player arg0, NMSBot arg1) {
    }

    private boolean hasMonstersNearby(Player arg0, double arg1) {
        return false;
    }

    private void tryBurrow(Player arg0, NMSBot arg1) {
    }

    private void handleBurrowedTick(Player arg0, NMSBot arg1, boolean arg2, double arg3) {
    }

    /* String constants found in bytecode:
       'NOT_BURROWED'
       'burrowTicks'
       'escapeTicks'
       'lastCheckTime'
       'chatCallback'
       'getHealth'
       'currentTimeMillis'
       'hasMonstersNearby'
       'tryBurrow'
       'handleBurrowedTick'
       'getLogger'
       'getNearbyEntities'
       'getLocation'
       'isProtected'
       'getInventory'
       'selectHotbarSlot'
       'placeBlock'
       'isAllowedToBreak'
       'swingMainHand'
       'breakNaturally'
       'isAllowedToPlace'
       'setHeldItemSlot'
       'getAmount'
       'setAmount'
       ' (forced escape)'
       'makeConcatWithConstants'
       'CHECK_INTERVAL_MS'
       'ConstantValue'
       'MAX_BURROW_TICKS'
       'MIN_ESCAPE_TICKS'
       'BURROW_HP_THRESHOLD'
       'MIN_ESCAPE_HEALTH'
       'HEALING_HP_THRESHOLD'
       'HEALING_PHASE_TICKS'
       'MONSTER_CHECK_RANGE'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'isBurrowed'
       'StackMapTable'
    */
}