package com.jonasmp.ai.watcher;

public class BurrowManager$BurrowState extends Enum {

    public static final BurrowManager$BurrowState NOT_BURROWED;
    public static final BurrowManager$BurrowState BURROWED;
    public static final BurrowManager$BurrowState ESCAPING;
    private static final BurrowManager$BurrowState[] $VALUES;

    public static BurrowManager$BurrowState[] values() {
        return null;
    }

    public static BurrowManager$BurrowState valueOf(String arg0) {
        return null;
    }

    private BurrowManager$BurrowState(String arg0, int arg1) {
        // TODO: decompile
    }

    private static BurrowManager$BurrowState[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'NOT_BURROWED'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'BurrowManager.java'
       'InnerClasses'
       'BurrowState'
    */
}