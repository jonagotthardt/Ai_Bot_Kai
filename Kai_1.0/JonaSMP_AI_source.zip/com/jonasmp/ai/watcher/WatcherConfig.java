package com.jonasmp.ai.watcher;

public class WatcherConfig {

    private final JavaPlugin plugin;
    private final File watcherDir;
    private YamlConfiguration mainConfig;
    private YamlConfiguration messagesConfig;
    private YamlConfiguration namesConfig;
    private YamlConfiguration skinsConfig;
    private YamlConfiguration soundsConfig;
    private YamlConfiguration titlesConfig;
    private YamlConfiguration triggersConfig;
    private YamlConfiguration loreConfig;
    private YamlConfiguration ambientConfig;
    private YamlConfiguration stalkingConfig;
    private YamlConfiguration cavesConfig;
    private YamlConfiguration brokenScriptConfig;
    private final File patrolsDir;
    private final File investigationDir;
    private final File loreDir;
    private final File logsDir;
    private final File ambientDir;
    private final File stalkingDir;
    private final File cavesDir;
    private final File brokenScriptDir;

    public WatcherConfig(JavaPlugin arg0) {
        // TODO: decompile
    }

    public void init() {
    }

    private void ensureDirs() {
    }

    private YamlConfiguration loadConfig(String arg0) {
        return null;
    }

    private int countConfigs() {
        return 0;
    }

    public boolean isEnabled() {
        return false;
    }

    public boolean isAiPlayerMode() {
        return false;
    }

    public String getWatcherName() {
        return null;
    }

    public boolean isVanishOnJoin() {
        return false;
    }

    public boolean isCollisionEnabled() {
        return false;
    }

    public boolean isInvulnerable() {
        return false;
    }

    public boolean showInTabList() {
        return false;
    }

    public boolean sendJoinLeaveMessages() {
        return false;
    }

    public int getFollowDistance() {
        return 0;
    }

    public int getInvestigationDistance() {
        return 0;
    }

    public double getPatrolSpeed() {
        return 0.0;
    }

    public int getObservationIntervalTicks() {
        return 0;
    }

    public int getStrikeDecayMinutes() {
        return 0;
    }

    public int getInvestigationThreshold() {
        return 0;
    }

    public boolean isFreezeEnabled() {
        return false;
    }

    public int getFreezeDurationSeconds() {
        return 0;
    }

    public String getFreezeMessage() {
        return null;
    }

    public String getResourcePackUrl() {
        return null;
    }

    public String getResourcePackHash() {
        return null;
    }

    public boolean isLoreModeEnabled() {
        return false;
    }

    public int getLoreChancePercent() {
        return 0;
    }

    public int getLoreMinDistance() {
        return 0;
    }

    public int getLoreMaxDistance() {
        return 0;
    }

    public String getOpenRouterApiKey() {
        return null;
    }

    public String getMessage(String arg0, String arg1) {
        return null;
    }

    public List getMessageList(String arg0) {
        return null;
    }

    public List getRandomNames() {
        return null;
    }

    public String pickRandomName() {
        return null;
    }

    public String getSkinValue() {
        return null;
    }

    public String getSkinSignature() {
        return null;
    }

    public boolean useRandomSkin() {
        return false;
    }

    public List getRandomSkinNames() {
        return null;
    }

    public boolean isSoundEnabled(String arg0) {
        return false;
    }

    public String getSoundName(String arg0) {
        return null;
    }

    public float getSoundVolume(String arg0) {
        return 0.0;
    }

    public float getSoundPitch(String arg0) {
        return 0.0;
    }

    public List getTitlePool(String arg0) {
        return null;
    }

    public List getSubtitlePool(String arg0) {
        return null;
    }

    public boolean isTriggerEnabled(String arg0) {
        return false;
    }

    public int getTriggerThreshold(String arg0) {
        return 0;
    }

    public boolean isLoreEffectEnabled(String arg0) {
        return false;
    }

    public int getLoreEffectCooldownMinutes() {
        return 0;
    }

    public boolean isAmbientEnabled() {
        return false;
    }

    public int getAmbientEventIntervalMin() {
        return 0;
    }

    public int getAmbientEventIntervalMax() {
        return 0;
    }

    public boolean isAmbientEventEnabled(String arg0) {
        return false;
    }

    public int getAmbientEventChance(String arg0) {
        return 0;
    }

    public List getAmbientMessages() {
        return null;
    }

    public List getAmbientSignTexts() {
        return null;
    }

    public boolean isStalkingEnabled() {
        return false;
    }

    public int getStalkingCheckInterval() {
        return 0;
    }

    public boolean isStalkingRequireDark() {
        return false;
    }

    public boolean isStalkingRequireRain() {
        return false;
    }

    public int getStalkingChance() {
        return 0;
    }

    public int getStalkingDistanceMin() {
        return 0;
    }

    public int getStalkingDistanceMax() {
        return 0;
    }

    public int getStalkingDurationMin() {
        return 0;
    }

    public int getStalkingDurationMax() {
        return 0;
    }

    public List getStalkingMessages() {
        return null;
    }

    public boolean isCaveDwellerEnabled() {
        return false;
    }

    public int getCaveCheckInterval() {
        return 0;
    }

    public int getCaveDarknessWarningAt() {
        return 0;
    }

    public int getCaveDarknessAppearAt() {
        return 0;
    }

    public int getCaveDarknessHorrorAt() {
        return 0;
    }

    public int getCaveDarkLightLevel() {
        return 0;
    }

    public boolean isCaveLightFlickerEnabled() {
        return false;
    }

    public int getCaveAppearanceMinDistance() {
        return 0;
    }

    public int getCaveAppearanceMaxDistance() {
        return 0;
    }

    public List getCaveWarningMessages() {
        return null;
    }

    public File getWatcherDir() {
        return null;
    }

    public File getPatrolsDir() {
        return null;
    }

    public File getInvestigationDir() {
        return null;
    }

    public File getLoreDir() {
        return null;
    }

    public File getLogsDir() {
        return null;
    }

    public File getAmbientDir() {
        return null;
    }

    public File getStalkingDir() {
        return null;
    }

    public File getCavesDir() {
        return null;
    }

    public File getBrokenScriptDir() {
        return null;
    }

    public YamlConfiguration getAmbientConfig() {
        return null;
    }

    public YamlConfiguration getStalkingConfig() {
        return null;
    }

    public YamlConfiguration getCavesConfig() {
        return null;
    }

    public YamlConfiguration getBrokenScriptConfig() {
        return null;
    }

    public boolean isBrokenScriptEnabled() {
        return false;
    }

    public int getBrokenScriptEventIntervalMin() {
        return 0;
    }

    public int getBrokenScriptEventIntervalMax() {
        return 0;
    }

    public List getBrokenScriptEnabledEvents() {
        return null;
    }

    public boolean isBrokenScriptKeywordsEnabled() {
        return false;
    }

    public int getBrokenScriptKeywordCooldown() {
        return 0;
    }

    public List getBrokenScriptParanoiaMessages() {
        return null;
    }

    public List loadPatrolConfigs() {
        return null;
    }

    public void reload() {
    }

    private static boolean lambda$loadPatrolConfigs$0(File arg0, String arg1) {
        return false;
    }

    /* String constants found in bytecode:
       'getDataFolder'
       'watcherDir'
       'patrolsDir'
       'investigation'
       'investigationDir'
       'ambientDir'
       'stalkingDir'
       'broken_script'
       'brokenScriptDir'
       'ensureDirs'
       'config.yml'
       'loadConfig'
       'mainConfig'
       'messages.yml'
       'messagesConfig'
       'names.yml'
       'namesConfig'
       'skins.yml'
       'skinsConfig'
       'sounds.yml'
       'soundsConfig'
       'titles.yml'
       'titlesConfig'
       'triggersConfig'
       'loreConfig'
       'ambientConfig'
       'stalkingConfig'
       'cavesConfig'
       'brokenScriptConfig'
       'getLogger'
       'countConfigs'
       'makeConcatWithConstants'
       'getResource'
       'saveResource'
       'getParentFile'
       'createNewFile'
       'loadConfiguration'
       'getBoolean'
       'ai_player_mode'
       'Herobrine'
    */
}