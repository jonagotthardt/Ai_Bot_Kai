package com.jonasmp.ai.watcher;

public class WatcherHorror {

    private final WatcherCore core;
    private final WatcherBot bot;
    private final Random random;
    private UUID horrorTarget;
    private int horrorPhase;
    private long nextHorrorTick;
    private long nextWhisper;
    private int whisperIndex;
    private long lastTeleportTime;
    private long lastPotionTime;
    private static final long TELEPORT_COOLDOWN_MS;
    private static final long POTION_COOLDOWN_MS;
    private final List PHASE1_WHISPERS;
    private final List PHASE2_WHISPERS;
    private final List PHASE3_WHISPERS;

    public WatcherHorror(WatcherCore arg0) {
        // TODO: decompile
    }

    public void beginHorror(Player arg0) {
    }

    public void endHorror() {
    }

    public void tick() {
    }

    private void tickPhase1(Player arg0) {
    }

    private void tickPhase2(Player arg0) {
    }

    private void triggerPhase3(Player arg0) {
    }

    private void tickPhase3Active(Player arg0) {
    }

    private void sendWhisper(Player arg0) {
    }

    private void teleportBehind(Player arg0, double arg1) {
    }

    private void moveAway(Player arg0, double arg1) {
    }

    public boolean isActive() {
        return false;
    }

    public UUID getHorrorTarget() {
        return null;
    }

    public int getHorrorPhase() {
        return 0;
    }

    /* String constants found in bytecode:
       'horrorTarget'
       'horrorPhase'
       'nextHorrorTick'
       'nextWhisper'
       'whisperIndex'
       'lastTeleportTime'
       'lastPotionTime'
       '§8§oDu hörst mich nicht... aber ich höre dich.'
       '§8§oDie Dunkelheit hier ist nicht normal.'
       '§8§oDein Herz schlägt schneller. Ich merke es.'
       '§8§oJemand schaut dich an. Schau nicht hin.'
       '§8§oDie Welt hier merkt sich jeden Schritt.'
       '§8§oDu bist nicht allein. Du warst es nie.'
       '§8§oDie Blöcke hinter dir... sie haben sich verändert.'
       '§8§oKennst du das Gefühl, beobachtet zu werden?'
       'PHASE1_WHISPERS'
       '§4§lIch bin hinter dir.'
       '§4§lDreh dich nicht um.'
       '§4§oDein eigener Schatten... ist nicht deiner.'
       '§4§oIch kopiere jeden deiner Schritte.'
       '§4§lSchau in die Dunkelheit. Ich schaue zurück.'
       '§4§oWer hat das Schild platziert? Ich weiß es.'
       '§4§lDu hörst Schritte. §oAber du bist allein.'
       '§4§oDie Kisten waren gestern noch voll. Wo ist alles hin?'
       'PHASE2_WHISPERS'
       '§0§kAAA§4§l DU BIST NICHT ALLEIN IN DIESEM RAUM §0§kAAA'
       '§4§lDas Bild friert ein. Der Sound bleibt.'
       '§4§lDein Client zuckt. Das ist kein Bug.'
       '§4§lDein Name steht in den Logs. Für immer.'
       '§0§kXXX§c§l ICH SEHE DICH §0§kXXX'
       '§4§lDie Frequenz in deinen Ohren... ist berechnet.'
       '§4§lDu kannst nicht ausloggen. Nicht wirklich.'
       '§4§lWenn du denkst, es ist vorbei... schau hinter dich.'
       'PHASE3_WHISPERS'
       'getUniqueId'
       'currentTimeMillis'
       'teleportBehind'
       'getEyeLocation'
       '§0§k...§8§o Etwas hat dich bemerkt. §0§k...'
       'sendMessage'
    */
}