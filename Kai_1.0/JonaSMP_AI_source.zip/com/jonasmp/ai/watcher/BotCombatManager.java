package com.jonasmp.ai.watcher;

import com.jonasmp.ai.bootstrap.CoreBootstrap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.List;

/**
 * BotCombatManager — vollständiger Rewrite für Beta 3.0
 *
 * Fixes:
 *  1. Eating während Kampf: Bot isst nur wenn er NICHT angreift, wechselt danach
 *     sofort zurück zur besten Waffe. Kein "essen in der hand und weiterkämpfen".
 *  2. Mace Smash: Funktioniert jetzt korrekt mit Windcharge-Throw → Aufsteigen → Fallen lassen.
 *  3. Wind Charge: Wird korrekt geworfen (useItem auf richtigem Slot).
 *  4. Weapon Lock: Während eat-Cooldown (3 Ticks nach Essen) keine Waffenwahl,
 *     danach selectBestWeapon() erzwungen.
 *  5. PvP verbessert: Kiting-Logik, Crit-Fenster, Shield-Break nach Axe-Hit.
 */
public class BotCombatManager {

    // ── Konstanten ────────────────────────────────────────────────────────────
    private static final int   SWORD_COOLDOWN_TICKS   = 12;   // 0.6s @ 20 TPS
    private static final int   AXE_COOLDOWN_TICKS     = 28;   // 1.4s
    private static final int   FIST_COOLDOWN_TICKS    = 15;
    private static final int   MACE_SMASH_COOLDOWN    = 40;   // 2s zwischen Smashes
    private static final int   WIND_CHARGE_COOLDOWN   = 25;   // 1.25s zwischen WC-Würfen
    private static final int   SHIELD_BLOCK_DURATION  = 12;
    private static final int   SHIELD_BLOCK_COOLDOWN  = 30;
    private static final int   EAT_WEAPON_LOCK_TICKS  = 4;    // Ticks nach Essen → Waffe sperren
    private static final float MACE_MIN_FALL_DISTANCE = 1.5f;
    private static final double MACE_SMASH_RANGE       = 4.0;
    private static final double SWORD_OPTIMAL_MIN      = 1.0;
    private static final double SWORD_OPTIMAL_MAX      = 2.5;
    private static final double AXE_OPTIMAL_MIN        = 1.0;
    private static final double AXE_OPTIMAL_MAX        = 3.5;

    // ── State ─────────────────────────────────────────────────────────────────
    private final AIPlayerBot aiBot;

    private Entity  currentTarget         = null;
    private int     combatTicks           = 0;
    private int     attackCooldown        = 0;
    private int     strafeDir             = 1;
    private int     jumpCooldown          = 0;
    private int     wTapCooldown          = 0;
    private int     blockHitCooldown      = 0;
    private int     noTargetTicks         = 0;
    private int     comboCount            = 0;

    // Mace / Wind Charge state
    private boolean isMaceSmashing        = false;
    private int     maceSmashTicks        = 0;
    private double  smashStartY           = 0;
    private int     windChargeCooldown    = 0;

    // Shield state
    private boolean isShieldBlocking      = false;
    private int     shieldBlockTicks      = 0;
    private int     shieldBlockCooldown   = 0;

    // Eating state — KEY FIX
    private boolean isEating              = false;
    private int     eatWeaponLockTicks    = 0;   // nach dem Essen kurz Waffe sperren
    private int     priorWeaponSlot       = -1;  // Slot vor dem Essen

    // Config
    private boolean enabled               = true;
    private double  strafeChance          = 0.7;
    private boolean jumpCritEnabled       = true;
    private boolean wTapEnabled           = true;
    private boolean blockHitEnabled       = true;

    // ── Ctor ──────────────────────────────────────────────────────────────────
    public BotCombatManager(AIPlayerBot aiBot) {
        this.aiBot = aiBot;
        reloadConfig();
    }

    public void reloadConfig() {
        var cfg = CoreBootstrap.PLUGIN.getConfig();
        enabled          = cfg.getBoolean("bot.combat.enabled",    true);
        strafeChance     = cfg.getDouble ("bot.combat.strafe_chance", 0.7);
        jumpCritEnabled  = cfg.getBoolean("bot.combat.jump_crit",  true);
        wTapEnabled      = cfg.getBoolean("bot.combat.w_tap",      true);
        blockHitEnabled  = cfg.getBoolean("bot.combat.block_hit",  true);
        debugLog("CONFIG_RELOADED enabled=" + enabled);
    }

    // ── Haupt-Tick ────────────────────────────────────────────────────────────

    /**
     * Wird jeden Tick aus AIPlayerBot aufgerufen (höchste Priorität).
     * @return true  wenn Kai im Kampf ist (restliche Tick-Logik überspringen)
     *         false wenn kein Kampf
     */
    public boolean tick(Player bot, NMSBot nmsBot) {
        if (!enabled) return false;

        // ── Cooldowns herunterzählen ──────────────────────────────────────────
        if (attackCooldown    > 0) attackCooldown--;
        if (jumpCooldown      > 0) jumpCooldown--;
        if (wTapCooldown      > 0) wTapCooldown--;
        if (blockHitCooldown  > 0) blockHitCooldown--;
        if (windChargeCooldown> 0) windChargeCooldown--;
        if (shieldBlockCooldown > 0) shieldBlockCooldown--;
        if (eatWeaponLockTicks  > 0) eatWeaponLockTicks--;

        // ── Eating abschließen ────────────────────────────────────────────────
        if (isEating) {
            tickEating(bot, nmsBot);
            // Während Essen: Kampf-State pausieren, aber trotzdem als "im Kampf" zurückgeben
            // damit der Bot nicht wegl äuft oder anderes tut
            return currentTarget != null;
        }

        // ── Ziel suchen / validieren ──────────────────────────────────────────
        if (!isTargetValid(bot)) {
            noTargetTicks++;
            if (noTargetTicks > 20) {
                // 1 Sekunde kein Ziel → Combat beenden
                clearTarget();
                return false;
            }
            // Kein Ziel aber wir waren kurz im Kampf → Weapon Lock aufheben
            if (eatWeaponLockTicks <= 0 && priorWeaponSlot >= 0) {
                selectBestWeapon(bot, nmsBot);
                priorWeaponSlot = -1;
            }
            return currentTarget != null;
        }
        noTargetTicks = 0;

        combatTicks++;
        Entity target = currentTarget;
        Location botLoc    = bot.getLocation();
        Location targetLoc = target.getLocation();
        double dist = botLoc.distance(targetLoc);

        // ── Rotation auf Ziel ─────────────────────────────────────────────────
        float yaw   = computeYaw(bot, target);
        float pitch = computePitch(bot, target);
        nmsBot.setRotation(yaw, pitch);

        // ── Waffe wählen (wenn kein EatLock) ─────────────────────────────────
        if (eatWeaponLockTicks <= 0) {
            selectBestWeapon(bot, nmsBot);
        }

        Material weapon = bot.getInventory().getItemInMainHand().getType();

        // ── Mace Smash Logik ──────────────────────────────────────────────────
        if (isMaceInHand(bot) && !isMaceSmashing) {
            if (dist < MACE_SMASH_RANGE && windChargeCooldown <= 0) {
                startMaceSmash(bot, nmsBot, target, dist);
                return true;
            }
        }
        if (isMaceSmashing) {
            tickMaceSmash(bot, nmsBot, target, dist);
            return true;
        }

        // ── Shield Block (zwischen Angriffen) ────────────────────────────────
        if (blockHitEnabled && hasShieldInOffhand(bot) && !isShieldBlocking
                && attackCooldown > SWORD_COOLDOWN_TICKS / 2
                && shieldBlockCooldown <= 0 && dist < 3.5) {
            startShieldBlock(nmsBot, target, dist);
        }
        if (isShieldBlocking) {
            shieldBlockTicks--;
            if (shieldBlockTicks <= 0 || attackCooldown <= 2) {
                stopShieldBlock(nmsBot);
            }
        }

        // ── Bewegung / Strafing ───────────────────────────────────────────────
        tickMovement(bot, nmsBot, target, dist, weapon);

        // ── Angriff ───────────────────────────────────────────────────────────
        if (isAttackReady(bot, target) && attackCooldown <= 0) {
            // Shield aufheben falls aktiv
            if (isShieldBlocking) stopShieldBlock(nmsBot);

            // Jump Crit
            if (jumpCritEnabled && jumpCooldown <= 0 && bot.isOnGround() && dist < 3.0) {
                nmsBot.jump();
                jumpCooldown = 25;
            }

            // W-Tap
            if (wTapEnabled && wTapCooldown <= 0) {
                nmsBot.setSprinting(true);
                // Sprint wird 3 Ticks gehalten, dann abgebrochen (durch Angriff)
                wTapCooldown = 15;
            }

            nmsBot.swingMainHand();
            nmsBot.attack(target);
            bot.setSprinting(false); // Sprint-Reset für Knockback

            // Cooldown setzen
            attackCooldown = getWeaponCooldownTicks(weapon);
            comboCount++;

            debugLog("ATTACK target=" + target.getType().name()
                    + " dist=" + String.format("%.1f", dist)
                    + " weapon=" + weapon.name()
                    + " combo=" + comboCount);
        }

        // ── Auf Ziel zubewegen wenn zu weit ──────────────────────────────────
        if (dist > 2.5) {
            nmsBot.navigateTo(targetLoc);
        }

        return true;
    }

    // ── Eating während Kampf ──────────────────────────────────────────────────

    /**
     * Startet den Ess-Vorgang korrekt:
     * 1. Merkt den aktuellen Waffen-Slot
     * 2. Wechselt auf Food-Slot
     * 3. Setzt isEating = true
     */
    public boolean tryEmergencyEat(Player bot, NMSBot nmsBot) {
        PlayerInventory inv = bot.getInventory();
        int foodSlot = findBestFoodSlot(bot);
        if (foodSlot < 0) return false;

        // Waffen-Slot merken BEVOR gewechselt wird
        priorWeaponSlot = findBestWeaponSlot(bot);

        // Auf Food-Slot wechseln
        nmsBot.selectHotbarSlot(foodSlot);
        isEating = true;
        debugLog("EAT_START slot=" + foodSlot + " priorWeapon=" + priorWeaponSlot);
        return true;
    }

    private void tickEating(Player bot, NMSBot nmsBot) {
        // Essen passiert durch den normalen autoEat-Mechanismus in AIPlayerBot.
        // Wir warten bis getFoodLevel >= 18 ODER health >= maxHealth * 0.8
        double health    = bot.getHealth();
        double maxHealth = bot.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
        int    food      = bot.getFoodLevel();

        boolean doneEating = (food >= 18) || (health >= maxHealth * 0.85);

        if (doneEating) {
            isEating = false;
            eatWeaponLockTicks = EAT_WEAPON_LOCK_TICKS;

            // Sofort zurück zur besten Waffe
            if (priorWeaponSlot >= 0) {
                int bestSlot = findBestWeaponSlot(bot);
                nmsBot.selectHotbarSlot(bestSlot >= 0 ? bestSlot : priorWeaponSlot);
                priorWeaponSlot = -1;
                debugLog("EAT_DONE switched back to weapon slot=" + bestSlot);
            }
        }
    }

    // ── Mace Smash ────────────────────────────────────────────────────────────

    private void startMaceSmash(Player bot, NMSBot nmsBot, Entity target, double dist) {
        int windChargeSlot = findWindChargeSlot(bot);
        if (windChargeSlot < 0) {
            // Kein Wind Charge → normaler Sprung-Angriff
            if (bot.isOnGround()) {
                nmsBot.jump();
                jumpCooldown = 30;
            }
            return;
        }

        isMaceSmashing  = true;
        maceSmashTicks  = 0;
        smashStartY     = bot.getLocation().getY();

        // 1. Wind Charge werfen um hochzukommen
        int currentSlot = bot.getInventory().getHeldItemSlot();
        nmsBot.selectHotbarSlot(windChargeSlot);

        // Pitch auf -90 (nach oben schauen) für Windcharge nach oben
        float yaw = computeYaw(bot, target);
        nmsBot.setRotation(yaw, -75.0f);
        nmsBot.useItem();

        windChargeCooldown = WIND_CHARGE_COOLDOWN;

        // Zurück auf Mace
        int maceSlot = findMaceSlot(bot);
        if (maceSlot >= 0) {
            nmsBot.selectHotbarSlot(maceSlot);
        }

        debugLog("MACE_SMASH_START target=" + target.getType().name()
                + " windChargeSlot=" + windChargeSlot
                + " maceSlot=" + maceSlot
                + " dist=" + String.format("%.1f", dist));
    }

    private void tickMaceSmash(Player bot, NMSBot nmsBot, Entity target, double dist) {
        maceSmashTicks++;
        double currentY = bot.getLocation().getY();
        double fallen   = smashStartY - currentY; // positiv wenn gefallen
        boolean onGround = bot.isOnGround();

        debugLog("MACE_SMASH_TRACK ticks=" + maceSmashTicks
                + " fallen=" + String.format("%.2f", fallen)
                + " onGround=" + onGround);

        // Timeout
        if (maceSmashTicks > 60) {
            debugLog("MACE_SMASH_TIMEOUT after " + maceSmashTicks + " ticks");
            isMaceSmashing = false;
            attackCooldown = MACE_SMASH_COOLDOWN;
            return;
        }

        // Peak erreicht → jetzt fallen und auf Ziel schauen
        if (maceSmashTicks > 8) {
            float yaw   = computeYaw(bot, target);
            float pitch = computePitch(bot, target);
            nmsBot.setRotation(yaw, pitch);

            // Auf Ziel zubewegen
            if (dist > 1.0) {
                nmsBot.navigateTo(target.getLocation());
            }
        }

        // Genug gefallen UND nah genug → Smash!
        if (fallen >= MACE_MIN_FALL_DISTANCE && dist < MACE_SMASH_RANGE) {
            nmsBot.swingMainHand();
            nmsBot.attack(target);
            isMaceSmashing = false;
            attackCooldown = MACE_SMASH_COOLDOWN;
            comboCount++;
            debugLog("MACE_SMASH_HIT target=" + target.getType().name()
                    + " dist=" + String.format("%.1f", dist)
                    + " fallen=" + String.format("%.2f", fallen)
                    + " ticks=" + maceSmashTicks);
        }

        // Noch aufsteigend oder zu weit → warten
    }

    // ── Bewegung / Strafing ───────────────────────────────────────────────────

    private void tickMovement(Player bot, NMSBot nmsBot, Entity target, double dist, Material weapon) {
        // Optimale Kampfdistanz je nach Waffe
        double optMin = isSword(weapon) ? SWORD_OPTIMAL_MIN : AXE_OPTIMAL_MIN;
        double optMax = isSword(weapon) ? SWORD_OPTIMAL_MAX : AXE_OPTIMAL_MAX;

        // Kiting: zu nah → rückwärts
        if (dist < optMin) {
            nmsBot.walkRelative(0, -0.4);
            return;
        }

        // Zu weit → vorwärts
        if (dist > optMax) {
            nmsBot.setSprinting(true);
            nmsBot.walkRelative(0, 0.5);
            return;
        }

        // Optimale Distanz → Strafing
        if (Math.random() < strafeChance) {
            // Alle 15 Ticks Strafing-Richtung wechseln
            if (combatTicks % 15 == 0) strafeDir = -strafeDir;
            nmsBot.walkRelative(strafeDir * 0.35, 0);
        }
    }

    // ── Ziel-Verwaltung ───────────────────────────────────────────────────────

    public void setTarget(Entity target, Player bot, NMSBot nmsBot) {
        if (target == null) {
            clearTarget();
            return;
        }
        boolean isNew = !target.equals(currentTarget);
        currentTarget = target;
        noTargetTicks = 0;

        if (isNew) {
            combatTicks = 0;
            comboCount  = 0;
            debugLog("COMBAT_START target=" + target.getType().name()
                    + " dist=" + String.format("%.1f", bot.getLocation().distance(target.getLocation())));
            aiBot.onCombatStart(bot);
            selectBestWeapon(bot, nmsBot);
        }
    }

    public Entity findPriorityTarget(Player bot) {
        // 1. Spieler der Kai zuletzt angegriffen hat
        Player lastAttacker = aiBot.getLastDamagedByPlayer();
        if (lastAttacker != null && lastAttacker.isOnline()
                && lastAttacker.getWorld().equals(bot.getWorld())) {
            double d = bot.getLocation().distance(lastAttacker.getLocation());
            if (d < 16) return lastAttacker;
        }

        // 2. Nächstes Monster (aus Cache)
        Entity monster = aiBot.cachedNearestMonster;
        if (monster != null && monster.isValid()) {
            return monster;
        }

        // 3. Fallback: Scan
        return findNearestMonster(bot, 8.0);
    }

    private Entity findNearestMonster(Player bot, double radius) {
        Entity nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (Entity e : bot.getNearbyEntities(radius, radius / 2, radius)) {
            if (e instanceof Monster) {
                double d = bot.getLocation().distance(e.getLocation());
                if (d < nearestDist) {
                    nearestDist = d;
                    nearest = e;
                }
            }
        }
        return nearest;
    }

    public void clearTarget() {
        if (currentTarget != null) {
            debugLog("COMBAT_STATE_RESET");
        }
        currentTarget      = null;
        combatTicks        = 0;
        isMaceSmashing     = false;
        isShieldBlocking   = false;
        isEating           = false;
        eatWeaponLockTicks = 0;
        priorWeaponSlot    = -1;
    }

    public boolean isInCombat() {
        return currentTarget != null && currentTarget.isValid();
    }

    public Entity getCurrentTarget() { return currentTarget; }

    // ── Waffen-Selektion ──────────────────────────────────────────────────────

    /**
     * Wählt die beste Waffe im Hotbar.
     * WICHTIG: Wird NICHT aufgerufen während isEating oder eatWeaponLockTicks > 0.
     */
    public void selectBestWeapon(Player bot, NMSBot nmsBot) {
        if (isEating || eatWeaponLockTicks > 0) return;
        if (isMaceSmashing) return;

        int bestSlot  = findBestWeaponSlot(bot);
        if (bestSlot < 0) return;

        int current = bot.getInventory().getHeldItemSlot();
        if (current != bestSlot) {
            nmsBot.selectHotbarSlot(bestSlot);
            debugLog("WEAPON_SWITCH from=" + current + " to=" + bestSlot
                    + " weapon=" + bot.getInventory().getItem(bestSlot).getType().name());
        }
    }

    private int findBestWeaponSlot(Player bot) {
        PlayerInventory inv = bot.getInventory();
        int bestSlot  = -1;
        int bestScore = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack item = inv.getItem(i);
            if (item == null) continue;
            int score = weaponScore(item.getType());
            if (score > bestScore) {
                bestScore = score;
                bestSlot  = i;
            }
        }
        return bestSlot;
    }

    private int weaponScore(Material m) {
        if (m == null) return 0;
        String n = m.name();
        // Mace
        if (n.equals("MACE"))               return 120;
        // Schwerter
        if (n.equals("NETHERITE_SWORD"))    return 110;
        if (n.equals("DIAMOND_SWORD"))      return 100;
        if (n.equals("IRON_SWORD"))         return  90;
        if (n.equals("STONE_SWORD"))        return  80;
        if (n.equals("GOLDEN_SWORD"))       return  70;
        if (n.equals("WOODEN_SWORD"))       return  60;
        // Äxte (höherer Schaden, aber langsamer)
        if (n.equals("NETHERITE_AXE"))      return 108;
        if (n.equals("DIAMOND_AXE"))        return  98;
        if (n.equals("IRON_AXE"))           return  88;
        if (n.equals("STONE_AXE"))          return  78;
        if (n.equals("GOLDEN_AXE"))         return  68;
        if (n.equals("WOODEN_AXE"))         return  58;
        // Trident
        if (n.equals("TRIDENT"))            return  95;
        return 0;
    }

    // ── Food-Selektion ────────────────────────────────────────────────────────

    /**
     * Bestes Essen im Hotbar finden.
     * Golde Äpfel zuerst bei Notfall (health < 6), sonst normale Nahrung.
     */
    private int findBestFoodSlot(Player bot) {
        PlayerInventory inv = bot.getInventory();
        double health = bot.getHealth();
        boolean emergency = health < 6;
        int bestSlot  = -1;
        int bestValue = -1;

        for (int i = 0; i < 9; i++) {
            ItemStack item = inv.getItem(i);
            if (item == null) continue;
            int val = foodValue(item.getType(), emergency);
            if (val > bestValue) {
                bestValue = val;
                bestSlot  = i;
            }
        }
        return bestSlot;
    }

    private int foodValue(Material m, boolean emergency) {
        if (m == null) return 0;
        switch (m) {
            case ENCHANTED_GOLDEN_APPLE: return emergency ? 1000 : 900;
            case GOLDEN_APPLE:           return emergency ? 900  : 800;
            case GOLDEN_CARROT:          return 70;
            case COOKED_BEEF:            return 60;
            case COOKED_PORKCHOP:        return 60;
            case COOKED_MUTTON:          return 55;
            case COOKED_CHICKEN:         return 50;
            case COOKED_SALMON:          return 50;
            case COOKED_COD:             return 45;
            case COOKED_RABBIT:          return 45;
            case COOKED_POTATO:          return 40;
            case BREAD:                  return 35;
            case APPLE:                  return 20;
            case CARROT:                 return 15;
            case POTATO:                 return 5;
            default:                     return 0;
        }
    }

    // ── Hilfs-Methoden ────────────────────────────────────────────────────────

    private boolean isTargetValid(Player bot) {
        return currentTarget != null
            && currentTarget.isValid()
            && !currentTarget.isDead()
            && currentTarget.getLocation().getWorld().equals(bot.getWorld());
    }

    private boolean isAttackReady(Player bot, Entity target) {
        // Minecraft 1.20+ Attack Strength: muss ~100% sein
        float strength = bot.getAttackCooldown();
        return strength >= 0.9f;
    }

    private int getWeaponCooldownTicks(Material weapon) {
        if (weapon == null) return FIST_COOLDOWN_TICKS;
        String n = weapon.name();
        if (n.contains("SWORD"))   return SWORD_COOLDOWN_TICKS;
        if (n.contains("AXE"))     return AXE_COOLDOWN_TICKS;
        if (n.equals("MACE"))      return MACE_SMASH_COOLDOWN;
        if (n.equals("TRIDENT"))   return 18;
        return FIST_COOLDOWN_TICKS;
    }

    private boolean isSword(Material m) {
        return m != null && m.name().contains("SWORD");
    }

    private boolean isMaceInHand(Player bot) {
        Material m = bot.getInventory().getItemInMainHand().getType();
        return m != null && m.name().equals("MACE");
    }

    private int findMaceSlot(Player bot) {
        PlayerInventory inv = bot.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack item = inv.getItem(i);
            if (item != null && item.getType().name().equals("MACE")) return i;
        }
        return -1;
    }

    private int findWindChargeSlot(Player bot) {
        PlayerInventory inv = bot.getInventory();
        // Zuerst Hotbar
        for (int i = 0; i < 9; i++) {
            ItemStack item = inv.getItem(i);
            if (item != null && item.getType().name().equals("WIND_CHARGE")) return i;
        }
        // Dann Hauptinventar
        for (int i = 9; i < 36; i++) {
            ItemStack item = inv.getItem(i);
            if (item != null && item.getType().name().equals("WIND_CHARGE")) {
                // In Hotbar verschieben
                inv.setItem(8, item);
                inv.setItem(i, null);
                return 8;
            }
        }
        return -1;
    }

    private boolean hasShieldInOffhand(Player bot) {
        ItemStack offhand = bot.getInventory().getItemInOffHand();
        return offhand != null && offhand.getType().name().equals("SHIELD");
    }

    private void startShieldBlock(NMSBot nmsBot, Entity target, double dist) {
        isShieldBlocking = true;
        shieldBlockTicks = SHIELD_BLOCK_DURATION;
        nmsBot.useOffhandItem();
        debugLog("SHIELD_BLOCK_START target=" + target.getType().name() + " dist=" + String.format("%.1f", dist));
    }

    private void stopShieldBlock(NMSBot nmsBot) {
        if (isShieldBlocking) {
            isShieldBlocking    = false;
            shieldBlockCooldown = SHIELD_BLOCK_COOLDOWN;
            debugLog("SHIELD_BLOCK_END");
        }
    }

    private float computeYaw(Player bot, Entity target) {
        Location bl = bot.getLocation();
        Location tl = target.getLocation();
        double dx = tl.getX() - bl.getX();
        double dz = tl.getZ() - bl.getZ();
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    private float computePitch(Player bot, Entity target) {
        Location bl = bot.getLocation().add(0, 1.6, 0); // Augenhöhe
        Location tl = target.getLocation().add(0, 1.0, 0);
        double dx   = tl.getX() - bl.getX();
        double dy   = tl.getY() - bl.getY();
        double dz   = tl.getZ() - bl.getZ();
        double dist = Math.sqrt(dx*dx + dz*dz);
        return (float) -Math.toDegrees(Math.atan2(dy, dist));
    }

    private void debugLog(String msg) {
        CoreBootstrap.PLUGIN.getLogger().info("[BotCombatManager] " + msg);
    }
}
