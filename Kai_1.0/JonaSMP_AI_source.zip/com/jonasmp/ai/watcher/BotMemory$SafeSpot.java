package com.jonasmp.ai.watcher;

public class BotMemory$SafeSpot {

    public double x;
    public double y;
    public double z;
    public String world;
    public long time;

    public BotMemory$SafeSpot() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'BotMemory.java'
       'InnerClasses'
    */
}