package com.jonasmp.ai.watcher;

public class WatcherEvents implements Listener {

    private final WatcherCore core;
    private AntiCheatBridge antiCheatBridge;
    private final Map oreTrackers;
    private static final Material[] TRACKED_ORES;
    private final Map lastLocations;
    private final Map lastMoveTimes;

    public WatcherEvents(WatcherCore arg0) {
        // TODO: decompile
    }

    public void register() {
    }

    public void onPlayerJoin(PlayerJoinEvent arg0) {
    }

    public void onBlockBreak(BlockBreakEvent arg0) {
    }

    private void trackOreMine(Player arg0, String arg1) {
    }

    public void onBlockPlace(BlockPlaceEvent arg0) {
    }

    public void onInventoryOpen(InventoryOpenEvent arg0) {
    }

    public void onCombat(EntityDamageByEntityEvent arg0) {
    }

    public void onMove(PlayerMoveEvent arg0) {
    }

    public void onInteract(PlayerInteractEvent arg0) {
    }

    private static WatcherEvents$OreTracker lambda$trackOreMine$0(UUID arg0) {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'antiCheatBridge'
       'oreTrackers'
       'lastLocations'
       'lastMoveTimes'
       'getPluginManager'
       'registerEvents'
       'getPlayer'
       'isSpawned'
       'getBotPlayer'
       'showPlayer'
       'getObserver'
       'onBlockBreak'
       'TRACKED_ORES'
       'trackOreMine'
       'getUniqueId'
       'computeIfAbsent'
       'getRecentCount'
       'onXrayIndicator'
       'onBlockPlace'
       'getInventory'
       'getHolder'
       'getSimpleName'
       'Container'
       'onContainerOpen'
       'getDamager'
       'getEntity'
       'getFinalDamage'
       'onPlayerCombat'
       'ensurePlayerData'
       'combat_victim'
       'makeConcatWithConstants'
       'addObservationRecord'
       'getAIPlayerBot'
       'getNMSBot'
       'recordPlayerDamage'
       'getGameMode'
       'SPECTATOR'
       'currentTimeMillis'
       'getOrDefault'
       'longValue'
    */
}