package com.jonasmp.ai.watcher;

public class BotPathfinder {

    private static final double COST_STRAIGHT;
    private static final double COST_DIAGONAL;
    private static final double COST_JUMP_UP;
    private static final double COST_FALL;
    private static final double COST_WATER;
    private static final double COST_LAVA;
    private static final int MAX_PATH_LENGTH;
    private static final int MAX_FALL_DISTANCE;
    private static final int MAX_SEARCH_NODES;
    private static final int[][] DIRECTIONS;

    public BotPathfinder() {
        // TODO: decompile
    }

    public static List findPath(Location arg0, Location arg1) {
        return null;
    }

    public static List findPath(Location arg0, Location arg1, int arg2) {
        return null;
    }

    private static double heuristic(BotPathfinder$Node arg0, BotPathfinder$Node arg1) {
        return 0.0;
    }

    private static double getMoveCost(World arg0, BotPathfinder$Node arg1, BotPathfinder$Node arg2) {
        return 0.0;
    }

    private static boolean isPassable(Material arg0) {
        return false;
    }

    private static List reconstructPath(Map arg0, BotPathfinder$Node arg1, World arg2) {
        return null;
    }

    private static double lambda$findPath$0(BotPathfinder$Node arg0) {
        return 0.0;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'emptyList'
       'getBlockX'
       'getBlockY'
       'getBlockZ'
       'singletonList'
       'applyAsDouble'
       'comparingDouble'
       'heuristic'
       'reconstructPath'
       'DIRECTIONS'
       'getMoveCost'
       'getOrDefault'
       'doubleValue'
       'getBlockAt'
       'isPassable'
       'COST_STRAIGHT'
       'ConstantValue'
       'COST_DIAGONAL'
       'COST_JUMP_UP'
       'COST_FALL'
       'COST_WATER'
       'COST_LAVA'
       'MAX_PATH_LENGTH'
       'MAX_FALL_DISTANCE'
       'MAX_SEARCH_NODES'
       'LineNumberTable'
       'LocalVariableTable'
       'Signature'
       'tentativeG'
       'maxLength'
       'startNode'
       'closedSet'
       'nodesChecked'
       'LocalVariableTypeTable'
       'StackMapTable'
       'feetBlock'
       'groundBlock'
       'currentHead'
       'isDiagonal'
       'destBlock'
    */
}