package com.jonasmp.ai.watcher;

public class AntiCheatBridge implements Listener {

    private final WatcherCore core;
    private boolean vulcanAvailable;
    private Class vulcanFlagEventClass;
    private Class vulbanBanEventClass;
    private Method getPlayerMethod;
    private Method getCheckMethod;
    private Method getVlMethod;
    private Method getInfoMethod;

    public AntiCheatBridge(WatcherCore arg0) {
        // TODO: decompile
    }

    private void detectVulcan() {
    }

    public void register() {
    }

    public void unregister() {
    }

    private void handleVulcanFlag(Event arg0) {
    }

    private void handleFlagResponse(Player arg0, String arg1, double arg2) {
    }

    private Method findMethod(Class arg0, String arg1, Class[] arg2) {
        return null;
    }

    private Method findMethodAny(Class arg0, String[] arg1) {
        return null;
    }

    public boolean isVulcanAvailable() {
        return false;
    }

    public void reportFlag(Player arg0, String arg1, double arg2, String arg3) {
    }

    private void lambda$register$0(Listener arg0, Event arg1) {
    }

    /* String constants found in bytecode:
       'vulcanAvailable'
       'vulcanFlagEventClass'
       'vulbanBanEventClass'
       'getPlayerMethod'
       'getCheckMethod'
       'getVlMethod'
       'getInfoMethod'
       'detectVulcan'
       'getPluginManager'
       'getPlugin'
       'getLogger'
       'me.frep.vulcan.api.event.VulcanFlagEvent'
       'me.frep.vulcan.api.VulcanFlagEvent'
       'me.frep.vulcan.spigot.api.event.VulcanFlagEvent'
       'getPlayer'
       'findMethod'
       'getCheckName'
       'getViolationLevel'
       'getViolations'
       'getDetails'
       'getDescription'
       'findMethodAny'
       'makeConcatWithConstants'
       'getMessage'
       'registerEvent'
       'unregisterAll'
       'doubleValue'
       'getObserver'
       'onAntiCheatFlag'
       'handleFlagResponse'
       'getUniqueId'
       'ensurePlayerData'
       'getTotalStrikes'
       'OBSERVING'
       'getAntiCheatStrikes'
       'beginInvestigation'
       'observePlayer'
       'getMethods'
       'getReturnType'
       'isAssignableFrom'
    */
}