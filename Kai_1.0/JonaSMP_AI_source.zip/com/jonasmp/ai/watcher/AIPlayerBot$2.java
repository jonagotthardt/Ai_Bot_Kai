package com.jonasmp.ai.watcher;

public class AIPlayerBot$2 extends BukkitRunnable {

     int tick;
     int actionTicksRemaining;
     String currentAction;
     int wanderCooldown;
     int airTicks;
    final AIPlayerBot this$0;

     AIPlayerBot$2(AIPlayerBot arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'actionTicksRemaining'
       'currentAction'
       'wanderCooldown'
       'isSpawned'
       'getPlayer'
       'respawnPlayer'
       'eatCooldown'
       'combatManager'
       'isInCombat'
       'getFoodLevel'
       'getHealth'
       'getAttackCooldown'
       'autoEatSmart'
       'selectBestWeapon'
       'getInventory'
       'getItemInMainHand'
       'isWeaponMaterial'
       'isNavigating'
       'tickPhysics'
       'getLocation'
       'saveLastLocation'
       'saveBotInventory'
       'burrowManager'
       'chatManager'
       'refreshEntityCache'
       'autoEquipper'
       'autoEnchanter'
       'tryWaterMLG'
       'isHealingPhase'
       'needsHealing'
       'walkRelative'
       'setSprinting'
       'autoEquipBestGear'
       'scanAndEnchantAll'
       'isOnGround'
       'cancelNavigation'
       'setSneaking'
       'isInWater'
       'setFallDistance'
    */
}