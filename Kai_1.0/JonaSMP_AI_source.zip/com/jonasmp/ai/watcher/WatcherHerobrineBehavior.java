package com.jonasmp.ai.watcher;

public class WatcherHerobrineBehavior {

    private final WatcherCore core;
    private final WatcherBot bot;
    private final Random random;
    private static final List HEROBRINE_SIGNS;
    private BukkitRunnable behaviorTask;
    private long nextBehaviorTick;

    public WatcherHerobrineBehavior(WatcherCore arg0) {
        // TODO: decompile
    }

    public void start() {
    }

    public void stop() {
    }

    public void tryForceBehavior(Player arg0) {
    }

    private void tryRandomBehavior() {
    }

    private void placeRedstoneTorchNear(Player arg0) {
    }

    private void placeSmallGlowstonePyramid(Player arg0) {
    }

    private void placeHerobrineSign(Player arg0) {
    }

    private void placeRedstoneEyes(Player arg0) {
    }

    private void placeNetherrackCross(Player arg0) {
    }

    private void playHerobrineSound(Player arg0) {
    }

    private Location findSurfaceNear(Player arg0, int arg1, int arg2) {
        return null;
    }

    private void placeRedstoneTrail(Player arg0) {
    }

    private void placeSmallTunnel(Player arg0) {
    }

    private void placeWrittenBook(Player arg0) {
    }

    private void placeBoneCross(Player arg0) {
    }

    private void watchFromWall(Player arg0) {
    }

    private static void lambda$watchFromWall$0(Block arg0, Block arg1) {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'behaviorTask'
       'nextBehaviorTick'
       'runTaskTimer'
       'tryRandomBehavior'
       'getAssignedPlayer'
       'getPlayer'
       'placeRedstoneTorchNear'
       'placeSmallGlowstonePyramid'
       'placeHerobrineSign'
       'placeRedstoneEyes'
       'placeNetherrackCross'
       'placeRedstoneTrail'
       'placeSmallTunnel'
       'placeWrittenBook'
       'placeBoneCross'
       'playHerobrineSound'
       'watchFromWall'
       'findSurfaceNear'
       'getBlockAt'
       'getRelative'
       'REDSTONE_TORCH'
       'getLogger'
       'makeConcatWithConstants'
       'getBlockX'
       'getBlockY'
       'getBlockZ'
       'GLOWSTONE'
       'HEROBRINE_SIGNS'
       'getLocation'
       'nextDouble'
       'DEEPSLATE'
       'REDSTONE_BLOCK'
       'NETHERRACK'
       'getVisuals'
       'playRandomHerobrineSound'
       'REDSTONE_WIRE'
       'WRITTEN_BOOK'
       'getItemMeta'
       'Herobrine'
       'setAuthor'
    */
}