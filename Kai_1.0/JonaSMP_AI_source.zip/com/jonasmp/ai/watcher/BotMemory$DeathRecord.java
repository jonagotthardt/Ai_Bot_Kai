package com.jonasmp.ai.watcher;

public class BotMemory$DeathRecord {

    public String cause;
    public double x;
    public double y;
    public double z;
    public String world;
    public long time;
    public int hour;

    public BotMemory$DeathRecord() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'BotMemory.java'
       'InnerClasses'
       'DeathRecord'
    */
}