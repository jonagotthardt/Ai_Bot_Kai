package com.jonasmp.ai.watcher;

public class BotMemory$PlayerInstruction {

    public String playerName;
    public String instruction;
    public double x;
    public double y;
    public double z;
    public String world;
    public long time;

    public BotMemory$PlayerInstruction() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'playerName'
       'instruction'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'BotMemory.java'
       'InnerClasses'
       'PlayerInstruction'
    */
}