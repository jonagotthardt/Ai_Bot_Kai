package com.jonasmp.ai.watcher;

public class WatcherCore {

    private static WatcherCore INSTANCE;
    private final WatcherConfig config;
    private final AIPlayerBot aiPlayerBot;
    private final Map playerData;
    private boolean running;
    private BukkitRunnable tickTask;
    private final AIBridgeWriter bridgeWriter;
    private TeaseBehavior teaseBehavior;

    private WatcherCore() {
        // TODO: decompile
    }

    public static WatcherCore getInstance() {
        return null;
    }

    public void init() {
    }

    public void shutdown() {
    }

    public void reload() {
    }

    private void startTickLoop() {
    }

    public WatcherPlayerData getPlayerData(UUID arg0) {
        return null;
    }

    public WatcherPlayerData ensurePlayerData(UUID arg0, String arg1) {
        return null;
    }

    public Map getAllPlayerData() {
        return null;
    }

    public WatcherConfig getConfig() {
        return null;
    }

    public AIPlayerBot getAIPlayerBot() {
        return null;
    }

    public boolean isRunning() {
        return false;
    }

    public WatcherBot getBot() {
        return null;
    }

    public WatcherMovement getMovement() {
        return null;
    }

    public WatcherObserver getObserver() {
        return null;
    }

    public WatcherInvestigation getInvestigation() {
        return null;
    }

    public WatcherFreeze getFreeze() {
        return null;
    }

    public WatcherLore getLore() {
        return null;
    }

    public WatcherHorror getHorror() {
        return null;
    }

    public WatcherVisuals getVisuals() {
        return null;
    }

    public WatcherHerobrineBehavior getHerobrine() {
        return null;
    }

    public WatcherAmbientHorror getAmbientHorror() {
        return null;
    }

    public WatcherStalking getStalking() {
        return null;
    }

    public WatcherCaveDweller getCaveDweller() {
        return null;
    }

    public WatcherBrokenScript getBrokenScript() {
        return null;
    }

    public WatcherToggles getToggles() {
        return null;
    }

    public void beginHorror(Player arg0) {
    }

    public void endHorror() {
    }

    public void beginUltimateHerobrineMode(Player arg0) {
    }

    public void endUltimateHerobrineMode() {
    }

    public void triggerLore(Player arg0) {
    }

    public void observePlayer(UUID arg0) {
    }

    public void beginInvestigation(UUID arg0) {
    }

    public void showVisible(UUID arg0) {
    }

    public void freezePlayer(UUID arg0) {
    }

    public void unfreezePlayer(UUID arg0) {
    }

    public void goIdle() {
    }

    public WatcherState getState() {
        return null;
    }

    public void setState(WatcherState arg0) {
    }

    public UUID getAssignedPlayer() {
        return null;
    }

    public AntiCheatBridge getAntiCheatBridge() {
        return null;
    }

    public AIBridgeWriter getBridgeWriter() {
        return null;
    }

    private static WatcherPlayerData lambda$ensurePlayerData$0(UUID arg0, String arg1, UUID arg2) {
        return null;
    }

    private void lambda$init$0() {
    }

    /* String constants found in bytecode:
       'playerData'
       'aiPlayerBot'
       'getDataFolder'
       'bridgeWriter'
       'isEnabled'
       'getLogger'
       'getConfig'
       'ai.openrouter_api_key'
       'getString'
       'getOpenRouterApiKey'
       'setApiKey'
       'getPluginManager'
       'registerEvents'
       'getScheduler'
       'runTaskLater'
       'teaseBehavior'
       'startTickLoop'
       'reloadConfig'
       'runTaskTimer'
       'computeIfAbsent'
       'isSpawned'
       'loadLastLocation'
       'getWorlds'
       'getSpawnLocation'
       'getHighestBlockYAt'
       'makeConcatWithConstants'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'getInstance'
       'StackMapTable'
       'getPlayerData'
       'ensurePlayerData'
       'getAllPlayerData'
       'getAIPlayerBot'
       'isRunning'
       'getMovement'
       'getObserver'
       'getInvestigation'
       'getFreeze'
    */
}