package com.jonasmp.ai.watcher;

public class FakeChannel extends AbstractChannel {

    private static final ChannelMetadata METADATA;
    private final SocketAddress localAddress;
    private final SocketAddress remoteAddress;
    private final ChannelConfig config;
    private final EventLoop eventLoop;
    private final ChannelPipeline pipeline;

    public FakeChannel(SocketAddress arg0, SocketAddress arg1) {
        // TODO: decompile
    }

    public EventLoop eventLoop() {
        return null;
    }

    public boolean isRegistered() {
        return false;
    }

    public ChannelConfig config() {
        return null;
    }

    public ChannelPipeline pipeline() {
        return null;
    }

    public boolean isCompatible(EventLoop arg0) {
        return false;
    }

    public ChannelMetadata metadata() {
        return null;
    }

    protected void doRegister() {
    }

    protected void doBind(SocketAddress arg0) {
    }

    protected void doDisconnect() {
    }

    protected void doClose() {
    }

    protected void doBeginRead() {
    }

    protected void doWrite(ChannelOutboundBuffer arg0) {
    }

    public boolean isActive() {
        return false;
    }

    public boolean isOpen() {
        return false;
    }

    protected SocketAddress localAddress0() {
        return null;
    }

    protected SocketAddress remoteAddress0() {
        return null;
    }

    protected AbstractChannel$AbstractUnsafe newUnsafe() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'localAddress'
       'remoteAddress'
       'eventLoop'
       'shutdownGracefully'
       'LineNumberTable'
       'LocalVariableTable'
       'isRegistered'
       'isCompatible'
       'doRegister'
       'Exceptions'
       'doDisconnect'
       'doBeginRead'
       'StackMapTable'
       'localAddress0'
       'remoteAddress0'
       'newUnsafe'
       'SourceFile'
       'FakeChannel.java'
       'NestMembers'
       'InnerClasses'
       'FakeChannelPipeline'
       'FakeUnsafe'
       'FakeContext'
       'AbstractUnsafe'
    */
}