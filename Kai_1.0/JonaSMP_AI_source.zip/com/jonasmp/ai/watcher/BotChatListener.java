package com.jonasmp.ai.watcher;

public class BotChatListener implements Listener {

    private static final String[] TRIGGERS;

    public BotChatListener() {
        // TODO: decompile
    }

    public void onChat(AsyncPlayerChatEvent arg0) {
    }

    private static void lambda$onChat$0(AIPlayerBot arg0, String arg1) {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'getMessage'
       'toLowerCase'
       'startsWith'
       'substring'
       'getPlayer'
       'getInstance'
       'getAIPlayerBot'
       'isSpawned'
       'makeConcatWithConstants'
       'sendMessage'
       'handlePlayerChat'
       'getScheduler'
       'getNMSBot'
       'broadcastMessage'
       'LineNumberTable'
       'LocalVariableTable'
       'finalResponse'
       'addressed'
       'commandPart'
       'StackMapTable'
       'RuntimeVisibleAnnotations'
       'lambda$onChat$0'
       'botPlayer'
       'SourceFile'
       'BotChatListener.java'
       'BootstrapMethods'
       '\x01[Kai] \x01Ich bin gerade nicht da...'
       '\x01[Kai] \x01\x01'
       'metafactory'
       'InnerClasses'
    */
}