package com.jonasmp.ai.watcher;

public class FakeChannel$FakeUnsafe extends AbstractChannel$AbstractUnsafe {

    private FakeChannel$FakeUnsafe(FakeChannel arg0) {
        // TODO: decompile
    }

    public void connect(SocketAddress arg0, SocketAddress arg1, ChannelPromise arg2) {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'setSuccess'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'remoteAddress'
       'localAddress'
       'SourceFile'
       'FakeChannel.java'
       'InnerClasses'
       'AbstractUnsafe'
       'FakeUnsafe'
    */
}