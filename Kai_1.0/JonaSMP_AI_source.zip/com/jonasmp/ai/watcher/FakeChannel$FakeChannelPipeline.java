package com.jonasmp.ai.watcher;

public class FakeChannel$FakeChannelPipeline implements ChannelPipeline {

    private final Channel channel;
    private final ChannelHandlerContext head;
    private final ChannelHandlerContext tail;

     FakeChannel$FakeChannelPipeline(Channel arg0) {
        // TODO: decompile
    }

    public Channel channel() {
        return null;
    }

    public ChannelPipeline addFirst(String arg0, ChannelHandler arg1) {
        return null;
    }

    public ChannelPipeline addFirst(ChannelHandler[] arg0) {
        return null;
    }

    public ChannelPipeline addLast(String arg0, ChannelHandler arg1) {
        return null;
    }

    public ChannelPipeline addLast(ChannelHandler[] arg0) {
        return null;
    }

    public ChannelPipeline addFirst(EventExecutorGroup arg0, String arg1, ChannelHandler arg2) {
        return null;
    }

    public ChannelPipeline addFirst(EventExecutorGroup arg0, ChannelHandler[] arg1) {
        return null;
    }

    public ChannelPipeline addLast(EventExecutorGroup arg0, String arg1, ChannelHandler arg2) {
        return null;
    }

    public ChannelPipeline addLast(EventExecutorGroup arg0, ChannelHandler[] arg1) {
        return null;
    }

    public ChannelPipeline remove(ChannelHandler arg0) {
        return null;
    }

    public ChannelHandler remove(String arg0) {
        return null;
    }

    public ChannelHandler remove(Class arg0) {
        return null;
    }

    public ChannelHandler removeFirst() {
        return null;
    }

    public ChannelHandler removeLast() {
        return null;
    }

    public ChannelHandler replace(String arg0, String arg1, ChannelHandler arg2) {
        return null;
    }

    public ChannelPipeline replace(ChannelHandler arg0, String arg1, ChannelHandler arg2) {
        return null;
    }

    public ChannelHandler replace(Class arg0, String arg1, ChannelHandler arg2) {
        return null;
    }

    public ChannelHandler first() {
        return null;
    }

    public ChannelHandler last() {
        return null;
    }

    public ChannelHandlerContext firstContext() {
        return null;
    }

    public ChannelHandlerContext lastContext() {
        return null;
    }

    public ChannelHandler get(String arg0) {
        return null;
    }

    public ChannelHandler get(Class arg0) {
        return null;
    }

    public ChannelHandlerContext context(ChannelHandler arg0) {
        return null;
    }

    public ChannelHandlerContext context(String arg0) {
        return null;
    }

    public ChannelHandlerContext context(Class arg0) {
        return null;
    }

    public List names() {
        return null;
    }

    public Map toMap() {
        return null;
    }

    public Iterator iterator() {
        return null;
    }

    public ChannelPipeline fireChannelRegistered() {
        return null;
    }

    public ChannelPipeline fireChannelUnregistered() {
        return null;
    }

    public ChannelPipeline fireChannelActive() {
        return null;
    }

    public ChannelPipeline fireChannelInactive() {
        return null;
    }

    public ChannelPipeline fireExceptionCaught(Throwable arg0) {
        return null;
    }

    public ChannelPipeline fireUserEventTriggered(Object arg0) {
        return null;
    }

    public ChannelPipeline fireChannelRead(Object arg0) {
        return null;
    }

    public ChannelPipeline fireChannelReadComplete() {
        return null;
    }

    public ChannelPipeline fireChannelWritabilityChanged() {
        return null;
    }

    public ChannelFuture bind(SocketAddress arg0) {
        return null;
    }

    public ChannelFuture connect(SocketAddress arg0) {
        return null;
    }

    public ChannelFuture connect(SocketAddress arg0, SocketAddress arg1) {
        return null;
    }

    public ChannelFuture disconnect() {
        return null;
    }

    public ChannelFuture close() {
        return null;
    }

    public ChannelFuture deregister() {
        return null;
    }

    public ChannelFuture bind(SocketAddress arg0, ChannelPromise arg1) {
        return null;
    }

    public ChannelFuture connect(SocketAddress arg0, ChannelPromise arg1) {
        return null;
    }

    public ChannelFuture connect(SocketAddress arg0, SocketAddress arg1, ChannelPromise arg2) {
        return null;
    }

    public ChannelFuture disconnect(ChannelPromise arg0) {
        return null;
    }

    public ChannelFuture close(ChannelPromise arg0) {
        return null;
    }

    public ChannelFuture deregister(ChannelPromise arg0) {
        return null;
    }

    public ChannelPipeline read() {
        return null;
    }

    public ChannelFuture write(Object arg0) {
        return null;
    }

    public ChannelFuture write(Object arg0, ChannelPromise arg1) {
        return null;
    }

    public ChannelPipeline flush() {
        return null;
    }

    public ChannelFuture writeAndFlush(Object arg0, ChannelPromise arg1) {
        return null;
    }

    public ChannelFuture writeAndFlush(Object arg0) {
        return null;
    }

    public ChannelPromise newPromise() {
        return null;
    }

    public ChannelProgressivePromise newProgressivePromise() {
        return null;
    }

    public ChannelFuture newSucceededFuture() {
        return null;
    }

    public ChannelFuture newFailedFuture(Throwable arg0) {
        return null;
    }

    public ChannelPromise voidPromise() {
        return null;
    }

    public ChannelPipeline addBefore(String arg0, String arg1, ChannelHandler arg2) {
        return null;
    }

    public ChannelPipeline addBefore(EventExecutorGroup arg0, String arg1, String arg2, ChannelHandler arg3) {
        return null;
    }

    public ChannelPipeline addAfter(String arg0, String arg1, ChannelHandler arg2) {
        return null;
    }

    public ChannelPipeline addAfter(EventExecutorGroup arg0, String arg1, String arg2, ChannelHandler arg3) {
        return null;
    }

    public ChannelInboundInvoker fireChannelWritabilityChanged() {
        return null;
    }

    public ChannelInboundInvoker fireChannelReadComplete() {
        return null;
    }

    public ChannelInboundInvoker fireChannelRead(Object arg0) {
        return null;
    }

    public ChannelInboundInvoker fireUserEventTriggered(Object arg0) {
        return null;
    }

    public ChannelInboundInvoker fireExceptionCaught(Throwable arg0) {
        return null;
    }

    public ChannelInboundInvoker fireChannelInactive() {
        return null;
    }

    public ChannelInboundInvoker fireChannelActive() {
        return null;
    }

    public ChannelInboundInvoker fireChannelUnregistered() {
        return null;
    }

    public ChannelInboundInvoker fireChannelRegistered() {
        return null;
    }

    public ChannelOutboundInvoker flush() {
        return null;
    }

    public ChannelOutboundInvoker read() {
        return null;
    }

    /* String constants found in bytecode:
       'emptyList'
       'emptyIterator'
       'newFailedFuture'
       'setFailure'
       'newSucceededFuture'
       'setSuccess'
       'eventLoop'
       'fireChannelWritabilityChanged'
       'fireChannelReadComplete'
       'fireChannelRead'
       'fireUserEventTriggered'
       'fireExceptionCaught'
       'fireChannelInactive'
       'fireChannelActive'
       'fireChannelUnregistered'
       'fireChannelRegistered'
       'LineNumberTable'
       'LocalVariableTable'
       'handlerType'
       'LocalVariableTypeTable'
       'Signature'
       'removeFirst'
       'removeLast'
       'newHandler'
       'oldHandler'
       'oldHandlerType'
       'firstContext'
       'lastContext'
       'StackMapTable'
       'localAddress'
       'remoteAddress'
       'disconnect'
       'deregister'
       'writeAndFlush'
       'newPromise'
       'newProgressivePromise'
       'voidPromise'
       'addBefore'
       'MethodParameters'
       'SourceFile'
    */
}