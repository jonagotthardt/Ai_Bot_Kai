package com.jonasmp.ai.watcher;

public class WatcherStalking {

    private final WatcherCore core;
    private final WatcherBot bot;
    private final WatcherVisuals visuals;
    private final Random random;
    private BukkitRunnable stalkTask;
    private UUID currentStalkTarget;
    private long stalkStartTime;
    private long nextStalkTick;
    private boolean isStalking;
    private final List STALK_MESSAGES;

    public WatcherStalking(WatcherCore arg0) {
        // TODO: decompile
    }

    public void start() {
    }

    public void stop() {
    }

    private void tryBeginStalk() {
    }

    public void beginStalk(Player arg0) {
    }

    private void tickStalk() {
    }

    private void creepCloser(Player arg0) {
    }

    private void endStalk() {
    }

    private Location calculateStalkPosition(Player arg0) {
        return null;
    }

    private boolean isPlayerLookingAt(Player arg0, Location arg1) {
        return false;
    }

    private Player pickStalkTarget() {
        return null;
    }

    public boolean isStalking() {
        return false;
    }

    public UUID getCurrentStalkTarget() {
        return null;
    }

    /* String constants found in bytecode:
       'stalkTask'
       'currentStalkTarget'
       'stalkStartTime'
       'nextStalkTick'
       'isStalking'
       '§8§oEtwas bewegt sich im Nebel...'
       '§8§oDu spürst, dass jemand dich beobachtet.'
       '§8§oDie Silhouette am Horizont... war die deine?'
       '§8§oEin Schatten bewegt sich zwischen den Bäumen.'
       '§8§oWenn du dich umdrehst... ist er schon weg.'
       '§8§oDer Nebel birgt mehr als nur Feuchtigkeit.'
       '§8§oSchritte. Nicht deine.'
       '§8§oWeiße Augen im Dunkeln. Du hattest sie gesehen.'
       'STALK_MESSAGES'
       'getVisuals'
       'getLogger'
       'pickStalkTarget'
       'getLocation'
       'getLightLevel'
       'getConfig'
       'isStalkingRequireDark'
       'isStalkingRequireRain'
       'getStalkingChance'
       'beginStalk'
       'getUniqueId'
       'currentTimeMillis'
       'calculateStalkPosition'
       'getEyeLocation'
       'setupHerobrineEyes'
       'getStalkingConfig'
       'message_chance'
       'getStalkingMessages'
       'sendMessage'
       'makeConcatWithConstants'
       'getPlayer'
       'isPlayerLookingAt'
       'getStalkingDurationMin'
       'getStalkingDurationMax'
       'nextDouble'
       'creepCloser'
    */
}