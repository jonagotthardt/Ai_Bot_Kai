package com.jonasmp.ai.watcher;

public class BotRespawnListener implements Listener {

    private final AIPlayerBot aiPlayerBot;
    private ItemStack[] savedInventory;
    private ItemStack[] savedArmor;
    private ItemStack savedOffHand;
    private int savedLevel;
    private float savedExp;

    public BotRespawnListener(AIPlayerBot arg0) {
        // TODO: decompile
    }

    public void onPlayerDeath(PlayerDeathEvent arg0) {
    }

    private static int countItems(ItemStack[] arg0) {
        return 0;
    }

    private void lambda$onPlayerDeath$0() {
    }

    private void lambda$onPlayerDeath$1() {
    }

    /* String constants found in bytecode:
       'savedInventory'
       'savedArmor'
       'savedOffHand'
       'savedLevel'
       'aiPlayerBot'
       'getEntity'
       'isSpawned'
       'getNMSBot'
       'getPlayer'
       'getUniqueId'
       'getLogger'
       'makeConcatWithConstants'
       'getInventory'
       'getArmorContents'
       'getItemInOffHand'
       'countItems'
       'saveBotInventory'
       'getCombatManager'
       'setKeepInventory'
       'setKeepLevel'
       'setDroppedExp'
       'getBotMemory'
       'getDeathMessage'
       'getLocation'
       'currentTimeMillis'
       'recordDeath'
       'toLowerCase'
       'learnedRunFromCreepers'
       'Got blown up by creeper'
       'Run away from creepers immediately'
       'recordLesson'
       'learnedDontFightLowHealth'
       'low_health_combat'
       'Died fighting while low health'
       'Flee when health is below 50%'
       'high place'
       'fall_damage'
       'Died from fall damage'
       'Avoid jumping off cliffs'
       'Died underwater'
    */
}