package com.jonasmp.ai.watcher;

public class WatcherHerobrineBehavior$1 extends BukkitRunnable {

     int tick;
    final WatcherHerobrineBehavior this$0;

     WatcherHerobrineBehavior$1(WatcherHerobrineBehavior arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'isRunning'
       'behaviorTask'
       'getBotPlayer'
       'nextBehaviorTick'
       'tryRandomBehavior'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'WatcherHerobrineBehavior.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}