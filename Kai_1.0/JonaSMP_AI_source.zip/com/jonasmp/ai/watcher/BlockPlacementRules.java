package com.jonasmp.ai.watcher;

public class BlockPlacementRules {

    private static final int MAX_BUILD_HEIGHT_ABOVE;
    private static final int MAX_BUILD_DISTANCE;
    private static final int MAX_BRIDGE_GAP;

    private BlockPlacementRules() {
        // TODO: decompile
    }

    public static boolean canPlaceHere(Location arg0, Location arg1, Material arg2) {
        return false;
    }

    private static boolean isValidSupport(Material arg0) {
        return false;
    }

    public static boolean isBridgeValid(Location arg0, Location arg1) {
        return false;
    }

    public static double maxBuildHeight(Location arg0) {
        return 0.0;
    }

    public static double maxBuildDistance() {
        return 0.0;
    }

    /* String constants found in bytecode:
       'getRelative'
       'isValidSupport'
       'GRASS_BLOCK'
       'COBBLESTONE'
       'NETHERRACK'
       'END_STONE'
       'MAX_BUILD_HEIGHT_ABOVE'
       'ConstantValue'
       'MAX_BUILD_DISTANCE'
       'MAX_BRIDGE_GAP'
       'LineNumberTable'
       'LocalVariableTable'
       'canPlaceHere'
       'StackMapTable'
       'isBridgeValid'
       'maxBuildHeight'
       'maxBuildDistance'
       'SourceFile'
       'BlockPlacementRules.java'
    */
}