package com.jonasmp.ai.watcher;

public class WorldProtection {

    private static final double SPAWN_PROTECT_RADIUS;
    private static final Set CONTAINERS;
    private static final Set DECORATIVE;
    private static final Set NATURAL_BLOCKS;

    private WorldProtection() {
        // TODO: decompile
    }

    public static boolean isProtected(Location arg0) {
        return false;
    }

    public static boolean isContainer(Material arg0) {
        return false;
    }

    public static boolean isDecorative(Material arg0) {
        return false;
    }

    public static boolean isAllowedToBreak(Block arg0) {
        return false;
    }

    public static boolean isAllowedToPlace(Material arg0) {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'getSpawnLocation'
       'CONTAINERS'
       'DECORATIVE'
       'isContainer'
       'isDecorative'
       'NATURAL_BLOCKS'
       'TRAPPED_CHEST'
       'SHULKER_BOX'
       'WHITE_SHULKER_BOX'
       'ORANGE_SHULKER_BOX'
       'MAGENTA_SHULKER_BOX'
       'LIGHT_BLUE_SHULKER_BOX'
       'YELLOW_SHULKER_BOX'
       'LIME_SHULKER_BOX'
       'PINK_SHULKER_BOX'
       'GRAY_SHULKER_BOX'
       'LIGHT_GRAY_SHULKER_BOX'
       'CYAN_SHULKER_BOX'
       'PURPLE_SHULKER_BOX'
       'BLUE_SHULKER_BOX'
       'BROWN_SHULKER_BOX'
       'GREEN_SHULKER_BOX'
       'RED_SHULKER_BOX'
       'BLACK_SHULKER_BOX'
       'DISPENSER'
       'BLAST_FURNACE'
       'BREWING_STAND'
       'COMPOSTER'
       'CHISELED_BOOKSHELF'
       'DECORATED_POT'
       'SPRUCE_SIGN'
       'BIRCH_SIGN'
       'JUNGLE_SIGN'
       'ACACIA_SIGN'
       'DARK_OAK_SIGN'
       'MANGROVE_SIGN'
       'CHERRY_SIGN'
       'BAMBOO_SIGN'
       'CRIMSON_SIGN'
       'WARPED_SIGN'
    */
}