package com.jonasmp.ai.watcher;

public class BotGoalPlanner$StepCondition {

    public abstract boolean isMet(Player arg0, BotGoalPlanner arg1) {
        return false;
    }

    /* String constants found in bytecode:
       'SourceFile'
       'BotGoalPlanner.java'
       'InnerClasses'
       'StepCondition'
    */
}