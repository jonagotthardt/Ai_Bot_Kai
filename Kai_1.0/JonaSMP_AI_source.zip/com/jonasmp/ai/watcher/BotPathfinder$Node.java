package com.jonasmp.ai.watcher;

public class BotPathfinder$Node {

    final int x;
    final int y;
    final int z;
     double fScore;

     BotPathfinder$Node(int arg0, int arg1, int arg2) {
        // TODO: decompile
    }

    public boolean equals(Object arg0) {
        return false;
    }

    public int hashCode() {
        return 0;
    }

    public String toString() {
        return null;
    }

    /* String constants found in bytecode:
       'makeConcatWithConstants'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'BotPathfinder.java'
       'BootstrapMethods'
       'InnerClasses'
    */
}