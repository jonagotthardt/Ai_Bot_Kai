package com.jonasmp.ai.watcher;

public class BotMemory$DangerZone {

    public double x;
    public double y;
    public double z;
    public String world;
    public String reason;
    public long time;

    public BotMemory$DangerZone() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'BotMemory.java'
       'InnerClasses'
       'DangerZone'
    */
}