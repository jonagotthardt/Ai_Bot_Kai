package com.jonasmp.ai.watcher;

public class BotGoalPlanner$StepFallback {

    public abstract BotGoalPlanner$Step onBlocked(Player arg0, BotGoalPlanner arg1, String arg2) {
        return null;
    }

    /* String constants found in bytecode:
       'onBlocked'
       'SourceFile'
       'BotGoalPlanner.java'
       'InnerClasses'
       'StepFallback'
    */
}