package com.jonasmp.ai.watcher;

import com.jonasmp.ai.bootstrap.CoreBootstrap;

/**
 * AIGoalBridge — löst den Konflikt zwischen Spieler-Commands und AI-Entscheidungen.
 *
 * Problem vorher:
 *   - Spieler sagt "farm" → playerCommandedUntil = jetzt + 30s
 *   - AI entscheidet nach 200 Ticks "GATHER_WOOD" → überschreibt Goal
 *   - Ergebnis: Bot macht nix / springt zwischen Goals hin und her
 *
 * Lösung:
 *   - Zwei getrennte Goal-Quellen: PLAYER und AI
 *   - PLAYER-Goal hat immer höhere Priorität für playerCommandDuration
 *   - AI-Goal darf nur gesetzt werden, wenn kein aktiver Player-Override existiert
 *   - Nach Ablauf des Player-Overrides übernimmt AI wieder
 *   - Beim Setzen eines Player-Goals wird der AI-Plan nicht gelöscht sondern
 *     nur pausiert → nach Ablauf nimmt AI dort weiter wo sie war
 *
 * Integration:
 *   Wird von AIPlayerBot.handlePlayerChat() und dem AI-Plan-Callback genutzt.
 *   Ersetze alle direkten goalPlanner.setGoal()/setPlayerOverride() Aufrufe
 *   durch Aufrufe an AIGoalBridge.
 */
public class AIGoalBridge {

    public enum GoalSource { PLAYER, AI, EMERGENCY }

    private static final long PLAYER_COMMAND_DURATION_MS = 30_000L; // 30 Sekunden

    private final BotGoalPlanner goalPlanner;

    // Aktuell aktive Quelle
    private GoalSource activeSource = GoalSource.AI;

    // Spieler-Override
    private BotGoalPlanner.GoalType playerGoal         = null;
    private long                     playerOverrideUntil = 0L;

    // AI-Goal (wird gemerkt, auch während Player-Override)
    private BotGoalPlanner.GoalType aiGoal             = null;

    // Emergency-Goal (überschreibt beides)
    private BotGoalPlanner.GoalType emergencyGoal      = null;
    private long                    emergencyUntil      = 0L;

    public AIGoalBridge(BotGoalPlanner goalPlanner) {
        this.goalPlanner = goalPlanner;
    }

    // ── Spieler setzt Goal ────────────────────────────────────────────────────

    /**
     * Aufgerufen wenn ein Spieler einen Chat-Befehl gibt.
     * Überschreibt die AI für PLAYER_COMMAND_DURATION_MS.
     */
    public void setPlayerGoal(BotGoalPlanner.GoalType goal) {
        this.playerGoal          = goal;
        this.playerOverrideUntil = System.currentTimeMillis() + PLAYER_COMMAND_DURATION_MS;
        this.activeSource        = GoalSource.PLAYER;

        // GoalPlanner direkt setzen
        goalPlanner.setGoal(goal);
        goalPlanner.setPlayerOverride(PLAYER_COMMAND_DURATION_MS);

        CoreBootstrap.PLUGIN.getLogger().info(
            "[AIGoalBridge] PLAYER goal=" + goal.name()
            + " override_until=" + PLAYER_COMMAND_DURATION_MS / 1000 + "s");
    }

    // ── AI setzt Goal ─────────────────────────────────────────────────────────

    /**
     * Aufgerufen aus dem AI-Plan-Callback (alle 200 Ticks).
     * Wird IGNORIERT wenn ein aktiver Player-Override existiert.
     *
     * @return true wenn das Goal übernommen wurde, false wenn ignoriert
     */
    public boolean setAIGoal(BotGoalPlanner.GoalType goal) {
        this.aiGoal = goal; // immer merken

        // Player-Override aktiv?
        if (isPlayerOverrideActive()) {
            CoreBootstrap.PLUGIN.getLogger().info(
                "[AIGoalBridge] AI goal=" + goal.name()
                + " IGNORED (player override active for "
                + remainingPlayerOverrideSeconds() + "s)");
            return false;
        }

        // Emergency aktiv?
        if (isEmergencyActive()) {
            CoreBootstrap.PLUGIN.getLogger().info(
                "[AIGoalBridge] AI goal=" + goal.name() + " IGNORED (emergency active)");
            return false;
        }

        activeSource = GoalSource.AI;
        goalPlanner.setGoal(goal);
        CoreBootstrap.PLUGIN.getLogger().info("[AIGoalBridge] AI goal=" + goal.name() + " SET");
        return true;
    }

    // ── Emergency Goal (Fleeing, Survival) ───────────────────────────────────

    /**
     * Überschreibt ALLES. Für Combat-Start, Flucht, Notfall-Essen.
     * Läuft nach durationMs automatisch aus.
     */
    public void setEmergencyGoal(BotGoalPlanner.GoalType goal, long durationMs) {
        this.emergencyGoal  = goal;
        this.emergencyUntil = System.currentTimeMillis() + durationMs;
        this.activeSource   = GoalSource.EMERGENCY;
        goalPlanner.setGoal(goal);
        CoreBootstrap.PLUGIN.getLogger().info(
            "[AIGoalBridge] EMERGENCY goal=" + goal.name() + " for " + durationMs / 1000 + "s");
    }

    // ── Tick — wird jeden Tick geprüft ────────────────────────────────────────

    /**
     * Prüft ob Overrides abgelaufen sind und stellt den richtigen Goal wieder her.
     * Muss jeden Tick (oder alle 20 Ticks) in AIPlayerBot aufgerufen werden,
     * BEVOR goalPlanner.tick() aufgerufen wird.
     */
    public void tick() {
        long now = System.currentTimeMillis();

        // Emergency abgelaufen?
        if (activeSource == GoalSource.EMERGENCY && now > emergencyUntil) {
            emergencyGoal = null;
            // Zurück zu Player oder AI
            if (isPlayerOverrideActive()) {
                activeSource = GoalSource.PLAYER;
                if (playerGoal != null) goalPlanner.setGoal(playerGoal);
            } else {
                activeSource = GoalSource.AI;
                if (aiGoal != null) goalPlanner.setGoal(aiGoal);
            }
            CoreBootstrap.PLUGIN.getLogger().info("[AIGoalBridge] EMERGENCY expired, resumed " + activeSource);
        }

        // Player-Override abgelaufen?
        if (activeSource == GoalSource.PLAYER && !isPlayerOverrideActive()) {
            activeSource = GoalSource.AI;
            // Wenn AI ein Goal hatte, wieder aufnehmen
            if (aiGoal != null) {
                goalPlanner.setGoal(aiGoal);
                CoreBootstrap.PLUGIN.getLogger().info(
                    "[AIGoalBridge] Player override expired, AI resumes goal=" + aiGoal.name());
            }
        }
    }

    // ── Status-Abfragen ───────────────────────────────────────────────────────

    public boolean isPlayerOverrideActive() {
        return System.currentTimeMillis() < playerOverrideUntil;
    }

    public boolean isEmergencyActive() {
        return emergencyGoal != null && System.currentTimeMillis() < emergencyUntil;
    }

    public GoalSource getActiveSource() { return activeSource; }

    public BotGoalPlanner.GoalType getAIGoal()     { return aiGoal;     }
    public BotGoalPlanner.GoalType getPlayerGoal()  { return playerGoal; }

    public long remainingPlayerOverrideSeconds() {
        return Math.max(0, (playerOverrideUntil - System.currentTimeMillis()) / 1000);
    }

    // ── Hilfsmethode: GoalType aus AI-Antwort parsen ─────────────────────────

    /**
     * Parst die AI-Antwort (z.B. "PLAN: GATHER_WOOD - ich brauche mehr Holz")
     * und gibt den passenden GoalType zurück.
     * Robust gegen verschiedene Antwort-Formate.
     *
     * @return null wenn kein valider GoalType erkannt
     */
    public static BotGoalPlanner.GoalType parseAIGoalFromPlan(String plan) {
        if (plan == null || plan.isBlank()) return null;

        String upper = plan.toUpperCase().trim();

        // Exakte GoalType-Namen zuerst
        for (BotGoalPlanner.GoalType gt : BotGoalPlanner.GoalType.values()) {
            if (upper.contains(gt.name())) return gt;
        }

        // Keyword-Fallbacks (falls AI Freitext antwortet)
        if (upper.contains("WOOD")   || upper.contains("TREE")   || upper.contains("HOLZ"))   return BotGoalPlanner.GoalType.GATHER_WOOD;
        if (upper.contains("STONE")  || upper.contains("STEIN"))                               return BotGoalPlanner.GoalType.GATHER_STONE;
        if (upper.contains("FOOD")   || upper.contains("HUNGER") || upper.contains("ESSEN"))   return BotGoalPlanner.GoalType.FIND_FOOD;
        if (upper.contains("NIGHT")  || upper.contains("NACHT")  || upper.contains("SLEEP"))   return BotGoalPlanner.GoalType.SURVIVE_NIGHT;
        if (upper.contains("FLEE")   || upper.contains("RUN")    || upper.contains("FLUCHT"))  return BotGoalPlanner.GoalType.FLEE_DANGER;
        if (upper.contains("MINE")   || upper.contains("ORE")    || upper.contains("EISEN"))   return BotGoalPlanner.GoalType.MINE_SURFACE_ORES;
        if (upper.contains("DIAMOND")|| upper.contains("DIAMANT"))                             return BotGoalPlanner.GoalType.DIG_FOR_DIAMONDS;
        if (upper.contains("EXPLORE")|| upper.contains("ERKUND"))                              return BotGoalPlanner.GoalType.EXPLORE;
        if (upper.contains("BUILD")  || upper.contains("BAU")    || upper.contains("HAUS"))    return BotGoalPlanner.GoalType.BUILD_BASIC_HOUSE;
        if (upper.contains("FARM")   || upper.contains("CROP")   || upper.contains("ERNTE"))   return BotGoalPlanner.GoalType.FARM_CROPS;
        if (upper.contains("CRAFT")  || upper.contains("TOOL"))                                return BotGoalPlanner.GoalType.CRAFT_BASIC_TOOLS;

        return null;
    }
}
