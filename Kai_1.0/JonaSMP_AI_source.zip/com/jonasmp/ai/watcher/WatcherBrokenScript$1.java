package com.jonasmp.ai.watcher;

public class WatcherBrokenScript$1 extends BukkitRunnable {

     long nextEventTick;
     long tick;
    final int val$intervalMin;
    final int val$intervalMax;
    final WatcherBrokenScript this$0;

     WatcherBrokenScript$1(WatcherBrokenScript arg0, int arg1, int arg2) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'val$intervalMin'
       'val$intervalMax'
       'requireNonNull'
       'nextEventTick'
       'isRunning'
       'getToggles'
       'isHorrorGlobalEnabled'
       'isBrokenScriptEnabled'
       'tryRandomEvent'
       'checkParanoia'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'StackMapTable'
       'SourceFile'
       'WatcherBrokenScript.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}