package com.jonasmp.ai.watcher;

public class WatcherObserver {

    private final WatcherCore core;
    private long lastRecordTime;

    public WatcherObserver(WatcherCore arg0) {
        // TODO: decompile
    }

    public void record(Player arg0) {
    }

    private void recordMovementSpeed(Player arg0, WatcherPlayerData arg1) {
    }

    public void onBlockBreak(Player arg0, String arg1) {
    }

    public void onBlockPlace(Player arg0, String arg1) {
    }

    public void onContainerOpen(Player arg0, String arg1) {
    }

    public void onPlayerCombat(Player arg0, Player arg1, double arg2) {
    }

    public void onAntiCheatFlag(Player arg0, String arg1, double arg2) {
    }

    public void onSuspiciousChat(Player arg0, String arg1, double arg2) {
    }

    public void onSuspiciousMovement(Player arg0, String arg1) {
    }

    public void onXrayIndicator(Player arg0, String arg1, int arg2) {
    }

    /* String constants found in bytecode:
       'lastRecordTime'
       'currentTimeMillis'
       'getUniqueId'
       'ensurePlayerData'
       'getLocation'
       '%.1f,%.1f,%.1f'
       'makeConcatWithConstants'
       'addObservationRecord'
       'recordMovementSpeed'
       'getObservationHistory'
       'block_break'
       'block_place'
       'container'
       'incrementAntiCheatStrikes'
       'anticheat'
       'getLogger'
       'incrementSuspiciousChatStrikes'
       'incrementSuspiciousMovementStrikes'
       'incrementXrayIndicators'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'onBlockBreak'
       'blockType'
       'onBlockPlace'
       'onContainerOpen'
       'containerType'
       'onPlayerCombat'
       'onAntiCheatFlag'
       'checkType'
       'violation'
       'onSuspiciousChat'
       'riskScore'
       'onSuspiciousMovement'
       'onXrayIndicator'
       'SourceFile'
       'WatcherObserver.java'
       'BootstrapMethods'
       'Hit \x01 for \x01'
       'Flagged: \x01 (vl=\x01'
    */
}