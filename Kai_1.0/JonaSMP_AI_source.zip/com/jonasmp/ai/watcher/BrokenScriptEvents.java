package com.jonasmp.ai.watcher;

public class BrokenScriptEvents {

    private static final Random random;
    public static final List FAKE_MESSAGES;

    public BrokenScriptEvents() {
        // TODO: decompile
    }

    public static void blockCorruption(Player arg0, int arg1, int arg2) {
    }

    public static void itemVanish(Player arg0, int arg1) {
    }

    public static void doorAnomaly(Player arg0, int arg1) {
    }

    public static void chestAnomaly(Player arg0, int arg1) {
    }

    public static void torchExtinguish(Player arg0, int arg1) {
    }

    public static void fakeChat(Player arg0) {
    }

    public static void healthGlitch(Player arg0) {
    }

    public static void cameraGlitch(Player arg0) {
    }

    public static void brokenScriptEnd(Player arg0) {
    }

    public static void tempBanKick(Player arg0, int arg1) {
    }

    public static void soundGlitch(Player arg0) {
    }

    public static void inventoryShuffle(Player arg0) {
    }

    public static void skyGlitch(Player arg0) {
    }

    public static void blockUnderFoot(Player arg0) {
    }

    private static void lambda$blockUnderFoot$0(Block arg0, Material arg1, Material arg2) {
    }

    private static void lambda$tempBanKick$0(Player arg0) {
    }

    private static void lambda$brokenScriptEnd$1(Map arg0, Player arg1) {
    }

    private static void lambda$brokenScriptEnd$0(Block arg0) {
    }

    private static void lambda$torchExtinguish$0(Block arg0, Material arg1) {
    }

    private static void lambda$itemVanish$0(Player arg0, int arg1, ItemStack arg2) {
    }

    private static void lambda$blockCorruption$0(Map arg0) {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'getLocation'
       'COARSE_DIRT'
       'COBBLESTONE'
       'MOSSY_COBBLESTONE'
       'getLogger'
       'makeConcatWithConstants'
       'getScheduler'
       'runTaskLater'
       'getMessage'
       'getInventory'
       'getBlockData'
       'setBlockData'
       'BLOCK_WOODEN_DOOR_OPEN'
       'playSound'
       'BLOCK_CHEST_OPEN'
       '§8§oEtwas hat eine Kiste geöffnet...'
       'sendMessage'
       'WALL_TORCH'
       'REDSTONE_TORCH'
       'REDSTONE_WALL_TORCH'
       'BLOCK_FIRE_EXTINGUISH'
       'FAKE_MESSAGES'
       'ENTITY_PLAYER_HURT'
       'addPotionEffect'
       '§c§o*Schmerz*'
       'BLINDNESS'
       'ENTITY_ELDER_GUARDIAN_CURSE'
       'ENTITY_WITHER_SPAWN'
       '§4§lTHE WORLD IS BROKEN.'
       'kickPlayer'
       'AMBIENT_CAVE'
       'BLOCK_SCULK_SENSOR_CLICKING'
       'ENTITY_GHAST_AMBIENT'
       'ENTITY_ENDERMAN_STARE'
       'ENTITY_WARDEN_HEARTBEAT'
       'BLOCK_BELL_RESONATE'
       'ENTITY_SILVERFISH_AMBIENT'
       'nextFloat'
       'getStorageContents'
       'setStorageContents'
    */
}