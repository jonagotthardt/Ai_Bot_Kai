package com.jonasmp.ai.core;

public class TeacherModeResponder$Severity extends Enum {

    public static final TeacherModeResponder$Severity WARN;
    public static final TeacherModeResponder$Severity BLOCK;
    public static final TeacherModeResponder$Severity SEVERE;
    private static final TeacherModeResponder$Severity[] $VALUES;

    public static TeacherModeResponder$Severity[] values() {
        return null;
    }

    public static TeacherModeResponder$Severity valueOf(String arg0) {
        return null;
    }

    private TeacherModeResponder$Severity(String arg0, int arg1) {
        // TODO: decompile
    }

    private static TeacherModeResponder$Severity[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'TeacherModeResponder.java'
       'InnerClasses'
    */
}