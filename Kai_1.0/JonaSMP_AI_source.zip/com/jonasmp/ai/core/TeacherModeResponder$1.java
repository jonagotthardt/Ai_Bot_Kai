package com.jonasmp.ai.core;

public class TeacherModeResponder$1 {

    static final int[] $SwitchMap$com$jonasmp$ai$decision$DecisionResult$Action;

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       '$SwitchMap$com$jonasmp$ai$decision$DecisionResult$Action'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'TeacherModeResponder.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}