package com.jonasmp.ai.core;

public class LanguageSelectionGUI {

    private static final String TITLE;

    public LanguageSelectionGUI() {
        // TODO: decompile
    }

    public static void open(Player arg0) {
    }

    /* String constants found in bytecode:
       'createInventory'
       'RED_BANNER'
       'getItemMeta'
       '§c§lDeutsch'
       'setDisplayName'
       '§7Klicke hier für Deutsch'
       '§7Dein Prefix wird: §7[§cDE§7]'
       'setItemMeta'
       'BLUE_BANNER'
       '§9§lEnglish'
       '§7Click here for English'
       '§7Your prefix will be: §7[§9EN§7]'
       '§e§lWähle deine Sprache'
       '§7Wähle die Sprache, in der du'
       '§7mit dem Server kommunizierst.'
       '§7[DE] = Deutsch'
       '§7[EN] = English'
       'GRAY_STAINED_GLASS_PANE'
       'openInventory'
       'ConstantValue'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'LanguageSelectionGUI.java'
    */
}