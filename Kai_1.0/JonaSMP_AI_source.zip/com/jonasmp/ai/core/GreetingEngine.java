package com.jonasmp.ai.core;

public class GreetingEngine implements Listener {

    private static final Random RANDOM;
    private static final long GREETING_DELAY_TICKS;
    private static final String[] GREETINGS_DE;
    private static final String[] GREETINGS_EN;

    public GreetingEngine() {
        // TODO: decompile
    }

    public void onPlayerJoin(PlayerJoinEvent arg0) {
    }

    private String pickRandomGreeting(Player arg0) {
        return null;
    }

    private void lambda$onPlayerJoin$1(Player arg0) {
    }

    private static void lambda$onPlayerJoin$0(Player arg0) {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'getPlayer'
       'updatePlayerPrefix'
       'getScheduler'
       'runTaskLater'
       'PLAYER_LANGUAGE_STORE'
       'getUniqueId'
       'getLanguage'
       'GREETINGS_EN'
       'GREETINGS_DE'
       'jonasmpai.admin.greeting'
       'hasPermission'
       'pickRandomGreeting'
       'makeConcatWithConstants'
       'broadcastMessage'
       'FIRST_JOIN_TRACKER'
       'hasAccepted'
       '§c§lWillkommen auf Yona SMP!'
       'sendMessage'
       '§7Bitte lies die Regeln und akzeptiere sie, um beizutreten.'
       '§7Please read and accept the rules to join the server.'
       'Yo Digga, was geht alda? Willkommen aufm Server, Bruder!'
       'Ey %s, endlich bist du da! Hast du schon deine Diamanten gefarmt oder was?'
       'Moin moin, Diggi! Bereit für den Grind oder was?'
       'Alda, guck mal wer da ist! Willkommen, Bruder %s!'
       'Yo %s, willkommen! Vergiss nicht, deine Base zu claimen, sonst klau ich alles lol'
       'Eyyyy %s! Digga, wo warst du so lange? Alles gut?'
       'Willkommen %s! Bist du ready zu grinden oder willst du erstmal chillen?'
       'Alda %s, du bist back! Hast du neue Skins mitgebracht oder was?'
       'Yo %s, Digga! Der Server wurde langweilig ohne dich, endlich!'
       'Was geht ab %s? Bereit für den nächsten Raid?'
       'Digga %s, du siehst aus als hättest du gerade 10 Stunden geschlafen. Willkommen!'
       'Alda %s, willkommen zurück! Hast du Essen mitgebracht? Wir haben Hunger lol'
       'Yo %s! Endlich, dachte schon du hast uns verlassen, Bruder.'
       'Moin %s! Digga, der Creeper neben deiner Base wartet auf dich haha'
       'Willkommen %s! Bist du heute wieder der Mining-King oder was?'
       'Ey %s alda, hast du schon gehört? Es gibt neue Enchantments!'
       'Digga %s, willkommen! Deine Farms laufen übrigens noch, du Schlawiner.'
       'Alda %s, guck mal! Der Server ist heute extra schön für dich.'
       'Yo %s! Bereit für PvP oder farmst du erstmal weiter?'
       'Alda %s, Digga! Lass mal eine Runde Bedwars zocken, was meinst du?'
    */
}