package com.jonasmp.ai.core;

public class PatternExtractor$1 extends BukkitRunnable {

    final PatternExtractor this$0;

     PatternExtractor$1(PatternExtractor arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'extractPatterns'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'SourceFile'
       'PatternExtractor.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}