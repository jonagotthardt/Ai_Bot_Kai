package com.jonasmp.ai.core;

public class PlayerWatcher$PlayerAction {

    public final long timestamp;
    public final UUID playerUuid;
    public final String playerName;
    public final String actionType;
    public final String blockType;
    public final String world;
    public final int chunkX;
    public final int chunkZ;
    public final int blockX;
    public final int blockY;
    public final int blockZ;
    public final String toolUsed;
    public final boolean success;
    public final String outcome;

    public PlayerWatcher$PlayerAction(long arg0, UUID arg1, String arg2, String arg3, String arg4, String arg5, int arg6, int arg7, int arg8, int arg9, int arg10, String arg11, boolean arg12, String arg13) {
        // TODO: decompile
    }

    public String toJson() {
        return null;
    }

    private static String escape(String arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'timestamp'
       'playerUuid'
       'playerName'
       'actionType'
       'blockType'
       'makeConcatWithConstants'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'PlayerWatcher.java'
       'BootstrapMethods'
       ',"blockType":"\x01"'
       ',"toolUsed":"\x01"'
       ',"outcome":"\x01"'
       '{"timestamp":\x01,"playerUuid":"\x01","playerName":"\x01","actionType":"\x01"\x01,"world":"\x01","chunkX":\x01,"chunkZ":\x01,"blockX":\x01,"blockY":\x01,"blockZ":\x01\x01,"success":\x01\x01}'
       'InnerClasses'
       'PlayerAction'
    */
}