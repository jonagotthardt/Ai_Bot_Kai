package com.jonasmp.ai.core;

public class PatternExtractor$Pattern {

    public final String id;
    public final String playerName;
    public final String type;
    public final String description;
    public final List actions;
    public final int frequency;
    public final long lastSeen;

    public PatternExtractor$Pattern(String arg0, String arg1, String arg2, String arg3, List arg4, int arg5, long arg6) {
        // TODO: decompile
    }

    public String toJson() {
        return null;
    }

    private static String escape(String arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'playerName'
       'description'
       'frequency'
       ',"playerName":"'
       ',"type":"'
       ',"description":"'
       ',"actions":['
       ',"frequency":'
       ',"lastSeen":'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'LocalVariableTypeTable'
       'StackMapTable'
       'SourceFile'
       'PatternExtractor.java'
       'InnerClasses'
    */
}