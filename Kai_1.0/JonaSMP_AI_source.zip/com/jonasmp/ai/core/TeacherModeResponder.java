package com.jonasmp.ai.core;

public class TeacherModeResponder {

    private final Random random;
    private static final String[] WARN_MESSAGES_DE;
    private static final String[] BLOCK_MESSAGES_DE;
    private static final String[] SEVERE_MESSAGES_DE;
    private static final String[] WARN_MESSAGES_EN;
    private static final String[] BLOCK_MESSAGES_EN;
    private static final String[] SEVERE_MESSAGES_EN;
    private static final String[] TITLE_WARN;
    private static final String[] TITLE_BLOCK;
    private static final String[] TITLE_SEVERE;
    private static final String[] SUBTITLE_WARN;
    private static final String[] SUBTITLE_BLOCK;
    private static final String[] SUBTITLE_SEVERE;

    public TeacherModeResponder() {
        // TODO: decompile
    }

    public void respond(Player arg0, DecisionResult$Action arg1, String arg2, double arg3) {
    }

    private TeacherModeResponder$Severity determineSeverity(DecisionResult$Action arg0, double arg1) {
        return null;
    }

    private void sendTitle(Player arg0, TeacherModeResponder$Severity arg1) {
    }

    private String pickMessage(TeacherModeResponder$Severity arg0, String arg1) {
        return null;
    }

    private void lambda$respond$0(Player arg0, DecisionResult$Action arg1, double arg2) {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'isTeacherModeEnabled'
       'getScheduler'
       '$SwitchMap$com$jonasmp$ai$decision$DecisionResult$Action'
       'TITLE_SEVERE'
       'SUBTITLE_SEVERE'
       'TITLE_BLOCK'
       'SUBTITLE_BLOCK'
       'TITLE_WARN'
       'SUBTITLE_WARN'
       'sendTitle'
       'SEVERE_MESSAGES_EN'
       'SEVERE_MESSAGES_DE'
       'BLOCK_MESSAGES_EN'
       'BLOCK_MESSAGES_DE'
       'WARN_MESSAGES_EN'
       'WARN_MESSAGES_DE'
       'PLAYER_LANGUAGE_STORE'
       'getUniqueId'
       'getLanguage'
       'determineSeverity'
       'pickMessage'
       'sendMessage'
       '§8§m----------------------------'
       'makeConcatWithConstants'
       'isPublicShamingEnabled'
       'getOnlinePlayers'
       'jonasmpai.moderation.notify'
       'hasPermission'
       'getLocation'
       'BLOCK_NOTE_BLOCK_PLING'
       'playSound'
       'Ey ey! So redet man hier nicht, mein Freund. Pass auf deine Worte auf!'
       'Moment mal! Was war das gerade? Hier wird respektvoll miteinander umgegangen.'
       'Aha, da hat wohl jemand vergessen, wie man sich benehmt. Zurückhaltung, bitte!'
       'So nicht, Kamerad. Wir sind hier im virtuellen Klassenzimmer, nicht im Raucherkeller!'
       'Pst pst! Die Sprache bitte! Denk an die kleinen Pixelohren hier.'
       "Das war's! Das reicht! Du kriegst jetzt ein Denkzettel. Aufpassen!"
       'Na warte! Solche Wörter fliegen hier raus wie ungeliebte Hausaufgaben!'
       'Aufgepasst! Ich bin nicht umsonst hier. Nächste Beleidigung = ernste Konsequenzen!'
       'Das ist ein Ort der Kultur und des feinen Umgangs! ...Okay, vielleicht nicht FEIN, aber respektvoll!'
    */
}