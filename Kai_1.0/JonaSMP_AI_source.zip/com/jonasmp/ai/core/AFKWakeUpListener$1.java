package com.jonasmp.ai.core;

public class AFKWakeUpListener$1 extends BukkitRunnable {

    final AFKWakeUpListener this$0;

     AFKWakeUpListener$1(AFKWakeUpListener arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'currentTimeMillis'
       'getOnlinePlayers'
       'getUniqueId'
       'lastActivity'
       'getOrDefault'
       'longValue'
       'currentlyAFK'
       'PLAYER_LANGUAGE_STORE'
       'getLanguage'
       '§7§o*The AI watches you curiously...*'
       '§7§o*Die KI beobachtet dich neugierig...*'
       'sendMessage'
       'tickleCount'
       'ticklePlayer'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'idleSeconds'
       'StackMapTable'
       'SourceFile'
       'AFKWakeUpListener.java'
       'EnclosingMethod'
       'startTickeTask'
       'InnerClasses'
    */
}