package com.jonasmp.ai.core;

public class GriefingDetector implements Listener {

    private static final int CHECK_RADIUS;
    private static final int SUSPICIOUS_THRESHOLD;
    private static final long COOLDOWN_MS;
    private final Map suspiciousCount;
    private final Map lastWarningTime;
    private final Map lastCheckedArea;
    private final Random random;
    private Object coreProtectAPI;
    private Method blockLookupMethod;
    private Method parseResultMethod;
    private boolean coreProtectAvailable;
    private Object logBlockConsumer;
    private Method lbGetHistoryMethod;
    private Method lbGetPlayerMethod;
    private boolean logBlockAvailable;
    private boolean initAttempted;
    private static GriefingDetector INSTANCE;
    private Method logRemovalMethod;

    public GriefingDetector() {
        // TODO: decompile
    }

    private void initLogging() {
    }

    public void onBlockBreak(BlockBreakEvent arg0) {
    }

    public void onBlockPlace(BlockPlaceEvent arg0) {
    }

    private void checkBlockAction(Player arg0, Block arg1) {
    }

    private boolean hasForeignBlocksNearby(String arg0, Location arg1) {
        return false;
    }

    private String getBlockPlacer(Block arg0) {
        return null;
    }

    private String getBlockPlacerCoreProtect(Block arg0) {
        return null;
    }

    private String getBlockPlacerLogBlock(Block arg0) {
        return null;
    }

    public static void logBlockBreak(Player arg0, Block arg1, Material arg2, BlockData arg3) {
    }

    private String buildGriefingMessage(String arg0, String arg1) {
        return null;
    }

    /* String constants found in bytecode:
       'suspiciousCount'
       'lastWarningTime'
       'lastCheckedArea'
       'coreProtectAvailable'
       'logBlockAvailable'
       'initAttempted'
       'getPluginManager'
       'CoreProtect'
       'getPlugin'
       'getMethod'
       'coreProtectAPI'
       'blockLookup'
       'blockLookupMethod'
       'parseResult'
       'parseResultMethod'
       'logRemoval'
       'logRemovalMethod'
       'getLogger'
       'getMessage'
       'makeConcatWithConstants'
       'getInstance'
       'getConsumer'
       'logBlockConsumer'
       'getHistory'
       'lbGetHistoryMethod'
       'de.diddiz.LogBlock.BlockChange'
       'getPlayerName'
       'lbGetPlayerMethod'
       'getBlockHistory'
       'initLogging'
       'getPlayer'
       'checkBlockAction'
       'jonasmpai.chat.spontaneous'
       'hasPermission'
       'getUniqueId'
       'getLocation'
       'hasForeignBlocksNearby'
       'getOrDefault'
       'currentTimeMillis'
       'longValue'
    */
}