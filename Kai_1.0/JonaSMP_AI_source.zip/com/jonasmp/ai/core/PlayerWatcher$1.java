package com.jonasmp.ai.core;

public class PlayerWatcher$1 extends BukkitRunnable {

    final PlayerWatcher$PlayerAction val$action;
    final PlayerWatcher this$0;

     PlayerWatcher$1(PlayerWatcher arg0, PlayerWatcher$PlayerAction arg1) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'val$action'
       'requireNonNull'
       'writeActionToFile'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'SourceFile'
       'PlayerWatcher.java'
       'EnclosingMethod'
       'bufferAndWrite'
       'InnerClasses'
       'PlayerAction'
    */
}