package com.jonasmp.ai.core;

public class ActivityTracker$ActivityType extends Enum {

    public static final ActivityTracker$ActivityType MINING;
    public static final ActivityTracker$ActivityType FARMING;
    public static final ActivityTracker$ActivityType BUILDING;
    public static final ActivityTracker$ActivityType COMBAT;
    public static final ActivityTracker$ActivityType EXPLORING;
    private static final ActivityTracker$ActivityType[] $VALUES;

    public static ActivityTracker$ActivityType[] values() {
        return null;
    }

    public static ActivityTracker$ActivityType valueOf(String arg0) {
        return null;
    }

    private ActivityTracker$ActivityType(String arg0, int arg1) {
        // TODO: decompile
    }

    private static ActivityTracker$ActivityType[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'EXPLORING'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'ActivityTracker.java'
       'InnerClasses'
       'ActivityType'
    */
}