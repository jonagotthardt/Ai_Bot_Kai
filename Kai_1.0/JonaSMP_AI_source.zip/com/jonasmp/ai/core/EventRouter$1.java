package com.jonasmp.ai.core;

public class EventRouter$1 {

    static final int[] $SwitchMap$com$jonasmp$ai$punishment$PunishmentType;

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       '$SwitchMap$com$jonasmp$ai$punishment$PunishmentType'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'EventRouter.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}