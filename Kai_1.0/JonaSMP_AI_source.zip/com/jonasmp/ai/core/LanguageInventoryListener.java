package com.jonasmp.ai.core;

public class LanguageInventoryListener implements Listener {

    private static final String GUI_TITLE;

    public LanguageInventoryListener() {
        // TODO: decompile
    }

    public void onInventoryClick(InventoryClickEvent arg0) {
    }

    /* String constants found in bytecode:
       'getWhoClicked'
       'getClickedInventory'
       'setCancelled'
       'getCurrentItem'
       'getItemMeta'
       'getDisplayName'
       'PLAYER_LANGUAGE_STORE'
       'getUniqueId'
       'setLanguage'
       '§a[AI] Sprache auf §c§lDEUTSCH§a gesetzt.'
       'sendMessage'
       'updatePlayerPrefix'
       'closeInventory'
       '§a[AI] Language set to §9§lENGLISH§a.'
       'GUI_TITLE'
       'ConstantValue'
       'LineNumberTable'
       'LocalVariableTable'
       'onInventoryClick'
       'whoClicked'
       'StackMapTable'
       'RuntimeVisibleAnnotations'
       'SourceFile'
       'LanguageInventoryListener.java'
    */
}