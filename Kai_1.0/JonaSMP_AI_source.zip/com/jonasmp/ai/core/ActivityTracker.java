package com.jonasmp.ai.core;

public class ActivityTracker implements Listener {

    private static final long CHECK_INTERVAL_TICKS;
    private static final int MONOTONY_THRESHOLD;
    private static final long MESSAGE_COOLDOWN_MS;
    private final Map playerActivities;
    private final Map lastMessageTime;
    private final Random random;

    public ActivityTracker() {
        // TODO: decompile
    }

    public void start() {
    }

    public void onBlockBreak(BlockBreakEvent arg0) {
    }

    public void onBlockPlace(BlockPlaceEvent arg0) {
    }

    public void onCombat(EntityDamageByEntityEvent arg0) {
    }

    private ActivityTracker$ActivityType classifyBreak(Material arg0) {
        return null;
    }

    private void recordActivity(UUID arg0, ActivityTracker$ActivityType arg1) {
    }

    private void checkAllPlayers() {
    }

    private String buildMonotonyMessage(String arg0, ActivityTracker$ActivityType arg1, String arg2) {
        return null;
    }

    private static ActivityTracker$ActivityWindow lambda$recordActivity$0(UUID arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'playerActivities'
       'lastMessageTime'
       'getScheduler'
       'runTaskTimer'
       'getLogger'
       'getPlayer'
       'classifyBreak'
       'getUniqueId'
       'recordActivity'
       'getDamager'
       'toLowerCase'
       'deepslate'
       'netherrack'
       'end_stone'
       'sugarcane'
       'computeIfAbsent'
       'currentTimeMillis'
       'lastUpdate'
       'getOnlinePlayers'
       'jonasmpai.chat.spontaneous'
       'hasPermission'
       'longValue'
       'PLAYER_LANGUAGE_STORE'
       'getLanguage'
       'buildMonotonyMessage'
       '§b[AI] §f'
       '§b[KI] §f'
       'makeConcatWithConstants'
       'sendMessage'
       'CHECK_INTERVAL_TICKS'
       'ConstantValue'
       'MONOTONY_THRESHOLD'
       'MESSAGE_COOLDOWN_MS'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'onBlockBreak'
       'RuntimeVisibleAnnotations'
       'onBlockPlace'
       'StackMapTable'
    */
}