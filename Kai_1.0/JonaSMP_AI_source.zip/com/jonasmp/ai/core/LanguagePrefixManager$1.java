package com.jonasmp.ai.core;

public class LanguagePrefixManager$1 extends BukkitRunnable {

     LanguagePrefixManager$1() {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'syncAllOnline'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'LanguagePrefixManager.java'
       'EnclosingMethod'
       'startGuardTask'
       'InnerClasses'
    */
}