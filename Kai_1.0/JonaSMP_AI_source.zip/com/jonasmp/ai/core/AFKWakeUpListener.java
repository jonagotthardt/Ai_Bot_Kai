package com.jonasmp.ai.core;

public class AFKWakeUpListener implements Listener {

    private final JavaPlugin plugin;
    private final Random random;
    private static final int AFK_THRESHOLD_SECONDS;
    private static final int TICKLE_INTERVAL_SECONDS;
    private static final double MIN_MOVE_DISTANCE_SQ;
    private final Map lastActivity;
    private final Map tickleCount;
    private final Set currentlyAFK;
    private final String[] WHISPERS_DE;
    private final String[] WHISPERS_EN;

    public AFKWakeUpListener(JavaPlugin arg0) {
        // TODO: decompile
    }

    public void onMove(PlayerMoveEvent arg0) {
    }

    public void onInteract(PlayerInteractEvent arg0) {
    }

    public void onQuit(PlayerQuitEvent arg0) {
    }

    private void resetActivity(UUID arg0) {
    }

    private void startTickeTask() {
    }

    private void ticklePlayer(Player arg0, int arg1, String arg2) {
    }

    /* String constants found in bytecode:
       'lastActivity'
       'tickleCount'
       'currentlyAFK'
       '§7§oPsst... noch da?'
       '§7§oHallo? Erde an Spieler?'
       '§7§oBeweg dich mal ein bisschen...'
       '§7§oIch glaube, du bist eingeschlafen...'
       '§7§o*leises Räuspern*'
       '§7§oHey, alles okay bei dir?'
       '§7§oDie Pixel werden kalt wenn du so stillstehst...'
       '§7§oWach auf, Abenteuer wartet!'
       '§7§o*zärtliches Nudge*'
       '§7§oDu lebst noch?'
       'WHISPERS_DE'
       '§7§oPsst... still there?'
       '§7§oHello? Earth to player?'
       '§7§oMove a little bit...'
       '§7§oI think you fell asleep...'
       '§7§o*soft clearing of throat*'
       '§7§oHey, everything okay?'
       '§7§oThe pixels are getting cold if you stand so still...'
       '§7§oWake up, adventure awaits!'
       '§7§o*tender nudge*'
       '§7§oYou still alive?'
       'WHISPERS_EN'
       'startTickeTask'
       'distanceSquared'
       'getPlayer'
       'getUniqueId'
       'resetActivity'
       'currentTimeMillis'
       'PLAYER_LANGUAGE_STORE'
       'getLanguage'
       '§a§o*The AI nods approvingly*'
       '§a§o*Die KI nickt zufrieden*'
       'sendMessage'
       'getLocation'
       'BLOCK_AMETHYST_BLOCK_CHIME'
       'playSound'
       'runTaskTimer'
    */
}