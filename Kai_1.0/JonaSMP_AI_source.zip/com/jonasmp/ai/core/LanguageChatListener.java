package com.jonasmp.ai.core;

public class LanguageChatListener implements Listener {

    private static final String SUFFIX_DE;
    private static final String SUFFIX_EN;

    public LanguageChatListener() {
        // TODO: decompile
    }

    public void onChat(AsyncPlayerChatEvent arg0) {
    }

    /* String constants found in bytecode:
       'PLAYER_LANGUAGE_STORE'
       'getPlayer'
       'getUniqueId'
       'getLanguage'
       ' §7[§9EN§7]§r'
       ' §7[§cDE§7]§r'
       'getFormat'
       'makeConcatWithConstants'
       'setFormat'
       'SUFFIX_DE'
       'ConstantValue'
       'SUFFIX_EN'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'RuntimeVisibleAnnotations'
       'SourceFile'
       'LanguageChatListener.java'
       'BootstrapMethods'
       'InnerClasses'
    */
}