package com.jonasmp.ai.core;

public class ServerMonitor implements Runnable {

    private static final double TPS_WARN_THRESHOLD;
    private static final double TPS_CRITICAL;
    private static final double RAM_WARN_PERCENT;
    private static final double RAM_CRITICAL_PERCENT;
    private static final double SWAP_WARN_PERCENT;
    private static final long WARN_COOLDOWN_MS;
    private static final long CRITICAL_COOLDOWN_MS;
    private long lastTpsWarn;
    private long lastTpsCritical;
    private long lastRamWarn;
    private long lastRamCritical;
    private long lastSwapWarn;
    private boolean tpsCriticalActive;
    private boolean ramCriticalActive;

    public ServerMonitor() {
        // TODO: decompile
    }

    public void start() {
    }

    public void run() {
    }

    private void broadcastToAdmins(String arg0) {
    }

    private static void lambda$broadcastToAdmins$0(String arg0) {
    }

    /* String constants found in bytecode:
       'lastTpsWarn'
       'lastTpsCritical'
       'lastRamWarn'
       'lastRamCritical'
       'lastSwapWarn'
       'tpsCriticalActive'
       'ramCriticalActive'
       'getScheduler'
       'runTaskTimerAsynchronously'
       'getLogger'
       'currentTimeMillis'
       'makeConcatWithConstants'
       'broadcastToAdmins'
       'getRuntime'
       'totalMemory'
       'freeMemory'
       'maxMemory'
       'getInstance'
       'getChunkRadar'
       'getCacheSize'
       'getCacheMemoryMb'
       '§a[AI-INFO] §aRAM-Nutzung ist wieder im grünen Bereich.'
       'isPhysicalMemoryWarningEnabled'
       'getOperatingSystemMXBean'
       'getTotalPhysicalMemorySize'
       'getFreePhysicalMemorySize'
       'getCommittedVirtualMemorySize'
       'getOnlinePlayers'
       'jonasmpai.admin.monitor'
       'hasPermission'
       'sendMessage'
       '§[0-9a-fk-or]'
       'replaceAll'
       'TPS_WARN_THRESHOLD'
       'ConstantValue'
       'TPS_CRITICAL'
       'RAM_WARN_PERCENT'
       'RAM_CRITICAL_PERCENT'
       'SWAP_WARN_PERCENT'
       'WARN_COOLDOWN_MS'
    */
}