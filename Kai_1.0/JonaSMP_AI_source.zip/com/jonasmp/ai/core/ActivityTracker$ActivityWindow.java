package com.jonasmp.ai.core;

public class ActivityTracker$ActivityWindow {

     ActivityTracker$ActivityType current;
     int streak;
     long lastUpdate;

    private ActivityTracker$ActivityWindow() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'EXPLORING'
       'currentTimeMillis'
       'lastUpdate'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'ActivityTracker.java'
       'InnerClasses'
       'ActivityType'
       'ActivityWindow'
    */
}