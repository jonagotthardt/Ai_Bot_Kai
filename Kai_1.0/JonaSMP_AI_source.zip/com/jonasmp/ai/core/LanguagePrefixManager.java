package com.jonasmp.ai.core;

public class LanguagePrefixManager {

    private static final String TEAM_PREFIX;
    private static JavaPlugin plugin;
    private static String BOT_NAME;
    private static final Map SUFFIX_MAP;
    private static final Map CURRENT_LP_SUFFIX;

    public LanguagePrefixManager() {
        // TODO: decompile
    }

    public static void init(JavaPlugin arg0) {
    }

    public static void setBotName(String arg0) {
    }

    public static void syncAllOnline() {
    }

    public static void updatePlayerPrefix(Player arg0) {
    }

    private static void updateLuckPermsSuffix(Player arg0, String arg1) {
    }

    private static void startGuardTask() {
    }

    private static void lambda$updateLuckPermsSuffix$0(String arg0) {
    }

    private static void lambda$init$0() {
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'getScheduler'
       'runTaskLater'
       'getLogger'
       'makeConcatWithConstants'
       'getOnlinePlayers'
       'updatePlayerPrefix'
       'equalsIgnoreCase'
       ' §7[§5BOT§7]§r'
       'PLAYER_LANGUAGE_STORE'
       'getUniqueId'
       'getLanguage'
       'SUFFIX_MAP'
       'getOrDefault'
       'getScoreboardManager'
       'getMainScoreboard'
       'substring'
       'registerNewTeam'
       'getSuffix'
       'setSuffix'
       'updateLuckPermsSuffix'
       'removeEntry'
       'CURRENT_LP_SUFFIX'
       'runTaskTimer'
       'getConsoleSender'
       'dispatchCommand'
       'syncAllOnline'
       'startGuardTask'
       ' §7[§cDE§7]§r'
       ' §7[§9EN§7]§r'
       'TEAM_PREFIX'
       'ConstantValue'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'setBotName'
       'StackMapTable'
       'lambda$updateLuckPermsSuffix$0'
       'lambda$init$0'
       'SourceFile'
       'LanguagePrefixManager.java'
    */
}