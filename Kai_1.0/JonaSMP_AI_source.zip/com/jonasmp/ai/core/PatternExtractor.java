package com.jonasmp.ai.core;

public class PatternExtractor {

    private static final File DATA_DIR;
    private static final File PATTERNS_FILE;

    public PatternExtractor() {
        // TODO: decompile
    }

    public void start() {
    }

    public void extractPatterns() {
    }

    private List readActions(File arg0) {
        return null;
    }

    private String extractJsonField(String arg0, String arg1) {
        return null;
    }

    private List extractSequences(String arg0, List arg1) {
        return null;
    }

    private List extractSpatialPatterns(String arg0, List arg1) {
        return null;
    }

    private List mergeAndSort(List arg0) {
        return null;
    }

    private void writePatterns(List arg0) {
    }

    public List loadPatterns() {
        return null;
    }

    private static int lambda$mergeAndSort$0(PatternExtractor$Pattern arg0, PatternExtractor$Pattern arg1) {
        return 0;
    }

    private static List lambda$extractSpatialPatterns$0(String arg0) {
        return null;
    }

    private static boolean lambda$extractPatterns$0(File arg0, String arg1) {
        return false;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'runTaskTimerAsynchronously'
       'getLogger'
       'isDirectory'
       'listFiles'
       '_actions.jsonl'
       'readActions'
       'extractSequences'
       'extractSpatialPatterns'
       'mergeAndSort'
       'writePatterns'
       'makeConcatWithConstants'
       'getMessage'
       'actionType'
       'extractJsonField'
       'blockType'
       'timestamp'
       'parseLong'
       'addSuppressed'
       'isWhitespace'
       'substring'
       'currentTimeMillis'
       'getOrDefault'
       'longValue'
       'BLOCK_PLACE'
       'computeIfAbsent'
       'singletonList'
       'playerName'
       'description'
       'frequency'
       'PATTERNS_FILE'
       'getParentFile'
       'getDataFolder'
       'LineNumberTable'
       'LocalVariableTable'
       'extractPatterns'
       'allPatterns'
       'LocalVariableTypeTable'
       'StackMapTable'
       'Signature'
       'pairCounts'
    */
}