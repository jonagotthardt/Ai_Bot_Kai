package com.jonasmp.ai.core;

public class PlayerWatcher implements Listener {

    private static final int MAX_ENTRIES_PER_PLAYER;
    private static final File DATA_DIR;
    private final Map actionBuffers;
    private final Map pendingActions;

    public PlayerWatcher() {
        // TODO: decompile
    }

    public void onBlockBreak(BlockBreakEvent arg0) {
    }

    public void onBlockPlace(BlockPlaceEvent arg0) {
    }

    public void onPlayerMove(PlayerMoveEvent arg0) {
    }

    public void onPlayerDeath(PlayerDeathEvent arg0) {
    }

    private void bufferAndWrite(PlayerWatcher$PlayerAction arg0) {
    }

    private void writeActionToFile(PlayerWatcher$PlayerAction arg0) {
    }

    public List getRecentActions(UUID arg0, int arg1) {
        return null;
    }

    private static Deque lambda$bufferAndWrite$0(UUID arg0) {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'actionBuffers'
       'pendingActions'
       'getLogger'
       'getAbsolutePath'
       'makeConcatWithConstants'
       'getPlayer'
       'getLocation'
       'currentTimeMillis'
       'getUniqueId'
       'BLOCK_BREAK'
       'getBlockX'
       'getBlockY'
       'getBlockZ'
       'getInventory'
       'getItemInMainHand'
       'bufferAndWrite'
       'BLOCK_PLACE'
       'actionType'
       'timestamp'
       'getEntity'
       'getDeathMessage'
       'playerUuid'
       'computeIfAbsent'
       'pollFirst'
       'runTaskAsynchronously'
       'playerName'
       'singletonList'
       'getMessage'
       'emptyList'
       'descendingIterator'
       'getDataFolder'
       'MAX_ENTRIES_PER_PLAYER'
       'ConstantValue'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'onBlockBreak'
       'RuntimeVisibleAnnotations'
       'ignoreCancelled'
    */
}