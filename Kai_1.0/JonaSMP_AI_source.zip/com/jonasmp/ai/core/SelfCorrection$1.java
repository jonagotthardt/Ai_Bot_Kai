package com.jonasmp.ai.core;

public class SelfCorrection$1 extends BukkitRunnable {

    final SelfCorrection this$0;

     SelfCorrection$1(SelfCorrection arg0) {
        // TODO: decompile
    }

    public void run() {
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'checkStuckBots'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'SourceFile'
       'SelfCorrection.java'
       'EnclosingMethod'
       'startStuckChecker'
       'InnerClasses'
    */
}