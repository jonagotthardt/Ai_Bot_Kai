package com.jonasmp.ai.shop;

public class DynamicShopBridge$BuySellResult {

    public final boolean success;
    public final String material;
    public final int amount;
    public final double totalPrice;
    public final String message;
    public final boolean usedReflection;

    private DynamicShopBridge$BuySellResult(boolean arg0, String arg1, int arg2, double arg3, String arg4, boolean arg5) {
        // TODO: decompile
    }

    static DynamicShopBridge$BuySellResult success(String arg0, int arg1, double arg2, boolean arg3) {
        return null;
    }

    static DynamicShopBridge$BuySellResult fail(String arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'totalPrice'
       'usedReflection'
       'makeConcatWithConstants'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'DynamicShopBridge.java'
       'BootstrapMethods'
       '§aErfolg: §7\x01x §e\x01 §7für §6\x01§7$'
       '§cFehler: §7\x01'
       'InnerClasses'
       'BuySellResult'
    */
}