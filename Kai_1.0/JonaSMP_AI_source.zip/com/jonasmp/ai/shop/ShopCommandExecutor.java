package com.jonasmp.ai.shop;

public class ShopCommandExecutor implements CommandExecutor, TabCompleter {

    private final DynamicShopBridge bridge;
    private static final int ITEMS_PER_PAGE;

    public ShopCommandExecutor(DynamicShopBridge arg0) {
        // TODO: decompile
    }

    public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
        return false;
    }

    private boolean handleBuy(Player arg0, String[] arg1) {
        return false;
    }

    private boolean handleSell(Player arg0, String[] arg1) {
        return false;
    }

    private boolean handlePrice(Player arg0, String[] arg1) {
        return false;
    }

    private boolean handleList(Player arg0, String[] arg1) {
        return false;
    }

    private boolean handleSearch(Player arg0, String[] arg1) {
        return false;
    }

    public List onTabComplete(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
        return null;
    }

    private static boolean lambda$onTabComplete$0(String arg0, String arg1) {
        return false;
    }

    private void lambda$handleSell$0(Player arg0, String arg1, int arg2) {
    }

    private static void lambda$handleSell$1(Player arg0, DynamicShopBridge$BuySellResult arg1) {
    }

    private void lambda$handleBuy$0(Player arg0, String arg1, int arg2) {
    }

    private static void lambda$handleBuy$1(Player arg0, DynamicShopBridge$BuySellResult arg1) {
    }

    /* String constants found in bytecode:
       'makeConcatWithConstants'
       'sendMessage'
       'toLowerCase'
       'shopprice'
       'shopsearch'
       'handleBuy'
       'handleSell'
       'handlePrice'
       'handleList'
       'handleSearch'
       'toUpperCase'
       'getScheduler'
       'getPluginManager'
       'JonaSMP_AI_v1_Fixed'
       'getPlugin'
       'runTaskAsynchronously'
       'equalsIgnoreCase'
       'getMaterial'
       'getInventory'
       'getContents'
       'getAmount'
       'getBuyPrice'
       'getSellPrice'
       '§2§lJona§a§lSMP §7— §eShop Preise'
       '§8§m                   '
       'getAllItems'
       '§cKeine Items im Shop geladen.'
       'searchItems'
       'emptyList'
       'ITEMS_PER_PAGE'
       'ConstantValue'
       'LineNumberTable'
       'LocalVariableTable'
       'onCommand'
       'StackMapTable'
       'finalItemName'
       'finalAmount'
       'sellPrice'
       'totalPages'
       'LocalVariableTypeTable'
    */
}