package com.jonasmp.ai.personality;

public class PersonalityType extends Enum {

    public static final PersonalityType SAFE;
    public static final PersonalityType LOW_RISK;
    public static final PersonalityType SUSPICIOUS;
    public static final PersonalityType SPAMMER;
    public static final PersonalityType SCAMMER;
    public static final PersonalityType TOXIC;
    public static final PersonalityType HIGH_RISK;
    private static final PersonalityType[] $VALUES;

    public static PersonalityType[] values() {
        return null;
    }

    public static PersonalityType valueOf(String arg0) {
        return null;
    }

    private PersonalityType(String arg0, int arg1) {
        // TODO: decompile
    }

    private static PersonalityType[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'SUSPICIOUS'
       'HIGH_RISK'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'PersonalityType.java'
    */
}