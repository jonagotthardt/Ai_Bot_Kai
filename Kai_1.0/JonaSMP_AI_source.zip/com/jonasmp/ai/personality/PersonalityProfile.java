package com.jonasmp.ai.personality;

public class PersonalityProfile {

    private final UUID uuid;
    private PersonalityType type;
    private int riskScore;

    public PersonalityProfile(UUID arg0) {
        // TODO: decompile
    }

    public void updateRisk(int arg0) {
    }

    private void recalc() {
    }

    public PersonalityType getType() {
        return null;
    }

    public int getRiskScore() {
        return 0;
    }

    public UUID getUuid() {
        return null;
    }

    /* String constants found in bytecode:
       'riskScore'
       'HIGH_RISK'
       'SUSPICIOUS'
       'LineNumberTable'
       'LocalVariableTable'
       'updateRisk'
       'StackMapTable'
       'getRiskScore'
       'SourceFile'
       'PersonalityProfile.java'
    */
}