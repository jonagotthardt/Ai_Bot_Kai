package com.jonasmp.ai.moderation;

public class BanHistoryManager {

    private final File file;
    private final YamlConfiguration config;
    private final Map banCounts;

    public BanHistoryManager(JavaPlugin arg0) {
        // TODO: decompile
    }

    private void load() {
    }

    public void save() {
    }

    public int getBanCount(UUID arg0) {
        return 0;
    }

    public int incrementBanCount(UUID arg0) {
        return 0;
    }

    public String getBanDuration(UUID arg0) {
        return null;
    }

    public String getFormattedDuration(UUID arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'banCounts'
       'getDataFolder'
       'ban_history.yml'
       'getParentFile'
       'createNewFile'
       'printStackTrace'
       'loadConfiguration'
       'fromString'
       'getOrDefault'
       'getBanCount'
       'permanent'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'LocalVariableTypeTable'
       'incrementBanCount'
       'getBanDuration'
       'getFormattedDuration'
       'SourceFile'
       'BanHistoryManager.java'
       'InnerClasses'
    */
}