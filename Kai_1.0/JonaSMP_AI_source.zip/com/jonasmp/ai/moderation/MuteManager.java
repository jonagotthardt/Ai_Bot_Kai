package com.jonasmp.ai.moderation;

public class MuteManager {

    private final Map mutes;

    public MuteManager() {
        // TODO: decompile
    }

    public boolean isMuted(UUID arg0) {
        return false;
    }

    public long getRemainingMs(UUID arg0) {
        return 0;
    }

    public void mute(UUID arg0, long arg1, String arg2, String arg3) {
    }

    public void unmute(UUID arg0) {
    }

    public MuteManager$MuteEntry getEntry(UUID arg0) {
        return null;
    }

    public Collection getAllMuted() {
        return null;
    }

    public String getMuteReason(UUID arg0) {
        return null;
    }

    private static boolean lambda$getAllMuted$0(Map$Entry arg0) {
        return false;
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'getRemainingMs'
       'remaining'
       'durationMs'
       'getAllMuted'
       'getMuteReason'
       'lambda$getAllMuted$0'
       'SourceFile'
       'MuteManager.java'
       'NestMembers'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
       'MuteEntry'
    */
}