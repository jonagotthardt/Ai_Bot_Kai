package com.jonasmp.ai.moderation;

public class MuteManager$MuteEntry {

    public final long until;
    public final String reason;
    public final String mutedBy;

    public MuteManager$MuteEntry(long arg0, String arg1, String arg2) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'MuteManager.java'
       'InnerClasses'
       'MuteEntry'
    */
}