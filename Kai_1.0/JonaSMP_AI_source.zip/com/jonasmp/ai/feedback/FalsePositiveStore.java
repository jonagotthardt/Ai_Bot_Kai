package com.jonasmp.ai.feedback;

public class FalsePositiveStore {

    private final File storeFile;
    private final Gson gson;
    private final Set knownFalsePositives;
    private final List entries;

    public FalsePositiveStore(File arg0) {
        // TODO: decompile
    }

    public void report(String arg0, String arg1, String arg2) {
    }

    public boolean isKnownFalsePositive(String arg0) {
        return false;
    }

    private String normalize(String arg0) {
        return null;
    }

    private void load() {
    }

    private void save() {
    }

    public int getCount() {
        return 0;
    }

    /* String constants found in bytecode:
       'setPrettyPrinting'
       'knownFalsePositives'
       'false_positives.json'
       'storeFile'
       'normalize'
       'currentTimeMillis'
       'toLowerCase'
       'replaceAll'
       'newBufferedReader'
       'normalizedMessage'
       'addSuppressed'
       'getLogger'
       'getMessage'
       'makeConcatWithConstants'
       'newBufferedWriter'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'dataFolder'
       'normalized'
       'StackMapTable'
       'isKnownFalsePositive'
       'LocalVariableTypeTable'
       'SourceFile'
       'FalsePositiveStore.java'
       'NestMembers'
       'BootstrapMethods'
       'InnerClasses'
       'FalsePositiveEntry'
    */
}