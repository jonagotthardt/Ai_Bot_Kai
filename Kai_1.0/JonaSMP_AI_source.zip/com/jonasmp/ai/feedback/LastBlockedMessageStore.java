package com.jonasmp.ai.feedback;

public class LastBlockedMessageStore {

    private final Map lastBlocked;

    public LastBlockedMessageStore() {
        // TODO: decompile
    }

    public void recordBlocked(UUID arg0, String arg1) {
    }

    public String getLastBlocked(UUID arg0) {
        return null;
    }

    public void clear(UUID arg0) {
    }

    /* String constants found in bytecode:
       'lastBlocked'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'recordBlocked'
       'rawMessage'
       'StackMapTable'
       'getLastBlocked'
       'SourceFile'
       'LastBlockedMessageStore.java'
    */
}