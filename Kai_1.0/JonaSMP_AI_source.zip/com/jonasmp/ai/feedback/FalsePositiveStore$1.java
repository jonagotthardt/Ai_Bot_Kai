package com.jonasmp.ai.feedback;

public class FalsePositiveStore$1 extends TypeToken {

     FalsePositiveStore$1(FalsePositiveStore arg0) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'requireNonNull'
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'FalsePositiveStore.java'
       'EnclosingMethod'
       'InnerClasses'
       'FalsePositiveEntry'
    */
}