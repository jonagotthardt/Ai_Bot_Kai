package com.jonasmp.ai.feedback;

public class FalsePositiveStore$FalsePositiveEntry {

     String normalizedMessage;
     String playerId;
     long timestamp;
     String reason;

     FalsePositiveStore$FalsePositiveEntry(String arg0, String arg1, long arg2, String arg3) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'normalizedMessage'
       'timestamp'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'FalsePositiveStore.java'
       'InnerClasses'
       'FalsePositiveEntry'
    */
}