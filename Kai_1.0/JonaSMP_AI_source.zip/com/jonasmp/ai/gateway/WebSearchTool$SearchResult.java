package com.jonasmp.ai.gateway;

public class WebSearchTool$SearchResult {

    public final String title;
    public final String snippet;
    public final String url;

    public WebSearchTool$SearchResult(String arg0, String arg1, String arg2) {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'WebSearchTool.java'
       'InnerClasses'
       'SearchResult'
    */
}