package com.jonasmp.ai.gateway;

public class AIResponse {

    private final double toxicity;
    private final double scam;
    private final double memoryRisk;
    private final double risk;
    private final String aiAction;
    private final double adaptiveBlockThreshold;
    private final double adaptiveWarnThreshold;
    private final String language;
    private final String originalMessage;
    private final boolean chatEligible;

    public AIResponse(double arg0, double arg1, double arg2, double arg3, String arg4, double arg5, double arg6, String arg7, String arg8) {
        // TODO: decompile
    }

    public AIResponse(double arg0, double arg1, double arg2, double arg3, String arg4, double arg5, double arg6, String arg7, String arg8, boolean arg9) {
        // TODO: decompile
    }

    public double getToxicity() {
        return 0.0;
    }

    public double getScam() {
        return 0.0;
    }

    public double getMemoryRisk() {
        return 0.0;
    }

    public double getRisk() {
        return 0.0;
    }

    public String getAiAction() {
        return null;
    }

    public double getAdaptiveBlockThreshold() {
        return 0.0;
    }

    public double getAdaptiveWarnThreshold() {
        return 0.0;
    }

    public String getLanguage() {
        return null;
    }

    public String getOriginalMessage() {
        return null;
    }

    public boolean isChatEligible() {
        return false;
    }

    /* String constants found in bytecode:
       'memoryRisk'
       'adaptiveBlockThreshold'
       'adaptiveWarnThreshold'
       'originalMessage'
       'chatEligible'
       'LineNumberTable'
       'LocalVariableTable'
       'getToxicity'
       'getMemoryRisk'
       'getAiAction'
       'getAdaptiveBlockThreshold'
       'getAdaptiveWarnThreshold'
       'getLanguage'
       'getOriginalMessage'
       'isChatEligible'
       'SourceFile'
       'AIResponse.java'
    */
}