package com.jonasmp.ai.gateway;

public class ChatSession {

    private static final long SESSION_TTL_MS;
    private final Map sessions;
    private final Map webSearchEnabled;
    private final Map pendingWebQuery;

    public ChatSession() {
        // TODO: decompile
    }

    public List getMessagesForPrompt(String arg0, JsonObject arg1, JsonObject arg2) {
        return null;
    }

    public void recordAssistantReply(String arg0, String arg1) {
    }

    public void recordUserMessage(String arg0, JsonObject arg1) {
    }

    public void clearSession(String arg0) {
    }

    public int getHistorySize(String arg0) {
        return 0;
    }

    public boolean isWebSearchEnabled(String arg0) {
        return false;
    }

    public void setWebSearchEnabled(String arg0, boolean arg1) {
    }

    public boolean hasPendingWebQuery(String arg0) {
        return false;
    }

    public String getPendingWebQuery(String arg0) {
        return null;
    }

    public void setPendingWebQuery(String arg0, String arg1) {
    }

    public void clearPendingWebQuery(String arg0) {
    }

    private static ChatSession$SessionData lambda$recordUserMessage$0(String arg0) {
        return null;
    }

    private static ChatSession$SessionData lambda$getMessagesForPrompt$0(String arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'webSearchEnabled'
       'pendingWebQuery'
       'computeIfAbsent'
       'currentTimeMillis'
       'lastActivity'
       'isDebugEnabled'
       'getLogger'
       'makeConcatWithConstants'
       'assistant'
       'addProperty'
       'getOrDefault'
       'booleanValue'
       'containsKey'
       'SESSION_TTL_MS'
       'ConstantValue'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'getMessagesForPrompt'
       'systemMsg'
       'currentUserMsg'
       'LocalVariableTypeTable'
       'StackMapTable'
       'recordAssistantReply'
       'assistantMsg'
       'recordUserMessage'
       'maxHistory'
       'clearSession'
       'getHistorySize'
       'isWebSearchEnabled'
       'setWebSearchEnabled'
       'hasPendingWebQuery'
       'getPendingWebQuery'
       'setPendingWebQuery'
       'clearPendingWebQuery'
       'lambda$recordUserMessage$0'
       'lambda$getMessagesForPrompt$0'
       'SourceFile'
       'ChatSession.java'
       'NestMembers'
    */
}