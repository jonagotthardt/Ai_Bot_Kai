package com.jonasmp.ai.gateway;

public class ChatSession$SessionData {

    final List history;
     long lastActivity;

    private ChatSession$SessionData() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'currentTimeMillis'
       'lastActivity'
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'ChatSession.java'
       'InnerClasses'
       'SessionData'
    */
}