package com.jonasmp.ai.punishment;

public class PunishmentEngine {

    public PunishmentEngine() {
        // TODO: decompile
    }

    public void execute(Player arg0, PunishmentResult arg1) {
    }

    /* String constants found in bytecode:
       '$SwitchMap$com$jonasmp$ai$punishment$PunishmentType'
       'getConsoleSender'
       'getReason'
       'makeConcatWithConstants'
       'dispatchCommand'
       'sendMessage'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'PunishmentEngine.java'
       'NestMembers'
       'BootstrapMethods'
       '§eWarning: \x01'
       'InnerClasses'
    */
}