package com.jonasmp.ai.punishment;

public class PunishmentType extends Enum {

    public static final PunishmentType NONE;
    public static final PunishmentType WARN;
    public static final PunishmentType KICK;
    public static final PunishmentType MUTE;
    public static final PunishmentType BAN;
    private static final PunishmentType[] $VALUES;

    public static PunishmentType[] values() {
        return null;
    }

    public static PunishmentType valueOf(String arg0) {
        return null;
    }

    private PunishmentType(String arg0, int arg1) {
        // TODO: decompile
    }

    private static PunishmentType[] $values() {
        return null;
    }

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'MethodParameters'
       'Signature'
       'SourceFile'
       'PunishmentType.java'
    */
}