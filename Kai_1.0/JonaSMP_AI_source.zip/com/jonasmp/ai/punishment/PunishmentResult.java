package com.jonasmp.ai.punishment;

public class PunishmentResult {

    private final PunishmentType type;
    private final String reason;
    private final long duration;

    public PunishmentResult(PunishmentType arg0, String arg1, long arg2) {
        // TODO: decompile
    }

    public PunishmentType getType() {
        return null;
    }

    public String getReason() {
        return null;
    }

    public long getDuration() {
        return 0;
    }

    /* String constants found in bytecode:
       'LineNumberTable'
       'LocalVariableTable'
       'getReason'
       'getDuration'
       'SourceFile'
       'PunishmentResult.java'
    */
}