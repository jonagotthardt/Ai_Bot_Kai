package com.jonasmp.ai.punishment;

public class PunishmentEngine$1 {

    static final int[] $SwitchMap$com$jonasmp$ai$punishment$PunishmentType;

    static {
        // static initializer
    }

    /* String constants found in bytecode:
       '$SwitchMap$com$jonasmp$ai$punishment$PunishmentType'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'SourceFile'
       'PunishmentEngine.java'
       'EnclosingMethod'
       'InnerClasses'
    */
}