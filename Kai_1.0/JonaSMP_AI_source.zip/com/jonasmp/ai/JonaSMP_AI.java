package com.jonasmp.ai;

public class JonaSMP_AI extends JavaPlugin {

    private static JonaSMP_AI instance;
    private ChunkRadar chunkRadar;

    public JonaSMP_AI() {
        // TODO: decompile
    }

    public void onLoad() {
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public static JonaSMP_AI getInstance() {
        return null;
    }

    public ChunkRadar getChunkRadar() {
        return null;
    }

    private void lambda$onEnable$1() {
    }

    private void lambda$onEnable$0() {
    }

    /* String constants found in bytecode:
       'getLogger'
       'saveDefaultConfig'
       'getServer'
       'getPluginManager'
       'MUTE_MANAGER'
       'registerEvents'
       'chunkRadar'
       'getDeltaTracker'
       'getScheduler'
       'runTaskLater'
       'getCommand'
       'setExecutor'
       'setTabCompleter'
       'SHOP_BRIDGE'
       'shopprice'
       'shopsearch'
       'makeConcatWithConstants'
       'getAIModel'
       'MEMORY_ENGINE'
       'exportAllProfiles'
       'THREAT_MANAGER'
       'MESSAGE_CACHE'
       'getInstance'
       'isRunning'
       'getMessage'
       'LineNumberTable'
       'LocalVariableTable'
       'watcherCommands'
       'watcherCmd'
       'shopCommands'
       'activityTracker'
       'StackMapTable'
       'onDisable'
       'getChunkRadar'
       'lambda$onEnable$1'
       'lambda$onEnable$0'
       'SourceFile'
       'JonaSMP_AI.java'
       'BootstrapMethods'
       'metafactory'
    */
}