package com.jonasmp.ai.language;

public class PlayerLanguageStore {

    private final File file;
    private FileConfiguration config;

    public PlayerLanguageStore() {
        // TODO: decompile
    }

    public String getLanguage(UUID arg0) {
        return null;
    }

    public void setLanguage(UUID arg0, String arg1) {
    }

    public boolean hasLanguage(UUID arg0) {
        return false;
    }

    private void save() {
    }

    /* String constants found in bytecode:
       'getDataFolder'
       'player_languages.yml'
       'createNewFile'
       'getLogger'
       'loadConfiguration'
       'getString'
       'getPlayer'
       'getLocale'
       'toLowerCase'
       'startsWith'
       'setLanguage'
       'makeConcatWithConstants'
       'toUpperCase'
       '§a[AI] Language set to §b§lENGLISH§a.'
       'sendMessage'
       '§a[AI] Sprache auf §b§lDEUTSCH§a gesetzt.'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'getLanguage'
       'hasLanguage'
       'SourceFile'
       'PlayerLanguageStore.java'
       'BootstrapMethods'
       'InnerClasses'
    */
}