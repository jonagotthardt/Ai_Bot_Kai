package com.jonasmp.ai.util;

public class Trie {

    private final Trie$TrieNode root;
    private boolean built;

    public Trie() {
        // TODO: decompile
    }

    public void insert(String arg0) {
    }

    public void build() {
    }

    public List search(String arg0) {
        return null;
    }

    public boolean containsAny(String arg0) {
        return false;
    }

    public int countMatches(String arg0) {
        return 0;
    }

    private static Trie$TrieNode lambda$insert$0(Character arg0) {
        return null;
    }

    /* String constants found in bytecode:
       'toCharArray'
       'computeIfAbsent'
       'charValue'
       'containsKey'
       'LineNumberTable'
       'LocalVariableTable'
       'StackMapTable'
       'LocalVariableTypeTable'
       'Signature'
       'containsAny'
       'countMatches'
       'lambda$insert$0'
       'SourceFile'
       'Trie.java'
       'NestMembers'
       'BootstrapMethods'
       'metafactory'
       'InnerClasses'
    */
}