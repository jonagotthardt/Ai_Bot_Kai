package com.jonasmp.ai.util;

public class Trie$TrieNode {

    final Map children;
     Trie$TrieNode fail;
     boolean isEnd;
     String word;

    private Trie$TrieNode() {
        // TODO: decompile
    }

    /* String constants found in bytecode:
       'Signature'
       'LineNumberTable'
       'LocalVariableTable'
       'SourceFile'
       'Trie.java'
       'InnerClasses'
    */
}